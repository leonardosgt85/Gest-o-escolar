# Integrações e divergências

## Dependências externas e alternativas locais

| Dependência | Alternativa local executável | Para substituir |
|---|---|---|
| Boletos/remessa/retorno bancário/cartões | Cobrança em centavos e registro manual local; solicitação externa fica pendente | Contrato/API bancária, sandbox, webhook autenticado, IDs e conciliação |
| E-mail/SMS/WhatsApp/ClassApp/Layers | Mensagens e solicitações locais persistidas; nenhum envio | Provedor, autorização, destinatários de homologação, recibos e retries |
| Fiscal | Solicitação pendente; nenhuma NFS-e emitida | Município/provedor/layout, certificado privado e sandbox |
| Professus/catraca | Item de navegação e pendência; nenhum acesso externo | Documentação e autorização específica do fornecedor |
| Importação/exportação legada | Fila local de solicitação; CSV local dos relatórios próprios | Dicionário, formato autorizado, mapa de IDs e reconciliação |
| Histórico, diploma, contrato assinado | Resumo imprimível demonstrativo com dados próprios | Modelos aprovados, regras institucionais e integração de assinatura |

Uma fila pendente não é um conector pronto. Pagamento manual local não é confirmação bancária. Não há envio externo, cobrança real, transferência ou migração de dados nesta entrega.

## Divergências visuais

- Logotipos, anúncio e arte do fornecedor foram substituídos por placeholders e texto equivalente; faltam recursos autorizados.
- Cores, tipografia e medidas são aproximações do material observado. A referência exata de todos os formulários não esteve acessível.
- Menus mantêm176 destinos, agrupados por módulo/categoria. Cadeias profundas foram reorganizadas para permitir pesquisa/uso em telas estreitas.
- O excesso horizontal observado na Home e o corte de banner foram corrigidos na organização responsiva; tabelas podem rolar internamente.
- Login é novo com JWT; não copia a autenticação privada do fornecedor.

## Divergências funcionais

- 23 cadastros relacionais próprios sustentam as operações demonstráveis; campos não observados são modelagem mínima inferida e não paridade comprovada.
- 67 destinos de relatório apontam para oito consultas locais simplificadas. Não são67 relatórios específicos reproduzidos; a página avisa a simplificação.
- 85 destinos não inspecionados têm página de dependência e nenhuma ação de negócio implementada. São bloqueios explícitos, não funções concluídas.
- Nove destinos têm apenas fila local de integração, sem serviço externo.
- “Situação de matrícula” filtra vínculos no contexto, sem prometer a regra de última matrícula do original. Usuário/data de cadastro e outros filtros/colunas da consulta original não foram todos reproduzidos.
- Papéis admin/secretaria/professor/financeiro são uma matriz mínima local; somente Administrador foi observado no original. Professor opera registros atribuídos; Financeiro não lê a ficha acadêmica completa.
- Nota individual não calcula média/recuperação/aprovação. Precisão decimal e valor não negativo são limites técnicos locais, não regra pedagógica da escola. Não foi fixada escala10/100.
- Vagas, datas acadêmicas, estado Cursando e controle de vínculos têm validação mínima local declarada. Regras oficiais de deferimento/transferência/encerramento precisam de homologação.
- Recebimento parcial é uma alternativa simples local. Não há multa, juros, abatimento de pré-matrícula, fechamento de caixa, transferência, estorno financeiro ou baixa bancária implementados.
- Contas a pagar registram obrigações; não executam pagamentos. Documentos registram metadados/recebimento, sem upload privado. Não há folha de pagamento, folha fiscal ou comunicações externas.

## Decisões indispensáveis

Escola/secretaria: campos e documentos oficiais, critérios de matrícula/transferência, datas/capacidade, atribuições. Coordenação: fórmulas, escala de notas, períodos, recuperação, frequência/fechamento. Financeiro: contratos, descontos, juros, baixas/estornos e conciliação. Fornecedores: exportação, APIs e sandbox. Proprietário: mídias autorizadas, retenção, recuperação e implantação. Nenhuma regra ausente foi preenchida como fato do original.

## Regras de dados e operação

Valores monetários são inteiros em centavos (BRL); datas de negócio são YYYY-MM-DD sem conversão de fuso. Instantes usam timestamptz, API ISO com offset/Z, e interface no fuso do navegador (testado America/Cuiaba). Migração001 usa snapshot imutável; down remove tabelas e é destrutivo, permitido apenas em destino vazio/descartável ou com backup e decisão específica. Seeds são idempotentes e bloqueados em produção; SEED_DEMO=0 mantém o admin local, somente desliga demais exemplos.
