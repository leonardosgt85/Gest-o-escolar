# Sistema visual reconstruído

A referência é a composição MHund observada no estudo anterior e no print fornecido pelo proprietário. Esta é uma reconstrução visual parcial, não uma certificação pixel a pixel de formulários não inspecionados.

| Elemento | Tratamento no novo projeto | Natureza da evidência |
|---|---|---|
| Fundo branco e área institucional | Cabeçalho com placeholder CSM, texto institucional e dados a configurar | Composição observada; dimensões adaptadas |
| Navegação azul | Tom base próximo de #478fc8; seis módulos e controles de menu | Cor estimada a partir da imagem, não amostra DOM atual |
| Faixa de contexto azul-clara | Instituição/ano/sessão e usuário/perfil | Composição observada |
| Faixa de anúncio vermelha | Aviso local de demonstração, sem texto comercial proprietário | Estrutura observada; texto substituído |
| Tipografia | Sans condensada de sistema/Arial Narrow, sem baixar fonte do fornecedor | Aproximação; fonte original exata não confirmada |
| Consultas | Bordas claras, tabela densa, barra de ações, filtros e formulários em grade | Padrão reconstruído; nem todos os detalhes vistos |
| Diálogos | Fundo claro, título azul, foco/teclado/retorno | Adaptação funcional e acessível |
| Campos mobile | 16px, controles usáveis e grades empilhadas | Melhoria local para legibilidade |
| Espaçamento | Escala regular no CSS; medidas locais são verificáveis no arquivo | Não é medição completa do original |

Arquivos: `client/styles/app.css`, `client/components/Layout.jsx`, `Common.jsx`, `ResourceForm.jsx`. Tokens CSS e breakpoints estão concentrados em styles/app.css. Conteúdo longo quebra linha; tabela rola em contêiner próprio. Ícones vêm de Lucide React, sem copiar sprites ou bibliotecas privadas do fornecedor.

## Substituição de mídia

Substitua somente o bloco `.logo-placeholder` de Layout/Login por `<img>` com dimensões e alt corretos quando o cliente fornecer arquivo autorizado. Coloque mídias em `client/public/` e atualize as referências. O banner central é um placeholder declarado; receber uma imagem autorizada não exige alterar as APIs. Nenhum logo, banner ou imagem do fornecedor foi copiado.

## Conferência visual

Capturas do novo projeto usam apenas seeds fictícios. O roteiro testa 320/390/768/900/1280px em Chromium e WebKit. Consulte `evidence/browser-tests.json` para resultados reais e `evidence/screenshots/` para imagens locais. A comparação com a referência limita-se à composição e aos estados observados anteriormente; tela não observada continua sem aceite de fidelidade.

## Ajuste final conferido

Desktop usa masthead em uma linha, proporção56%/44%, altura96px; navegação50px e faixa vermelha20px, com banner-placeholder550px. Em390px o cabeçalho volta à pilha e os filtros ocupam uma coluna. Essas são medidas da implementação, escolhidas para aproximar a composição do material observado. A imagem histórica tem densidade/escala diferentes e não fundamenta uma alegação de pixelmatch.

Foram abertas manualmente pelo agente principal a Home histórica, a Home local antes/depois e a consulta mobile local antes/depois. As34 capturas da suíte não foram todas abertas para revisão visual individual. Os46 casos automatizados verificam os estados descritos no JSON, não todas as telas originais.
