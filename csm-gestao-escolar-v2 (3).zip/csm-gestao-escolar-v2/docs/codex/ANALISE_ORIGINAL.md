# Análise funcional do original — MHund

Data: 29/10/2026, America/Cuiaba. Referência: https://www.mhund.com.br/Home. Projeto próprio separado do CSM PHP, do fornecedor, de seus bancos e credenciais.

## Fontes e limites

Fonte primária: estudo autenticado anterior em `outputs/estudo-mhund-20261029` do workspace, feito com a sessão legítima do proprietário. Foram registrados 43 estados de menus/consulta vazia e 176 destinos distintos. Não são 176 operações executadas. A página de Alunos foi examinada sem pesquisar pessoa real ou concluir gravação. O dashboard foi examinado quanto à estrutura, sem copiar valores financeiros. Fonte secundária: páginas públicas do fabricante, que anunciam capacidades sem comprovar contratação ou regras da escola.

Nesta implementação, a ferramenta do navegador integrado não disponibilizou uma sessão controlável e a aba do Chrome não retornou conteúdo DOM utilizável; posterior tentativa indicou aba fora da sessão de controle. Isso limita a inspeção nova e não demonstra indisponibilidade do MHund nem senha inválida. Não foram recuperados cookies, tokens, senhas ou dados privados. O estudo anterior foi preservado e reaproveitado; a atualidade de todos os formulários internos NÃO foi confirmada novamente.

## Composição observada

Cabeçalho institucional branco: logotipo à esquerda, nome/endereço/dados institucionais ao centro. Faixa azul-clara dividida: instituição, ano letivo e tempo de sessão; usuário/perfil à direita. Navegação azul com Início, Acadêmico, Financeiro, Gerencial, Manutenção, Utilitários, Patrimônio, suporte e dashboard. Submenus hierárquicos de Arquivos, Lançamentos, Relatórios e Gráficos. Faixa de anúncio vermelha e banner central do fornecedor. Rodapé azul.

O projeto recria a composição e os seis módulos, com mídia/logotipo representados por placeholders. Os agrupamentos foram reconstruídos a partir dos estados observados; não se afirma reprodução exata de toda cadeia de submenu. Anúncios proprietários e marca do fornecedor foram substituídos por conteúdo local equivalente.

## Consulta de alunos: observação direta

Finalidade: localizar e selecionar aluno. Filtros vistos: Curso, Responsável financeiro, Código, CPF, Nome do aluno, Matrícula, Ano do curso, Usuário/data de cadastro, Situação da última matrícula. Colunas vistas: Código, Matrícula, CPF, Nome, Nascimento, Telefone, E-mail, Curso, Situação, Ano. Ações vistas: Novo, Editar, Excluir, Pesquisar, Selecionar. Apenas abertura/fechamento de filtros foi executada no original.

Não foram observados os campos internos completos do formulário de inclusão, obrigatoriedade, validações, máscaras, todos os diálogos, sucesso de gravação ou persistência. Os formulários locais são reconstruções mínimas declaradas, não cópia validada desses detalhes.

No novo projeto: consulta com filtros confirmados suportados pelo modelo, seleção por rádio, paginação, modal de cadastro/edição/exclusão e detalhe com matrículas, notas, frequência/documentos locais. O filtro usa “Situação de matrícula”, pois aplica qualquer vínculo no ano/contexto escolhido; não inventamos uma regra de última matrícula. Filtro usuário/data de cadastro e colunas institucionais detalhadas não foram integralmente reproduzidos.

## Mapa dos módulos observados

- Acadêmico: alunos/responsáveis/ensalamento, conteúdos, notas/frequência, progressão, boletins, diários, históricos, atas, ocorrências, estatísticas e CRM.
- Financeiro: cobranças/baixas, caixas/bancos, retornos, cartões/cheques, contas a pagar, fornecedores, relatórios e fiscal.
- Gerencial: usuários/permissões, configurações, eventos, contratos, documentos e mensagens.
- Manutenção: cursos/séries/disciplinas, esquemas de avaliação, calendários, classificações, parâmetros financeiros.
- Utilitários: importações/exportações, próximo ano, replicações e integrações.
- Patrimônio: bens, grupos/setores e relatórios.

O arquivo PARIDADE.csv contém cada um dos 176 destinos. Fluxos não inspecionados permanecem NÃO VERIFICADOS/BLOQUEADOS; menu presente não é prova de implementação equivalente.

## Fluxos locais conectados

1. Login: e-mail/senha → hash bcrypt → JWT com expiração em cookie HttpOnly → sessão revogável no banco → catálogo por sessão. POSTs protegidos por Origin/CSRF. Logout revoga a sessão.
2. Cadastro: pesquisar/paginar → selecionar → Novo/Editar → validar → API → transação Knex/PostgreSQL → GET de confirmação → recarregar → recuperar registro. Exclusão pede confirmação e respeita FKs.
3. Acadêmico: curso/ano/turma → aluno/responsável/vínculo → matrícula → aula/conteúdo → frequência e nota individuais. Não há média, aprovação ou fechamento escolar inventados.
4. Financeiro: obrigação em centavos → recebimento manual local parcial/integral → trava da parcela e chave idempotente → saldo real. Um filho não quita o irmão. Nada é confirmado em banco externo.
5. Documentos: resumo de dados locais → impressão demonstrativa; sem assinatura digital ou validade de histórico oficial.
6. Integrações: detalhes → fila persistida pendente → releitura. Nenhum envio ou importação externa é simulado como sucesso.

## Estados e usabilidade

As páginas locais têm inicial/carregando, vazio, preenchido, erro, sucesso e acesso negado. Dependências desconhecidas têm página explícita sem ação de negócio. Mensagens de API não expõem SQL/credenciais. Diálogos têm foco contido, Escape, retorno ao invocador e bloqueio durante gravação. Erros de campo direcionam o foco.

O estudo observou excesso horizontal de 15px na Home a1280 CSS e corte do banner no celular. O novo layout mantém a organização e adapta menus/tabelas; a tabela pode rolar em seu contêiner, sem rolagem lateral da página. As larguras são viewports de navegador, não aparelhos físicos.

## Para completar a equivalência

É indispensável uma sessão novamente controlável e registros fictícios autorizados para observar inclusão/edição, validações, documentos, regras de notas/fechamento, caixa, baixa, fiscal e operações em lote. A escola deve fornecer regras e exemplos aprovados; fornecedores devem fornecer contratos técnicos/sandbox. Não houve gravação no original nesta tarefa.
