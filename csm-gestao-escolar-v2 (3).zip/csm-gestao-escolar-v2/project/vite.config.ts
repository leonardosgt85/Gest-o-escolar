import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'node:path'

// Em desenvolvimento o Vite encaminha /api para o backend (mesma origem para o
// navegador, então o cookie de sessão funciona sem CORS). Para apontar para
// outro host use VITE_API_PROXY, ou VITE_API_URL para chamar a API direto.
const apiTarget = process.env.VITE_API_PROXY || 'http://127.0.0.1:3000'

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  server: {
    host: '0.0.0.0',
    port: Number(process.env.PORT || 5173),
    proxy: { '/api': { target: apiTarget, changeOrigin: false } },
  },
  preview: { host: '0.0.0.0', port: Number(process.env.PORT || 5173) },
})
