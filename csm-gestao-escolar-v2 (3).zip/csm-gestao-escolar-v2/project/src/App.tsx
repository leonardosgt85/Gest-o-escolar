import { Component, type ReactNode } from 'react'
import { BrowserRouter, Link, Navigate, Route, Routes, useParams } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import Layout from './components/Layout'
import { Alert, Loading, PageHeader } from './components/ui'
import Login from './pages/Login'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import ResourcePage from './pages/Resource'
import ReportPage from './pages/Report'
import IntegrationPage from './pages/Integration'
import PendingPage from './pages/Pending'

class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() {
    if (!this.state.failed) return this.props.children
    return (
      <div className="container fatal-error">
        <Alert>Ocorreu um erro ao exibir esta página. Recarregue para tentar novamente.</Alert>
        <button className="btn btn-primary" type="button" onClick={() => window.location.reload()}>Recarregar</button>
      </div>
    )
  }
}

function NotFound() {
  return (
    <>
      <PageHeader title="Página não encontrada" />
      <p>A rota informada não consta no catálogo deste sistema.</p>
      <Link className="btn btn-primary" to="/">Voltar ao início</Link>
    </>
  )
}

function ResourceRoute() {
  const { catalog, user } = useApp()
  const { resourceKey = '' } = useParams()
  const resource = catalog!.resources[resourceKey]
  if (!resource) return <NotFound />
  return <ResourcePage key={resource.key} resource={resource} user={user!} />
}

// /sistema/:routeId resolve a rota do catálogo (176 destinos do menu) para a
// tela correspondente: cadastro, relatório, fila de integração ou "pendente".
function CatalogRoute() {
  const { catalog, user } = useApp()
  const { routeId } = useParams()
  const source = catalog!.routes.find((r) => r.path === `/sistema/${routeId}`)
  if (!source) return <NotFound />
  const route = { ...source, moduleLabel: catalog!.modules.find((m) => m.id === source.module)?.label || source.module }
  if (route.mode === 'resource' && route.target && catalog!.resources[route.target]) {
    return <ResourcePage key={route.id} resource={catalog!.resources[route.target]} route={route} user={user!} />
  }
  if (route.mode === 'report') return <ReportPage key={route.id} route={route} user={user!} />
  if (route.mode === 'integration') return <IntegrationPage key={route.id} route={route} />
  return <PendingPage key={route.id} route={route} />
}

function Gate() {
  const { user, catalog, authChecked, loading, reloadCatalog } = useApp()

  if (!authChecked) return <div className="container fatal-error"><Loading>Verificando sessão…</Loading></div>
  if (!user) return <Login />
  if (!catalog) {
    return (
      <div className="container fatal-error">
        {loading ? <Loading /> : (
          <>
            <Alert>Catálogo indisponível.</Alert>
            <button className="btn btn-primary" type="button" onClick={() => reloadCatalog().catch(() => {})}>Recarregar catálogo</button>
          </>
        )}
      </div>
    )
  }

  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Navigate to="/" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/cadastros/:resourceKey" element={<ResourceRoute />} />
          <Route path="/sistema/:routeId" element={<CatalogRoute />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <Gate />
      </AppProvider>
    </ErrorBoundary>
  )
}
