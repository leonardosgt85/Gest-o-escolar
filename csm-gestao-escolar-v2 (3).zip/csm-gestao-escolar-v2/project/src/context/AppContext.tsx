import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api, onUnauthorized } from '../lib/api'
import type { Catalog, User } from '../lib/types'

interface AppState {
  user: User | null
  catalog: Catalog | null
  authChecked: boolean
  loading: boolean
  notice: string
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  reloadCatalog: () => Promise<void>
}

const AppContext = createContext<AppState | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [catalog, setCatalog] = useState<Catalog | null>(null)
  const [authChecked, setAuthChecked] = useState(false)
  const [loading, setLoading] = useState(false)
  const [notice, setNotice] = useState('')

  const loadCatalog = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api<{ data: Catalog }>('/catalog')
      setCatalog(res.data)
    } finally {
      setLoading(false)
    }
  }, [])

  // Sessão expirada/revogada em qualquer chamada: volta para o login.
  useEffect(() => {
    onUnauthorized(() => {
      setUser(null)
      setCatalog(null)
      setNotice('Sua sessão expirou ou foi encerrada. Entre novamente para continuar.')
    })
  }, [])

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const me = await api<{ user: User }>('/auth/me')
        if (cancelled) return
        setUser(me.user)
        await loadCatalog()
      } catch {
        /* sem sessão: segue para o login */
      } finally {
        if (!cancelled) setAuthChecked(true)
      }
    })()
    return () => { cancelled = true }
  }, [loadCatalog])

  const login = useCallback(async (email: string, password: string) => {
    const res = await api<{ user: User }>('/auth/login', { method: 'POST', body: { email, password } })
    setNotice('')
    setUser(res.user)
    await loadCatalog()
  }, [loadCatalog])

  const logout = useCallback(async () => {
    await api('/auth/logout', { method: 'POST' })
    setUser(null)
    setCatalog(null)
    setNotice('Sessão encerrada.')
  }, [])

  const value = useMemo<AppState>(
    () => ({ user, catalog, authChecked, loading, notice, login, logout, reloadCatalog: loadCatalog }),
    [user, catalog, authChecked, loading, notice, login, logout, loadCatalog],
  )
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp deve ser usado dentro de <AppProvider>')
  return ctx
}
