import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import type { Option } from '../lib/types'

// Carrega as listas (id + rótulo) dos cadastros referenciados por campos/filtros.
// Falhas de uma referência não derrubam as demais.
export default function useReferences(references: (string | undefined)[]) {
  const keys = [...new Set(references.filter((r): r is string => Boolean(r)))].sort().join(',')
  const [state, setState] = useState<{ data: Record<string, Option[]>; loading: boolean; error: string }>({ data: {}, loading: false, error: '' })

  useEffect(() => {
    const controller = new AbortController()
    if (!keys) { setState({ data: {}, loading: false, error: '' }); return () => controller.abort() }
    setState({ data: {}, loading: true, error: '' })
    Promise.allSettled(
      keys.split(',').map(async (key) => {
        const res = await api<{ data: Option[] }>(`/options/${encodeURIComponent(key)}`, { signal: controller.signal })
        return [key, res.data] as const
      }),
    ).then((results) => {
      if (controller.signal.aborted) return
      const data: Record<string, Option[]> = {}
      let error = ''
      for (const r of results) {
        if (r.status === 'fulfilled') data[r.value[0]] = r.value[1]
        else if ((r.reason as Error).name !== 'AbortError') error = (r.reason as Error).message
      }
      setState({ data, loading: false, error })
    })
    return () => controller.abort()
  }, [keys])

  return state
}
