// A sessão vive num cookie httpOnly definido pelo backend: o JavaScript nunca
// vê o token. `credentials: 'include'` faz o navegador enviá-lo em toda chamada.
const API_URL = (import.meta.env.VITE_API_URL as string | undefined) || '/api'

export class ApiRequestError extends Error {
  status: number
  code?: string
  fields: Record<string, string>
  constructor(message: string, status: number, code?: string, fields?: unknown) {
    super(message)
    this.name = 'ApiRequestError'
    this.status = status
    this.code = code
    this.fields = normalizeFieldErrors(fields)
  }
}

function normalizeFieldErrors(fields: unknown): Record<string, string> {
  if (!Array.isArray(fields)) return {}
  const result: Record<string, string> = {}
  for (const issue of fields as { field?: string; message?: string }[]) {
    if (!issue?.field || !issue.message) continue
    result[issue.field] = result[issue.field] ? `${result[issue.field]} ${issue.message}` : issue.message
  }
  return result
}

let unauthorizedHandler: () => void = () => {}
export function onUnauthorized(handler: () => void) {
  unauthorizedHandler = handler
}

interface RequestOptions {
  method?: string
  body?: unknown
  signal?: AbortSignal
}

export async function api<T = any>(path: string, { method = 'GET', body, signal }: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  let res: Response
  try {
    res = await fetch(`${API_URL}${path}`, {
      method,
      headers,
      credentials: 'include',
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    })
  } catch (err) {
    if ((err as Error).name === 'AbortError') throw err
    throw new ApiRequestError('Não foi possível conectar ao servidor. Confira a conexão e tente novamente.', 0, 'NETWORK_ERROR')
  }

  if (res.status === 204) return undefined as T
  let data: any = {}
  if ((res.headers.get('content-type') || '').includes('json')) {
    try { data = await res.json() } catch { data = {} }
  }
  if (!res.ok) {
    if (res.status === 401 && path !== '/auth/login') unauthorizedHandler()
    throw new ApiRequestError(data?.error || `A solicitação falhou (${res.status}).`, res.status, data?.code, data?.fields)
  }
  return data as T
}

export function queryString(values: Record<string, string | number | null | undefined>): string {
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(values)) {
    if (value !== '' && value !== null && value !== undefined) params.set(key, String(value))
  }
  const text = params.toString()
  return text ? `?${text}` : ''
}
