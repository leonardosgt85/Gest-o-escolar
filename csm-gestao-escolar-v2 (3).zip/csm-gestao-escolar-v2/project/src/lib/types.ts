export type Role = 'admin' | 'secretaria' | 'professor' | 'financeiro'

export interface User {
  id: string
  name: string
  email: string
  role: Role
}

export interface Field {
  key: string
  label: string
  type: string
  required?: boolean
  reference?: string
  options?: string[]
}

export interface Resource {
  key: string
  label: string
  module: string
  fields: Field[]
  notice?: string
}

export type RouteMode = 'resource' | 'report' | 'integration' | 'pending'

export interface CatalogRoute {
  id: string
  module: string
  label: string
  originalPath: string
  path: string
  mode: RouteMode
  target: string | null
  notice: string | null
  group?: string
  navigationEvidence?: string
}

export interface Catalog {
  modules: { id: string; label: string }[]
  routes: CatalogRoute[]
  resources: Record<string, Resource>
}

export type Row = Record<string, unknown> & { id: string }

export interface Pagination {
  page: number
  pageSize: number
  total: number
}

export interface Option {
  id: string
  label: string
}

export interface ReportData {
  title: string
  columns: { key: string; label: string }[]
  rows: Row[]
  notice?: string
}
