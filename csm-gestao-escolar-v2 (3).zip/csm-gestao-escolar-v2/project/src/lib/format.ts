import type { Option } from './types'

// Dinheiro trafega sempre em centavos (inteiro); a tela mostra/edita em reais.
export function parseMoney(value: string): number {
  const text = String(value).trim()
  if (!/^-?\d+(?:[.,]\d{1,2})?$/.test(text)) {
    throw new Error('Informe um valor sem separador de milhar e com até duas casas decimais.')
  }
  const [whole, decimals = ''] = text.replace(',', '.').split('.')
  const negative = whole.startsWith('-')
  const cents = BigInt(whole.replace('-', '')) * 100n + BigInt(decimals.padEnd(2, '0'))
  const signed = negative ? -cents : cents
  if (signed > BigInt(Number.MAX_SAFE_INTEGER) || signed < BigInt(Number.MIN_SAFE_INTEGER)) throw new Error('Valor acima do limite permitido.')
  return Number(signed)
}

export function moneyInput(cents: unknown): string {
  if (cents === null || cents === undefined || cents === '') return ''
  const value = BigInt(String(cents))
  const abs = value < 0n ? -value : value
  return `${value < 0n ? '-' : ''}${abs / 100n},${String(abs % 100n).padStart(2, '0')}`
}

export function currency(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—'
  try { return `R$ ${moneyInput(value)}` } catch { return String(value) }
}

export function recordLabel(source?: object): string {
  if (!source) return ''
  const row = source as Record<string, unknown>
  const pick = row.label || row.name || row.title || row.description || row.content || row.code
  if (pick) return String(pick)
  return String(row.year ?? row.id ?? '')
}

export function display(value: unknown, type?: string, refs?: Option[]): string {
  if (value === null || value === undefined || value === '') return '—'
  if (type === 'money') return currency(value)
  if (type === 'boolean' || typeof value === 'boolean') return value ? 'Sim' : 'Não'
  if (refs) return recordLabel(refs.find((r) => r.id === value)) || String(value)
  if (type === 'date' && /^\d{4}-\d{2}-\d{2}/.test(String(value))) return String(value).slice(0, 10).split('-').reverse().join('/')
  if (type === 'datetime-local' || (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value))) {
    const d = new Date(String(value))
    if (!Number.isNaN(d.getTime())) return d.toLocaleString('pt-BR')
  }
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

// <input type="datetime-local"> trabalha em horário local; o servidor guarda ISO/UTC.
export function localDateTimeInput(value: unknown): string {
  if (!value) return ''
  const d = new Date(String(value))
  if (Number.isNaN(d.getTime())) return ''
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
}

export function dateTimeToIso(value: string): string {
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) throw new Error('Informe uma data e um horário válidos.')
  return d.toISOString()
}

// Exportação CSV com proteção contra injeção de fórmula em planilhas.
function csvCell(value: unknown): string {
  let text = value === null || value === undefined ? '' : typeof value === 'object' ? JSON.stringify(value) : String(value)
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text)) text = `'${text}`
  return `"${text.replaceAll('"', '""')}"`
}

export function downloadCsv(columns: { key: string; label: string }[], rows: Record<string, unknown>[], name: string) {
  const text = [columns.map((c) => csvCell(c.label)).join(';'), ...rows.map((r) => columns.map((c) => csvCell(r[c.key])).join(';'))].join('\r\n')
  const url = URL.createObjectURL(new Blob(['﻿', text], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `${name}.csv`
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
