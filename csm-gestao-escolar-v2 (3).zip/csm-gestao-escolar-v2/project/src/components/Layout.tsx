import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import type { CatalogRoute, Role } from '../lib/types'
import { Icon } from './ui'

const ROLE_LABEL: Record<Role, string> = { admin: 'Administrador', secretaria: 'Secretaria', professor: 'Professor', financeiro: 'Financeiro' }

const GROUP_LABELS: Record<string, string> = {
  arquivos: 'Arquivos', regular: 'Ensino regular', lancamentos: 'Lançamentos', notas: 'Notas', 'ano-letivo': 'Ano letivo',
  'anos-anteriores': 'Anos anteriores', relatorios: 'Relatórios', graficos: 'Gráficos', cadastros: 'Cadastros', cursos: 'Cursos',
  outros: 'Outros', fechadas: 'Fechadas', parciais: 'Parciais', baixas: 'Baixas', boletos: 'Boletos', integracoes: 'Integrações',
  'notas-fiscais': 'Notas fiscais', 'outros-operacoes': 'Outras operações', acessos: 'Acessos', configuracoes: 'Configurações',
  'base-pesquisas': 'Base de pesquisas', 'cursos-estruturas': 'Cursos e estruturas', financeiro: 'Financeiro', aplicativos: 'Aplicativos',
  pedagogico: 'Pedagógico', geral: 'Geral', menu: 'Geral',
}

function routeGroup(route: CatalogRoute): string {
  if (route.group) return route.group
  const evidence = (route.navigationEvidence || '').split(' | ').find((v) => v.startsWith(route.module))
  const suffix = evidence?.slice(route.module.length + 1) || 'geral'
  const first = Object.keys(GROUP_LABELS).sort((a, b) => b.length - a.length).find((k) => suffix === k || suffix.startsWith(`${k}-`))
  return (first && GROUP_LABELS[first]) || 'Geral'
}

const norm = (s: string) => s.toLocaleLowerCase('pt-BR')

function MainNav() {
  const { catalog } = useApp()
  const [openId, setOpenId] = useState<string | null>(null)
  const [collapsed, setCollapsed] = useState(true)
  const [search, setSearch] = useState('')
  const navRef = useRef<HTMLElement>(null)
  const location = useLocation()

  useEffect(() => { setOpenId(null); setCollapsed(true); setSearch('') }, [location.pathname])
  useEffect(() => {
    const close = (e: Event) => { if (navRef.current && !navRef.current.contains(e.target as Node)) { setOpenId(null); setSearch('') } }
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpenId(null); setSearch('') } }
    document.addEventListener('pointerdown', close)
    document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('pointerdown', close); document.removeEventListener('keydown', esc) }
  }, [])

  const modules = catalog?.modules ?? []
  const groupsFor = useMemo(() => {
    const map = new Map<string, [string, CatalogRoute[]][]>()
    for (const m of modules) {
      const groups: Record<string, CatalogRoute[]> = {}
      for (const r of catalog!.routes.filter((r) => r.module === m.id)) (groups[routeGroup(r)] ||= []).push(r)
      map.set(m.id, Object.entries(groups))
    }
    return map
  }, [catalog, modules])

  return (
    <nav className="navbar navbar-default navbar-csm" aria-label="Módulos do sistema" ref={navRef}>
      <div className="container-fluid nav-fluid">
        <div className="navbar-header">
          <button type="button" className="navbar-toggle collapsed" aria-expanded={!collapsed} aria-controls="module-navigation" onClick={() => setCollapsed((c) => !c)}>
            <span className="sr-only">Alternar navegação</span>
            <span className="icon-bar" /><span className="icon-bar" /><span className="icon-bar" />
          </button>
          <Link className="navbar-brand navbar-home" to="/" aria-label="Página inicial"><Icon name="home" /></Link>
        </div>
        <div className={`collapse navbar-collapse${collapsed ? '' : ' in'}`} id="module-navigation">
          <ul className="nav navbar-nav navbar-modules">
            {modules.map((m, index) => {
              const open = openId === m.id
              const filtered = (groupsFor.get(m.id) ?? [])
                .map(([group, routes]) => [group, routes.filter((r) => norm(r.label).includes(norm(search)))] as [string, CatalogRoute[]])
                .filter(([, routes]) => routes.length)
              return (
                <li key={m.id} className={`dropdown${open ? ' open' : ''}`}>
                  <a href={`#${m.id}`} className="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded={open}
                    onClick={(e) => { e.preventDefault(); setOpenId(open ? null : m.id); setSearch('') }}>
                    {m.label} <span className="caret" />
                  </a>
                  {open && (
                    <ul className={`dropdown-menu mega-menu${index >= modules.length - 3 ? ' dropdown-menu-right' : ''}`} aria-label={`Menu ${m.label}`}>
                      <li className="menu-search">
                        <input type="search" className="form-control input-sm" value={search} autoFocus aria-label="Pesquisar no menu"
                          placeholder="Pesquisar opção neste módulo" onChange={(e) => setSearch(e.target.value)} />
                      </li>
                      {filtered.length ? filtered.map(([group, routes]) => (
                        <li key={group} className="menu-group">
                          <ul className="list-unstyled">
                            <li className="dropdown-header">{group} <span className="badge">{routes.length}</span></li>
                            {routes.map((r) => <li key={r.id}><NavLink to={r.path}>{r.label}</NavLink></li>)}
                          </ul>
                        </li>
                      )) : <li className="menu-empty text-muted">Nenhuma opção encontrada.</li>}
                    </ul>
                  )}
                </li>
              )
            })}
          </ul>
          <ul className="nav navbar-nav navbar-right">
            <li><NavLink to="/dashboard"><Icon name="dashboard" /> Dashboard</NavLink></li>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useApp()
  const [clock, setClock] = useState(() => new Date())
  const [busy, setBusy] = useState(false)
  const location = useLocation()
  const isHome = location.pathname === '/'

  useEffect(() => { const t = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(t) }, [])
  useEffect(() => { window.scrollTo(0, 0) }, [location.pathname])

  async function doLogout() {
    setBusy(true)
    try { await logout() } finally { setBusy(false) }
  }

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">Ir para o conteúdo</a>

      <div className="masthead no-print">
        <div className="row">
          <header className="col-md-7 institution-header">
            <Link to="/" className="logo-placeholder" aria-label="CSM, página inicial"><span>CSM</span><small>LOGOTIPO A CONFIGURAR</small></Link>
            <div className="institution-info">
              <strong>CSM · COLÉGIO SÃO MATEUS</strong>
              <span>Gestão Escolar · Ambiente local</span>
              <small>Endereço institucional a configurar</small>
            </div>
          </header>
          <div className="col-md-5 session-band">
            <div className="session-context">
              <strong>Colégio São Mateus</strong>
              <span>Ano letivo: consulta por filtro</span>
              <time dateTime={clock.toISOString()}>Horário local: {clock.toLocaleTimeString('pt-BR')}</time>
            </div>
            <div className="session-user">
              <span className="session-avatar"><Icon name="user" /></span>
              <div className="session-user-name">
                <strong>{user?.name}</strong>
                <span>{user ? ROLE_LABEL[user.role] : ''}</span>
              </div>
              <button type="button" className="btn btn-link btn-xs logout-button" onClick={doLogout} disabled={busy}>
                <Icon name="log-out" /> {busy ? 'Saindo…' : 'Sair'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="no-print"><MainNav /></div>
      <div className="institution-ribbon no-print"><Icon name="book" /> CSM · Gestão Escolar — ambiente local de demonstração</div>

      <main id="main-content" className={isHome ? 'home-content' : 'container-fluid main-content'} tabIndex={-1}>{children}</main>

      <footer className="site-footer no-print">
        <div><strong>CSM · Gestão Escolar</strong> <span>Projeto local independente · Dados de demonstração quando habilitados no servidor.</span></div>
        <span className="footer-right">Colégio São Mateus<br />Ambiente de desenvolvimento</span>
      </footer>
    </div>
  )
}
