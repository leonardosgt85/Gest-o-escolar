import { useRef, useState, type FormEvent } from 'react'
import { api } from '../lib/api'
import { currency, moneyInput, parseMoney } from '../lib/format'
import type { Row } from '../lib/types'
import { Alert } from './ui'

const METHODS = ['Dinheiro', 'Pix', 'Cartão', 'Transferência', 'Outro']

export default function PaymentForm({ invoice, onSaved, onCancel, onBusy }: {
  invoice: Row
  onSaved: () => void
  onCancel: () => void
  onBusy: (busy: boolean) => void
}) {
  const balance = invoice.balance_cents as number | undefined
  const [amount, setAmount] = useState(balance === undefined ? '' : moneyInput(balance))
  const [method, setMethod] = useState(METHODS[0])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  // A chave de idempotência só muda quando o conteúdo muda: repetir o envio
  // (duplo clique, retry de rede) nunca grava duas vezes.
  const attempt = useRef({ fingerprint: '', key: '' })

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError('')
    let cents: number
    try {
      cents = parseMoney(amount)
      if (cents <= 0) throw new Error('Informe um valor maior que zero.')
    } catch (err) { setError((err as Error).message); return }
    const fingerprint = JSON.stringify([invoice.id, cents, method])
    if (attempt.current.fingerprint !== fingerprint) attempt.current = { fingerprint, key: crypto.randomUUID() }
    setBusy(true)
    onBusy(true)
    try {
      await api('/finance/payments', { method: 'POST', body: { invoice_id: invoice.id, amount_cents: cents, method, idempotency_key: attempt.current.key } })
      onSaved()
    } catch (err) { setError((err as Error).message) }
    finally { setBusy(false); onBusy(false) }
  }

  return (
    <form onSubmit={submit}>
      <Alert kind="info">Recebimento local de demonstração. Registra a entrada no banco local; nenhum banco, boleto ou serviço fiscal é acionado. Recebimento parcial é permitido.</Alert>
      <p><strong>{String(invoice.description)}</strong></p>
      <p>Valor original: {currency(invoice.amount_cents)}{balance !== undefined && <> · Saldo: {currency(balance)}</>}</p>
      <Alert>{error}</Alert>
      <div className="row">
        <div className="col-sm-6">
          <div className="form-group">
            <label className="control-label" htmlFor="payment-amount">Valor recebido (R$)</label>
            <input id="payment-amount" className="form-control" inputMode="decimal" required value={amount} disabled={busy} onChange={(e) => setAmount(e.target.value)} />
            <span className="help-block">Sem separador de milhar. Até duas casas decimais.</span>
          </div>
        </div>
        <div className="col-sm-6">
          <div className="form-group">
            <label className="control-label" htmlFor="payment-method">Forma de recebimento</label>
            <select id="payment-method" className="form-control" value={method} disabled={busy} onChange={(e) => setMethod(e.target.value)}>
              {METHODS.map((o) => <option key={o}>{o}</option>)}
            </select>
          </div>
        </div>
      </div>
      <div className="modal-footer">
        <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Registrando…' : 'Registrar recebimento local'}</button>
        <button className="btn btn-default" type="button" disabled={busy} onClick={onCancel}>Cancelar</button>
      </div>
    </form>
  )
}
