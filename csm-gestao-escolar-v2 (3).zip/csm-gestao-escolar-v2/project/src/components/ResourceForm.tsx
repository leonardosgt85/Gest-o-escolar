import { useEffect, useRef, useState, type FormEvent } from 'react'
import { api, ApiRequestError } from '../lib/api'
import { dateTimeToIso, localDateTimeInput, moneyInput, parseMoney } from '../lib/format'
import useReferences from '../hooks/useReferences'
import type { Field, Resource, Role, Row } from '../lib/types'
import { Alert, FormGroup, Icon } from './ui'

type Values = Record<string, string | boolean>

function initialValues(fields: Field[], record: Row | null): Values {
  const values: Values = {}
  for (const f of fields) {
    const v = record?.[f.key]
    if (f.type === 'boolean') values[f.key] = v === undefined ? f.key === 'active' : Boolean(v)
    else if (f.type === 'password') values[f.key] = ''
    else if (f.type === 'money') values[f.key] = moneyInput(v)
    else if (f.type === 'date') values[f.key] = v ? String(v).slice(0, 10) : ''
    else if (f.type === 'datetime-local') values[f.key] = localDateTimeInput(v)
    else values[f.key] = v === null || v === undefined ? '' : String(v)
  }
  return values
}

export default function ResourceForm({ resource, record, role, onSaved, onCancel, onBusy }: {
  resource: Resource
  record: Row | null
  role: Role
  onSaved: () => void | Promise<void>
  onCancel: () => void
  onBusy: (busy: boolean) => void
}) {
  // Atribuição de professor só é editável pelo administrador
  const fields = resource.fields.filter((f) => f.key !== 'teacher_id' || role === 'admin')
  const [values, setValues] = useState<Values>(() => initialValues(fields, record))
  const [error, setError] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const focusError = useRef(false)
  const refs = useReferences(fields.map((f) => f.reference))

  useEffect(() => {
    if (!focusError.current || busy) return
    focusError.current = false
    const first = fields.find((f) => errors[f.key])
    ;(formRef.current?.elements.namedItem(first?.key ?? '') as HTMLElement | null)?.focus()
  }, [errors, busy, fields])

  const change = (key: string, value: string | boolean) => {
    setValues((c) => ({ ...c, [key]: value }))
    setErrors((c) => ({ ...c, [key]: '' }))
  }

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError('')
    const payload: Record<string, unknown> = {}
    const found: Record<string, string> = {}
    for (const f of fields) {
      const value = values[f.key]
      if (f.type === 'password' && record && !value) continue // senha em branco na edição = manter
      const empty = String(value ?? '').trim() === ''
      if ((f.required || (f.type === 'password' && !record)) && f.type !== 'boolean' && empty) { found[f.key] = 'Preencha este campo.'; continue }
      if (f.type === 'password') {
        if (String(value).length < 12) found[f.key] = 'A senha precisa ter pelo menos 12 caracteres.'
        else if (new TextEncoder().encode(String(value)).length > 72) found[f.key] = 'A senha excede 72 bytes. Reduza a quantidade de caracteres.'
        else payload[f.key] = value
      } else if (f.type === 'boolean') payload[f.key] = Boolean(value)
      else if (empty) payload[f.key] = null
      else if (f.type === 'money') { try { payload[f.key] = parseMoney(String(value)) } catch (err) { found[f.key] = (err as Error).message } }
      else if (f.type === 'datetime-local') { try { payload[f.key] = dateTimeToIso(String(value)) } catch (err) { found[f.key] = (err as Error).message } }
      else if (f.type === 'integer' || f.type === 'number') {
        const n = Number(String(value).replace(',', '.'))
        if (!Number.isFinite(n)) found[f.key] = 'Informe um número válido.'
        else payload[f.key] = n
      } else payload[f.key] = String(value)
    }
    if (Object.keys(found).length) { focusError.current = true; setErrors(found); return }

    setBusy(true)
    onBusy(true)
    try {
      if (record) await api(`/resources/${resource.key}/${record.id}`, { method: 'PUT', body: payload })
      else await api(`/resources/${resource.key}`, { method: 'POST', body: payload })
      await onSaved()
    } catch (err) {
      const apiErr = err as ApiRequestError
      if (apiErr.fields && Object.keys(apiErr.fields).length) { focusError.current = true; setErrors(apiErr.fields) }
      setError(apiErr.message)
    } finally {
      setBusy(false)
      onBusy(false)
    }
  }

  function control(f: Field) {
    const id = `field-${f.key}`
    const common = { id, name: f.key, disabled: busy, 'aria-invalid': errors[f.key] ? true : undefined, 'aria-describedby': errors[f.key] ? `${id}-error` : undefined }
    const value = values[f.key]
    if (f.type === 'textarea') return <textarea {...common} className="form-control" rows={4} value={String(value)} onChange={(e) => change(f.key, e.target.value)} />
    if (f.type === 'select') {
      return (
        <select {...common} className="form-control" value={String(value)} onChange={(e) => change(f.key, e.target.value)}>
          <option value="">Selecione</option>
          {(f.options || []).map((o) => <option key={o}>{o}</option>)}
        </select>
      )
    }
    if (f.type === 'reference') {
      return (
        <select {...common} className="form-control" value={String(value)} disabled={busy || refs.loading} onChange={(e) => change(f.key, e.target.value)}>
          <option value="">Selecione</option>
          {(refs.data[f.reference!] || []).map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
        </select>
      )
    }
    const type = f.type === 'datetime-local' ? 'datetime-local' : f.type === 'date' ? 'date' : f.type === 'email' ? 'email' : f.type === 'password' ? 'password' : 'text'
    const inputMode = f.type === 'money' || f.type === 'number' ? 'decimal' : f.type === 'integer' ? 'numeric' : undefined
    return <input {...common} className="form-control" type={type} inputMode={inputMode} autoComplete={f.type === 'password' ? 'new-password' : 'off'} value={String(value)} onChange={(e) => change(f.key, e.target.value)} />
  }

  return (
    <form onSubmit={submit} ref={formRef} noValidate>
      {resource.notice && <Alert kind="info">{resource.notice}</Alert>}
      <Alert>{error}</Alert>
      {refs.error && <Alert>Lista de referências indisponível: {refs.error}</Alert>}
      <div className="row">
        {fields.map((f) => {
          if (f.type === 'boolean') {
            return (
              <div className="col-sm-6" key={f.key}>
                <div className="checkbox form-group">
                  <label><input type="checkbox" name={f.key} checked={Boolean(values[f.key])} disabled={busy} onChange={(e) => change(f.key, e.target.checked)} /> {f.label}</label>
                </div>
              </div>
            )
          }
          const wide = f.type === 'textarea'
          return (
            <FormGroup key={f.key} id={`field-${f.key}`} className={wide ? 'col-sm-12' : 'col-sm-6'} error={errors[f.key]}
              hint={f.type === 'money' ? 'Valor em reais, sem separador de milhar (ex.: 1250,00).' : undefined}
              label={`${f.label}${f.required ? ' *' : ''}`}>
              {control(f)}
            </FormGroup>
          )
        })}
      </div>
      <div className="modal-footer">
        <button className="btn btn-primary" type="submit" disabled={busy}><Icon name="floppy-disk" /> {busy ? 'Salvando…' : 'Salvar'}</button>
        <button className="btn btn-default" type="button" disabled={busy} onClick={onCancel}>Cancelar</button>
      </div>
    </form>
  )
}
