import type { ChangeEvent, FormEvent } from 'react'
import useReferences from '../hooks/useReferences'
import { recordLabel } from '../lib/format'
import type { Role } from '../lib/types'
import { Alert, Icon } from './ui'

export const emptyStudentFilters = { course_id: '', guardian_id: '', code: '', cpf: '', name: '', enrollment_number: '', year: '', status: '' }
export type StudentFilterValues = typeof emptyStudentFilters

export default function StudentFilters({ values, onChange, onSearch, busy, role }: {
  values: StudentFilterValues
  onChange: (v: StudentFilterValues) => void
  onSearch: (e: FormEvent) => void
  busy: boolean
  role: Role
}) {
  // Só admin/secretaria podem listar responsáveis; para os demais o filtro some.
  const canFilterGuardians = role === 'admin' || role === 'secretaria'
  const refs = useReferences(['courses', canFilterGuardians ? 'guardians' : undefined])
  const change = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => onChange({ ...values, [e.target.name]: e.target.value })

  const text = (key: keyof StudentFilterValues, label: string, numeric = false) => (
    <div className="col-sm-6 col-md-3" key={key}>
      <div className="form-group">
        <label className="control-label" htmlFor={`filter-${key}`}>{label}</label>
        <input id={`filter-${key}`} className="form-control" name={key} value={values[key]} onChange={change} inputMode={numeric ? 'numeric' : undefined} />
      </div>
    </div>
  )

  return (
    <form onSubmit={onSearch} className="panel panel-default panel-filters">
      <div className="panel-heading">Filtros da consulta</div>
      <div className="panel-body">
        <div className="row">
          <div className="col-sm-6 col-md-3">
            <div className="form-group">
              <label className="control-label" htmlFor="filter-course">Curso</label>
              <select id="filter-course" className="form-control" name="course_id" value={values.course_id} onChange={change} disabled={refs.loading}>
                <option value="">Todos os cursos</option>
                {(refs.data.courses || []).map((r) => <option key={r.id} value={r.id}>{recordLabel(r)}</option>)}
              </select>
            </div>
          </div>
          {canFilterGuardians && (
            <div className="col-sm-6 col-md-3">
              <div className="form-group">
                <label className="control-label" htmlFor="filter-guardian">Responsável financeiro</label>
                <select id="filter-guardian" className="form-control" name="guardian_id" value={values.guardian_id} onChange={change} disabled={refs.loading}>
                  <option value="">Todos os responsáveis</option>
                  {(refs.data.guardians || []).map((r) => <option key={r.id} value={r.id}>{recordLabel(r)}</option>)}
                </select>
              </div>
            </div>
          )}
          {text('code', 'Código')}
          {text('cpf', 'CPF')}
          {text('name', 'Nome do aluno')}
          {text('enrollment_number', 'Matrícula')}
          {text('year', 'Ano', true)}
          <div className="col-sm-6 col-md-3">
            <div className="form-group">
              <label className="control-label" htmlFor="filter-status">Situação de matrícula</label>
              <select id="filter-status" className="form-control" name="status" value={values.status} onChange={change}>
                <option value="">Todas as situações</option>
                {['Aguardando deferimento', 'Cursando', 'Indeferida'].map((o) => <option key={o}>{o}</option>)}
              </select>
            </div>
          </div>
        </div>
        <button className="btn btn-primary" type="submit" disabled={busy}><Icon name="search" /> Pesquisar</button>{' '}
        <button className="btn btn-default" type="button" disabled={busy} onClick={() => onChange(emptyStudentFilters)}>Limpar filtros</button>
        <div className="top-gap"><Alert>{refs.error}</Alert></div>
      </div>
    </form>
  )
}
