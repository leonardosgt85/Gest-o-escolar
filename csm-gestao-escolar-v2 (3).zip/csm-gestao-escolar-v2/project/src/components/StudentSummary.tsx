import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { display } from '../lib/format'
import type { Row } from '../lib/types'
import { Alert, DataTable, Icon, Loading } from './ui'

interface Summary { student: Row; enrollments: Row[]; grades: Row[]; attendance: Row[]; documents: Row[] }

const LABELS: Record<string, string> = {
  id: 'ID', student_id: 'Aluno', class_id: 'Turma', class_name: 'Turma', year: 'Ano', enrolled_on: 'Data da matrícula', status: 'Situação',
  subject_id: 'Disciplina', subject_name: 'Disciplina', enrollment_id: 'Matrícula', lesson_id: 'Aula', date: 'Data', period: 'Período',
  value: 'Nota registrada', absent: 'Ausente', present: 'Presente', remarks: 'Observações', kind: 'Tipo', received: 'Recebido', description: 'Descrição',
}
const HIDDEN = ['created_at', 'updated_at', 'password_hash']

function Section({ title, rows }: { title: string; rows: Row[] }) {
  const keys = [...new Set(rows.flatMap((r) => Object.keys(r)))].filter((k) => !HIDDEN.includes(k))
  return (
    <section className="summary-section">
      <h4>{title}</h4>
      <DataTable columns={keys.length ? keys.map((k) => ({ key: k, label: LABELS[k] || k, type: k.endsWith('_on') || k === 'date' ? 'date' : undefined })) : [{ key: 'empty', label: 'Registros' }]} rows={rows} caption={title} />
    </section>
  )
}

export default function StudentSummary({ studentId }: { studentId: string }) {
  const [state, setState] = useState<{ loading: boolean; data: Summary | null; error: string }>({ loading: true, data: null, error: '' })

  useEffect(() => {
    const controller = new AbortController()
    api<{ data: Summary }>(`/documents/${studentId}/summary`, { signal: controller.signal })
      .then((r) => setState({ loading: false, data: r.data, error: '' }))
      .catch((e: Error) => { if (e.name !== 'AbortError') setState({ loading: false, data: null, error: e.message }) })
    return () => controller.abort()
  }, [studentId])

  const s = state.data
  return (
    <div>
      <Alert kind="info">Consulta de dados locais. Notas e frequência são exibidas como registradas, sem cálculo de média, aprovação ou emissão de histórico oficial.</Alert>
      {state.loading && <Loading />}
      <Alert>{state.error}</Alert>
      {s && (
        <>
          <div className="well well-sm">
            <h4>{String(s.student?.name || 'Dados do aluno')}</h4>
            <dl className="dl-horizontal dl-student">
              {([['code', 'Código'], ['enrollment_number', 'Matrícula'], ['cpf', 'CPF'], ['birth_date', 'Nascimento']] as const).map(([k, l]) => (
                <div key={k}><dt>{l}</dt><dd>{display(s.student?.[k], k === 'birth_date' ? 'date' : 'text')}</dd></div>
              ))}
            </dl>
          </div>
          <Section title="Matrículas" rows={s.enrollments} />
          <Section title="Notas registradas" rows={s.grades} />
          <Section title="Frequência registrada" rows={s.attendance} />
          <Section title="Controle de documentos" rows={s.documents} />
          <p className="text-muted small">Impressão de demonstração. Este documento não substitui o histórico escolar oficial ou documento assinado.</p>
          <button className="btn btn-default" type="button" onClick={() => window.print()}><Icon name="print" /> Imprimir consulta de demonstração</button>
        </>
      )}
    </div>
  )
}
