import { useEffect, useId, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { display } from '../lib/format'
import type { Option, Pagination, Row } from '../lib/types'

// Componentes finos sobre as classes do Bootstrap 3 (sem jQuery/JS do Bootstrap:
// dropdowns, modais e colapso são controlados pelo React).

export function Icon({ name, spin }: { name: string; spin?: boolean }) {
  return <span className={`glyphicon glyphicon-${name}${spin ? ' icon-spin' : ''}`} aria-hidden="true" />
}

export function Alert({ children, kind = 'danger' }: { children?: ReactNode; kind?: 'danger' | 'info' | 'success' | 'warning' }) {
  if (!children) return null
  return (
    <div className={`alert alert-${kind}`} role={kind === 'danger' ? 'alert' : 'status'}>
      {children}
    </div>
  )
}

export function Loading({ children = 'Carregando dados…' }: { children?: ReactNode }) {
  return (
    <p className="text-center text-muted loading-line" role="status">
      <Icon name="refresh" spin /> {children}
    </p>
  )
}

export function Breadcrumb({ items }: { items: string[] }) {
  return (
    <ol className="breadcrumb">
      {items.map((item, i) => (i === items.length - 1 ? <li key={item} className="active">{item}</li> : <li key={item}>{item}</li>))}
    </ol>
  )
}

export function PageHeader({ title, context, children }: { title: string; context?: string; children?: ReactNode }) {
  return (
    <div className="page-header">
      {context && <Breadcrumb items={context.split(' / ')} />}
      <h1>{title}</h1>
      {children}
    </div>
  )
}

export function Modal({ title, children, onClose, busy = false, large = false, returnFocus }: {
  title: string
  children: ReactNode
  onClose: () => void
  busy?: boolean
  large?: boolean
  returnFocus?: HTMLElement | null
}) {
  const ref = useRef<HTMLDivElement>(null)
  const titleId = useId()
  const closeRef = useRef(onClose)
  const busyRef = useRef(busy)
  closeRef.current = onClose
  busyRef.current = busy

  // Foco preso no diálogo, Esc fecha (exceto gravando) e o foco volta a quem abriu.
  useEffect(() => {
    const previous = returnFocus || (document.activeElement as HTMLElement | null)
    const dialog = ref.current!
    const focusable = () =>
      [...dialog.querySelectorAll<HTMLElement>('button, input, select, textarea, a[href], [tabindex="0"]')].filter(
        (el) => !(el as HTMLButtonElement).disabled && el.getClientRects().length,
      )
    ;(focusable().find((el) => !el.classList.contains('close')) || dialog).focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !busyRef.current) { e.preventDefault(); closeRef.current() }
      if (e.key !== 'Tab') return
      const list = focusable()
      const first = list[0]
      const last = list[list.length - 1]
      if (!first) { e.preventDefault(); dialog.focus() }
      else if (e.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { e.preventDefault(); last.focus() }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
    }
    document.body.classList.add('modal-open')
    document.addEventListener('keydown', onKey)
    return () => {
      document.body.classList.remove('modal-open')
      document.removeEventListener('keydown', onKey)
      if (previous?.isConnected) previous.focus()
    }
  }, [returnFocus])

  return createPortal(
    <>
      <div className="modal-backdrop fade in" />
      <div className="modal fade in" style={{ display: 'block' }} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} ref={ref}>
        <div className={`modal-dialog${large ? ' modal-lg' : ''}`}>
          <div className="modal-content">
            <div className="modal-header">
              <button type="button" className="close" aria-label="Fechar janela" onClick={onClose} disabled={busy}>
                <span aria-hidden="true">&times;</span>
              </button>
              <h4 className="modal-title" id={titleId}>{title}</h4>
            </div>
            <div className="modal-body">{children}</div>
          </div>
        </div>
      </div>
    </>,
    document.body,
  )
}

export interface Column {
  key: string
  label: string
  type?: string
  reference?: string
}

export function DataTable({ columns, rows, selected, onSelect, references = {}, empty = 'Nenhum registro encontrado.', caption }: {
  columns: Column[]
  rows: Row[]
  selected?: string | null
  onSelect?: (id: string) => void
  references?: Record<string, Option[]>
  empty?: string
  caption?: string
}) {
  return (
    <div className="table-responsive" role="region" aria-label={caption || 'Tabela de dados'} tabIndex={0}>
      <table className="table table-striped table-bordered table-hover table-condensed table-csm">
        <caption className="sr-only">{caption || 'Registros da consulta'}</caption>
        <thead>
          <tr>
            {onSelect && <th scope="col" className="text-center col-select">Selecionar</th>}
            {columns.map((c) => <th key={c.key} scope="col">{c.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {!rows.length ? (
            <tr><td colSpan={columns.length + (onSelect ? 1 : 0)} className="text-center text-muted empty-cell">{empty}</td></tr>
          ) : rows.map((row, i) => (
            <tr key={row.id || i} className={row.id === selected ? 'info' : undefined} aria-selected={onSelect ? row.id === selected : undefined}>
              {onSelect && (
                <td className="text-center col-select">
                  <input type="radio" name="selected-record" aria-label={`Selecionar ${String(row.name || row.description || row.code || `registro ${i + 1}`)}`} checked={row.id === selected} onChange={() => onSelect(row.id)} />
                </td>
              )}
              {columns.map((c) => <td key={c.key}>{display(row[c.key], c.type, c.reference ? references[c.reference] : undefined)}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function Pager({ pagination, onPage, disabled }: { pagination: Pagination | null; onPage: (page: number) => void; disabled?: boolean }) {
  if (!pagination) return null
  const pages = Math.max(1, Math.ceil(pagination.total / pagination.pageSize))
  return (
    <div className="clearfix pager-row">
      <span className="text-muted pull-left pager-info">{pagination.total} registro(s) · Página {pagination.page} de {pages}</span>
      <div className="btn-group pull-right">
        <button type="button" className="btn btn-default" disabled={disabled || pagination.page <= 1} onClick={() => onPage(pagination.page - 1)}>
          <Icon name="chevron-left" /> Anterior
        </button>
        <button type="button" className="btn btn-default" disabled={disabled || pagination.page >= pages} onClick={() => onPage(pagination.page + 1)}>
          Próxima <Icon name="chevron-right" />
        </button>
      </div>
    </div>
  )
}

export function FormGroup({ id, label, error, hint, children, className = 'col-sm-6' }: {
  id: string
  label: string
  error?: string
  hint?: string
  children: ReactNode
  className?: string
}) {
  return (
    <div className={className}>
      <div className={`form-group${error ? ' has-error' : ''}`}>
        <label className="control-label" htmlFor={id}>{label}</label>
        {children}
        {hint && !error && <span className="help-block">{hint}</span>}
        {error && <span className="help-block" id={`${id}-error`}>{error}</span>}
      </div>
    </div>
  )
}
