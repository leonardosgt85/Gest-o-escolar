import { useCallback, useEffect, useState, type ChangeEvent, type FormEvent } from 'react'
import { api, queryString } from '../lib/api'
import { downloadCsv, recordLabel } from '../lib/format'
import useReferences from '../hooks/useReferences'
import type { CatalogRoute, ReportData, User } from '../lib/types'
import { Alert, DataTable, Icon, Loading, PageHeader } from '../components/ui'

export default function ReportPage({ route, user }: { route: CatalogRoute & { moduleLabel?: string }; user: User }) {
  // Cada relatório só oferece os filtros que a API realmente usa
  const refFilters: [string, string, string][] = (['assets', 'payables'].includes(route.target ?? '')
    ? []
    : ([['class_id', 'Turma', 'classes'], ['student_id', 'Aluno', 'students']] as [string, string, string][])
  ).filter(([key]) => key !== 'class_id' || user.role !== 'financeiro')
  const refs = useReferences(refFilters.map(([, , r]) => r))
  const [filters, setFilters] = useState<Record<string, string>>({ year: '', class_id: '', student_id: '' })
  const [applied, setApplied] = useState<Record<string, string>>({})
  const [state, setState] = useState<{ loading: boolean; data: ReportData | null; error: string }>({ loading: true, data: null, error: '' })

  const load = useCallback(async (signal?: AbortSignal) => {
    setState((s) => ({ ...s, loading: true, error: '' }))
    try {
      const res = await api<{ data: ReportData }>(`/reports/${route.target}${queryString(applied)}`, { signal })
      setState({ loading: false, data: res.data, error: '' })
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setState({ loading: false, data: null, error: (e as Error).message })
    }
  }, [route.target, applied])

  useEffect(() => {
    const controller = new AbortController()
    load(controller.signal)
    return () => controller.abort()
  }, [load])

  const change = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setFilters((f) => ({ ...f, [e.target.name]: e.target.value }))
  const submit = (e: FormEvent) => {
    e.preventDefault()
    setApplied({ year: filters.year, ...Object.fromEntries(refFilters.map(([key]) => [key, filters[key]])) })
  }
  const d = state.data

  return (
    <>
      <PageHeader title={route.label} context={`${route.moduleLabel} / Relatórios`} />
      <Alert kind="info">{route.notice || 'Relatório local de demonstração. Dados calculados a partir do banco local.'} Nenhuma média ou aprovação escolar é calculada automaticamente.</Alert>

      <form className="panel panel-default panel-filters" onSubmit={submit}>
        <div className="panel-heading">Filtros do relatório</div>
        <div className="panel-body">
          <div className="row">
            <div className="col-sm-3">
              <div className="form-group">
                <label className="control-label" htmlFor="report-year">Ano</label>
                <input id="report-year" className="form-control" name="year" inputMode="numeric" pattern="[0-9]{4}" placeholder="Todos" value={filters.year} onChange={change} />
              </div>
            </div>
            {refFilters.map(([key, label, resource]) => (
              <div className="col-sm-4" key={key}>
                <div className="form-group">
                  <label className="control-label" htmlFor={`report-${key}`}>{label}</label>
                  <select id={`report-${key}`} className="form-control" name={key} value={filters[key]} disabled={refs.loading} onChange={change}>
                    <option value="">Todos</option>
                    {(refs.data[resource] || []).map((r) => <option key={r.id} value={r.id}>{recordLabel(r)}</option>)}
                  </select>
                </div>
              </div>
            ))}
          </div>
          <button className="btn btn-primary" type="submit" disabled={state.loading}><Icon name="search" /> Pesquisar</button>
        </div>
      </form>

      <Alert>{refs.error}</Alert>
      <Alert>{state.error}</Alert>
      {state.loading && <Loading />}
      {d && !state.loading && (
        <>
          <div className="clearfix toolbar">
            <h3 className="pull-left report-title">{d.title}</h3>
            <div className="pull-right">
              <button className="btn btn-default" type="button" onClick={() => downloadCsv(d.columns, d.rows, `relatorio-${route.id.toLowerCase()}`)}><Icon name="download-alt" /> Exportar CSV</button>{' '}
              <button className="btn btn-default" type="button" onClick={() => window.print()}><Icon name="print" /> Imprimir</button>
            </div>
          </div>
          {d.notice && <Alert kind="info">{d.notice}</Alert>}
          <DataTable columns={d.columns.map((c) => ({ ...c, type: /_cents$/.test(c.key) ? 'money' : c.key === 'date' || c.key.endsWith('_on') ? 'date' : undefined }))} rows={d.rows} caption={d.title} />
          <p className="help-block">{d.rows.length} registro(s) retornado(s). Exportação CSV com proteção contra fórmulas de planilha. Impressão de demonstração, sem valor de documento oficial.</p>
        </>
      )}
    </>
  )
}
