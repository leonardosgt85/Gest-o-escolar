import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react'
import { api, queryString } from '../lib/api'
import useReferences from '../hooks/useReferences'
import type { CatalogRoute, Pagination, Resource, Role, Row, User } from '../lib/types'
import { Alert, DataTable, Icon, Loading, Modal, PageHeader, Pager, type Column } from '../components/ui'
import ResourceForm from '../components/ResourceForm'
import StudentFilters, { emptyStudentFilters } from '../components/StudentFilters'
import StudentSummary from '../components/StudentSummary'
import PaymentForm from '../components/PaymentForm'

// Espelha services/policyService.js: o botão só aparece se o perfil pode gravar
// (o backend continua sendo quem decide).
const WRITE: Partial<Record<Role, string[]>> = {
  secretaria: ['students', 'guardians', 'guardian_links', 'courses', 'academic_years', 'classes', 'subjects', 'enrollments', 'lessons', 'attendance', 'grades', 'occurrences', 'events', 'contracts', 'documents', 'messages', 'lookup_entries'],
  professor: ['lessons', 'attendance', 'grades', 'occurrences'],
  financeiro: ['invoices', 'accounts', 'vendors', 'payables'],
}

type DialogKind = 'new' | 'edit' | 'delete' | 'summary' | 'payment' | null

export default function ResourcePage({ resource, route, user }: { resource: Resource; route?: CatalogRoute & { moduleLabel?: string }; user: User }) {
  const [state, setState] = useState<{ rows: Row[]; pagination: Pagination | null; loading: boolean; error: string }>({ rows: [], pagination: null, loading: true, error: '' })
  const [search, setSearch] = useState('')
  const [filters, setFilters] = useState(emptyStudentFilters)
  const [applied, setApplied] = useState<Record<string, string>>({})
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState<string | null>(null)
  const [dialog, setDialog] = useState<DialogKind>(null)
  const [busy, setBusy] = useState(false)
  const [modalError, setModalError] = useState('')
  const [success, setSuccess] = useState('')
  const invoker = useRef<HTMLElement | null>(null)

  const fields = resource.fields.filter((f) => f.type !== 'password' && (f.key !== 'teacher_id' || user.role === 'admin'))
  const refs = useReferences(fields.map((f) => f.reference))
  const canWrite = user.role === 'admin' || Boolean(WRITE[user.role]?.includes(resource.key))
  const canReceive = resource.key === 'invoices' && ['admin', 'financeiro'].includes(user.role)
  const canSummary = resource.key === 'students' && ['admin', 'secretaria'].includes(user.role)
  const row = state.rows.find((r) => r.id === selected)
  const rowName = String(row?.name || row?.description || row?.code || 'registro selecionado')

  const load = useCallback(async (signal?: AbortSignal) => {
    setState((s) => ({ ...s, loading: true, error: '' }))
    try {
      const res = await api<{ data: Row[]; pagination: Pagination }>(`/resources/${resource.key}${queryString({ ...applied, page, pageSize: 25 })}`, { signal })
      setState({ rows: res.data, pagination: res.pagination, loading: false, error: '' })
      setSelected(null)
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setState({ rows: [], pagination: null, loading: false, error: (e as Error).message })
    }
  }, [resource.key, applied, page])

  useEffect(() => {
    const controller = new AbortController()
    load(controller.signal)
    return () => controller.abort()
  }, [load])

  function apply(e: FormEvent) {
    e.preventDefault()
    setApplied(resource.key === 'students' ? { ...filters } : { search })
    setPage(1)
    setSuccess('')
  }
  function open(kind: DialogKind, el: HTMLElement) { invoker.current = el; setModalError(''); setDialog(kind) }
  function close() { if (!busy) { setDialog(null); setModalError('') } }

  async function remove() {
    setBusy(true)
    setModalError('')
    try {
      await api(`/resources/${resource.key}/${selected}`, { method: 'DELETE' })
      setDialog(null)
      setSuccess('Registro excluído e consulta atualizada.')
      if (state.rows.length === 1 && page > 1) setPage(page - 1)
      else await load()
    } catch (e) { setModalError((e as Error).message) }
    finally { setBusy(false) }
  }

  const columns: Column[] = fields.slice(0, resource.key === 'students' ? 7 : 8).map((f) => ({ key: f.key, label: f.label, type: f.type, reference: f.reference }))
  if (resource.key === 'invoices') columns.push({ key: 'balance_cents', label: 'Saldo (R$)', type: 'money' })
  const notice = route?.notice || resource.notice

  return (
    <>
      <PageHeader title={route?.label || resource.label} context={`${route?.moduleLabel || 'Cadastros'} / ${resource.label}`} />
      {notice && <Alert kind="info">{notice}</Alert>}

      {resource.key === 'students' ? (
        <StudentFilters values={filters} onChange={setFilters} onSearch={apply} busy={state.loading} role={user.role} />
      ) : (
        <form className="well well-sm form-inline search-well" onSubmit={apply}>
          <div className="form-group">
            <label className="control-label" htmlFor="resource-search">Pesquisar em {resource.label.toLocaleLowerCase('pt-BR')}</label>{' '}
            <input id="resource-search" className="form-control search-input" type="search" value={search} placeholder="Digite um termo para pesquisar" onChange={(e) => setSearch(e.target.value)} />
          </div>{' '}
          <button className="btn btn-primary" type="submit" disabled={state.loading}><Icon name="search" /> Pesquisar</button>
        </form>
      )}

      <div className="toolbar clearfix" role="toolbar" aria-label="Ações da consulta">
        <div className="pull-left btn-toolbar-csm">
          {canWrite && (
            <>
              <button className="btn btn-primary" type="button" onClick={(e) => open('new', e.currentTarget)}><Icon name="plus" /> Novo</button>{' '}
              <button className="btn btn-default" type="button" disabled={!row || state.loading} onClick={(e) => open('edit', e.currentTarget)}><Icon name="pencil" /> Editar</button>{' '}
              <button className="btn btn-danger" type="button" disabled={!row || state.loading} onClick={(e) => open('delete', e.currentTarget)}><Icon name="trash" /> Excluir</button>{' '}
            </>
          )}
          {canSummary && <><button className="btn btn-default" type="button" disabled={!row || state.loading} onClick={(e) => open('summary', e.currentTarget)}><Icon name="list-alt" /> Detalhes do aluno</button>{' '}</>}
          {canReceive && <button className="btn btn-success" type="button" disabled={!row || state.loading} onClick={(e) => open('payment', e.currentTarget)}><Icon name="usd" /> Receber</button>}
        </div>
        <button className="btn btn-default pull-right" type="button" disabled={state.loading} onClick={() => load()}><Icon name="refresh" /> Atualizar</button>
      </div>

      <Alert kind="success">{success}</Alert>
      <Alert>{state.error}</Alert>
      {refs.error && <Alert>Rótulos de referências indisponíveis: {refs.error}</Alert>}
      {state.loading ? <Loading /> : <DataTable columns={columns} rows={state.rows} references={refs.data} selected={selected} onSelect={setSelected} caption={`Consulta de ${resource.label}`} />}
      <Pager pagination={state.pagination} onPage={setPage} disabled={state.loading} />
      <p className="help-block">Selecione um registro na primeira coluna para habilitar as ações disponíveis ao seu perfil.</p>

      {(dialog === 'new' || dialog === 'edit') && (
        <Modal large title={`${dialog === 'new' ? 'Novo registro' : 'Editar registro'} · ${resource.label}`} onClose={close} busy={busy} returnFocus={invoker.current}>
          <ResourceForm resource={resource} record={dialog === 'edit' ? row ?? null : null} role={user.role} onBusy={setBusy} onCancel={close}
            onSaved={async () => { setDialog(null); setSuccess('Registro salvo e conferido em nova consulta ao servidor.'); await load() }} />
        </Modal>
      )}
      {dialog === 'delete' && row && (
        <Modal title="Excluir registro" onClose={close} busy={busy} returnFocus={invoker.current}>
          <Alert kind="warning">Confirme a exclusão de <strong>{rowName}</strong>. Cadastros vinculados podem impedir a operação por integridade.</Alert>
          <Alert>{modalError}</Alert>
          <div className="modal-footer">
            <button className="btn btn-danger" type="button" disabled={busy} onClick={remove}>{busy ? 'Excluindo…' : 'Confirmar exclusão'}</button>
            <button className="btn btn-default" type="button" disabled={busy} onClick={close}>Cancelar</button>
          </div>
        </Modal>
      )}
      {dialog === 'summary' && row && canSummary && (
        <Modal large title={`Consulta do aluno · ${rowName}`} onClose={close} returnFocus={invoker.current}><StudentSummary studentId={row.id} /></Modal>
      )}
      {dialog === 'payment' && row && (
        <Modal title="Recebimento local de demonstração" onClose={close} busy={busy} returnFocus={invoker.current}>
          <PaymentForm invoice={row} onBusy={setBusy} onCancel={close} onSaved={() => { setDialog(null); setSuccess('Recebimento registrado no banco local. Consulta atualizada.'); load() }} />
        </Modal>
      )}
    </>
  )
}
