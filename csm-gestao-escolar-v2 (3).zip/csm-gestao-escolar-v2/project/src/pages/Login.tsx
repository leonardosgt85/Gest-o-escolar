import { useState, type FormEvent } from 'react'
import { useApp } from '../context/AppContext'
import { Alert, Icon } from '../components/ui'

export default function Login() {
  const { login, notice } = useApp()
  const [email, setEmail] = useState('admin@school.local')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError('')
    try { await login(email, password) }
    catch (err) { setError((err as Error).message) }
    finally { setBusy(false) }
  }

  return (
    <div className="login-page">
      <div className="login-institution text-center">
        <div className="logo-placeholder"><span>CSM</span><small>LOGOTIPO A CONFIGURAR</small></div>
        <h1>COLÉGIO SÃO MATEUS</h1>
        <p>Sistema de Gestão Escolar</p>
      </div>
      <div className="panel panel-primary login-panel">
        <div className="panel-heading"><h2 className="panel-title"><Icon name="lock" /> Acesso ao sistema</h2></div>
        <form className="panel-body" onSubmit={submit}>
          <Alert kind="info">{notice}</Alert>
          <Alert>{error}</Alert>
          <div className="form-group">
            <label className="control-label" htmlFor="login-email">E-mail</label>
            <input id="login-email" className="form-control input-lg" type="email" autoComplete="username" value={email} disabled={busy} required onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="control-label" htmlFor="login-password">Senha</label>
            <input id="login-password" className="form-control input-lg" type="password" autoComplete="current-password" value={password} disabled={busy} required onChange={(e) => setPassword(e.target.value)} />
          </div>
          <button className="btn btn-primary btn-lg btn-block" type="submit" disabled={busy}><Icon name="log-in" /> {busy ? 'Entrando…' : 'Entrar'}</button>
        </form>
        <div className="panel-footer text-center small text-muted">Ambiente local de demonstração. Não use dados reais de alunos ou responsáveis.</div>
      </div>
    </div>
  )
}
