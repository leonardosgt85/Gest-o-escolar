import type { CatalogRoute } from '../lib/types'
import { Alert, Icon, PageHeader } from '../components/ui'

function dependency(route: CatalogRoute): string {
  const label = route.label.toLocaleLowerCase('pt-BR')
  if (/carteirinha|document|histórico|certific|diploma/.test(label)) return 'Definição do modelo institucional, campos obrigatórios, regras de emissão e validação do documento pela escola.'
  if (/nota|média|progressão|replicar|fechamento|avalia/.test(label)) return 'Validação das regras pedagógicas, períodos de avaliação, cálculos e efeitos sobre os registros dos alunos.'
  if (/matrícul|remaneja|turma|ensalam/.test(label)) return 'Definição das regras de matrícula, vínculos, capacidade e tratamento dos registros existentes antes de operações em lote.'
  if (/crm|contato|mensage|sms|email|e-mail/.test(label)) return 'Definição do processo de atendimento e configuração autorizada dos canais de comunicação externos.'
  if (/finance|contáb|boleto|banco|cheque|fiscal|remessa|baixa|pagamento/.test(label)) return 'Especificação das regras financeiras e configuração de serviços bancários ou fiscais, com validação antes de qualquer movimentação.'
  return 'Inspeção do fluxo completo, definição dos campos e regras com a escola e validação dos efeitos sobre os dados antes da implementação.'
}

export default function PendingPage({ route }: { route: CatalogRoute & { moduleLabel?: string } }) {
  return (
    <>
      <PageHeader title={route.label} context={`${route.moduleLabel} / ${route.group || 'Rotinas'}`} />
      <div className="panel panel-default pending-panel">
        <div className="panel-body media">
          <div className="media-left"><Icon name="list-alt" /></div>
          <div className="media-body">
            <h3 className="media-heading">Fluxo ainda não implementado</h3>
            <p>O item <strong>{route.label}</strong> foi identificado no menu de referência. Sua operação completa não foi inspecionada, e não há ação disponível nesta página.</p>
            <dl>
              <dt>Referência de navegação</dt><dd>{route.id} · {route.moduleLabel}</dd>
              <dt>Dependência para implementação</dt><dd>{dependency(route)}</dd>
            </dl>
          </div>
        </div>
      </div>
      <Alert kind="info">Nenhum dado foi alterado ao abrir esta página. Esta área permanece pendente de especificação e validação.</Alert>
    </>
  )
}
