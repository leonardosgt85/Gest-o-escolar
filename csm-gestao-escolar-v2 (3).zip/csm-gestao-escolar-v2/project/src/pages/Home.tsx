import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { Icon } from '../components/ui'

export default function Home() {
  const { catalog } = useApp()
  return (
    <div className="home-page">
      <h1 className="sr-only">Gestão Escolar · Colégio São Mateus</h1>
      {/* Substitua este bloco por <img> quando houver arquivo autorizado (ver README) */}
      <section className="home-banner text-center" aria-label="Espaço reservado para ilustração institucional">
        <div className="banner-icons"><Icon name="education" /> <Icon name="book" /></div>
        <p className="banner-title">Ilustração institucional</p>
        <p className="text-muted">Espaço reservado. A imagem original não foi reproduzida.</p>
        <small className="text-muted">AMBIENTE LOCAL DE DEMONSTRAÇÃO</small>
      </section>
      <div className="container-fluid home-shortcuts">
        <div className="page-header page-header-sm clearfix">
          <h2 className="pull-left"><Icon name="stats" /> Acesso aos cadastros locais</h2>
          <Link className="btn btn-default pull-right" to="/dashboard"><Icon name="dashboard" /> Acessar visão geral</Link>
        </div>
        <div className="row shortcut-row">
          {Object.values(catalog?.resources ?? {}).map((r) => (
            <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3" key={r.key}>
              <Link className="list-group-item shortcut" to={`/cadastros/${r.key}`}>{r.label} <Icon name="arrow-right" /></Link>
            </div>
          ))}
        </div>
        <div className="well well-sm">
          <strong>Ambiente local de demonstração</strong><br />
          Consulte os avisos de cada tela. Integrações, documentos e operações bancárias dependem de serviços próprios e não são simulados como concluídos.
        </div>
      </div>
    </div>
  )
}
