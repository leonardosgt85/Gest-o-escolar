import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { api } from '../lib/api'
import type { CatalogRoute, Row } from '../lib/types'
import { Alert, DataTable, Icon, Loading, PageHeader } from '../components/ui'

export default function IntegrationPage({ route }: { route: CatalogRoute & { moduleLabel?: string } }) {
  const [details, setDetails] = useState('')
  const [rows, setRows] = useState<Row[]>([])
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async (signal?: AbortSignal) => {
    setLoading(true)
    try {
      const res = await api<{ data: Row[] }>('/integrations/jobs', { signal })
      setRows(res.data.filter((r) => r.route_id === route.id))
    } catch (e) { if ((e as Error).name !== 'AbortError') setError((e as Error).message) }
    finally { if (!signal?.aborted) setLoading(false) }
  }, [route.id])

  useEffect(() => {
    const controller = new AbortController()
    load(controller.signal)
    return () => controller.abort()
  }, [load])

  async function submit(e: FormEvent) {
    e.preventDefault()
    setBusy(true); setError(''); setSuccess('')
    try {
      const saved = await api<{ data: Row }>('/integrations/jobs', { method: 'POST', body: { route_id: route.id, payload: { description: details.trim() } } })
      const list = await api<{ data: Row[] }>('/integrations/jobs')
      setRows(list.data.filter((r) => r.route_id === route.id))
      const persisted = list.data.some((r) => r.id === saved.data.id)
      setSuccess(persisted
        ? 'Solicitação salva e conferida no banco local, pendente de integração. Nenhum serviço externo foi acionado.'
        : 'O servidor aceitou a solicitação, mas a releitura não confirmou o registro. Atualize a consulta antes de repetir.')
      if (persisted) setDetails('')
    } catch (err) { setError((err as Error).message) }
    finally { setBusy(false) }
  }

  return (
    <>
      <PageHeader title={route.label} context={`${route.moduleLabel} / Integrações`} />
      <Alert kind="info">Este fluxo depende de uma integração externa ainda não configurada. Esta página somente salva uma solicitação local com situação pendente. Nenhum envio, importação, baixa, assinatura ou operação bancária é realizado.</Alert>
      {route.notice && <Alert kind="info">{route.notice}</Alert>}
      <form className="panel panel-default" onSubmit={submit}>
        <div className="panel-heading">Registrar solicitação local</div>
        <div className="panel-body">
          <div className="form-group">
            <label className="control-label" htmlFor="integration-details">Detalhes da solicitação</label>
            <textarea id="integration-details" className="form-control" rows={4} maxLength={5000} required disabled={busy} value={details}
              placeholder="Descreva o que precisa ser integrado. Não inclua senhas ou credenciais." onChange={(e) => setDetails(e.target.value)} />
          </div>
          <button className="btn btn-primary" type="submit" disabled={busy || !details.trim()}><Icon name="floppy-disk" /> {busy ? 'Salvando…' : 'Salvar solicitação local'}</button>
        </div>
      </form>
      <Alert>{error}</Alert>
      <Alert kind="success">{success}</Alert>
      <h3>Solicitações locais deste fluxo</h3>
      {loading ? <Loading /> : (
        <DataTable columns={[{ key: 'id', label: 'Protocolo local' }, { key: 'status', label: 'Situação' }, { key: 'payload', label: 'Dados solicitados' }, { key: 'created_at', label: 'Registrado em', type: 'datetime-local' }]}
          rows={rows} caption="Solicitações de integração" empty="Nenhuma solicitação local para este fluxo." />
      )}
    </>
  )
}
