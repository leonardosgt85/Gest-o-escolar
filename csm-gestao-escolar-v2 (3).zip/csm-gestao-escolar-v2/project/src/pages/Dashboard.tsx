import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { currency } from '../lib/format'
import { Alert, Loading, PageHeader } from '../components/ui'

const METRICS: [string, string, boolean?][] = [
  ['students', 'Alunos cadastrados'], ['guardians', 'Responsáveis cadastrados'], ['enrollments', 'Matrículas'],
  ['pendingInvoices', 'Cobranças em aberto'], ['totalReceivableCents', 'Total a receber', true],
  ['receivedCents', 'Recebimentos locais', true], ['assets', 'Bens patrimoniais'],
]

export default function Dashboard() {
  const [state, setState] = useState<{ loading: boolean; data: Record<string, number | null> | null; error: string }>({ loading: true, data: null, error: '' })

  useEffect(() => {
    const controller = new AbortController()
    api<{ data: Record<string, number | null> }>('/dashboard', { signal: controller.signal })
      .then((r) => setState({ loading: false, data: r.data, error: '' }))
      .catch((e: Error) => { if (e.name !== 'AbortError') setState({ loading: false, data: null, error: e.message }) })
    return () => controller.abort()
  }, [])

  return (
    <>
      <PageHeader title="Visão geral" context="Início / Dashboard" />
      <Alert kind="info">Indicadores calculados a partir dos registros disponíveis ao seu perfil. Valores financeiros representam somente lançamentos locais.</Alert>
      {state.loading && <Loading />}
      <Alert>{state.error}</Alert>
      {state.data && (
        <div className="row">
          {METRICS.filter(([key]) => state.data![key] !== undefined).map(([key, label, money]) => (
            <div className="col-sm-6 col-md-4" key={key}>
              <div className="panel panel-info metric">
                <div className="panel-heading">{label}</div>
                <div className="panel-body">
                  <strong className="metric-value">
                    {state.data![key] === null ? <small className="text-muted">Indisponível neste perfil</small> : money ? currency(state.data![key]) : String(state.data![key])}
                  </strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  )
}
