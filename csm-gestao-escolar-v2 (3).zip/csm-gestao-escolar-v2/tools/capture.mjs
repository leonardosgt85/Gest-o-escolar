// Captura as telas deste projeto (frontend + backend rodando) para comparar com referencia/.
// Uso:  npm i -D playwright && npx playwright install chromium   (uma vez, na raiz)
//       node tools/capture.mjs [baseUrl]            ex.: http://localhost:5173
import { chromium } from 'playwright'
import { mkdirSync } from 'node:fs'

const base = process.argv[2] || 'http://localhost:5173'
const out = new URL('../referencia/capturas/', import.meta.url).pathname
mkdirSync(out, { recursive: true })

const routes = [
  ['home', '/'], ['alunos', '/cadastros/students'], ['cobrancas', '/cadastros/invoices'],
  ['relatorio', '/sistema/mh-003'], ['pendente', '/sistema/mh-002'], ['dashboard', '/dashboard'],
]
const sizes = [[1280, 800], [390, 800]]

const browser = await chromium.launch()
for (const [w, h] of sizes) {
  const page = await (await browser.newContext({ viewport: { width: w, height: h } })).newPage()
  await page.goto(base)
  await page.fill('#login-password', process.env.CSM_PASSWORD || 'AdminDev!123')
  await page.click('button[type=submit]')
  await page.waitForSelector('.institution-header')
  for (const [name, path] of routes) {
    await page.goto(base + path)
    await page.waitForLoadState('networkidle')
    await page.screenshot({ path: `${out}${name}-${w}.png`, fullPage: true })
  }
}
await browser.close()
console.log('Capturas em', out)
