require('dotenv').config({ quiet: true })

// Sem senha cravada no código: se DB_PASSWORD não estiver no .env o Postgres
// recusa a conexão e o erro deixa isso claro.
if (!process.env.DB_PASSWORD && !process.env.DATABASE_URL && process.env.NODE_ENV !== 'test') {
  console.warn('⚠️  DB_PASSWORD (ou DATABASE_URL) não definido — configure o .env antes de rodar.')
}

const connection = process.env.DATABASE_URL || {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'school',
}

const base = {
  client: 'pg',
  connection,
  migrations: { directory: './src/db/migrations', tableName: 'knex_migrations' },
  seeds: { directory: './src/db/seeds' },
}

module.exports = {
  development: { ...base, pool: { min: 0, max: 10 } },
  // Testes usam um banco separado (<DB_NAME>_test) ou TEST_DATABASE_URL
  test: {
    ...base,
    connection: process.env.TEST_DATABASE_URL || {
      ...(typeof connection === 'object' ? connection : {}),
      database: (process.env.DB_NAME || 'school') + '_test',
    },
    pool: { min: 0, max: 4 },
  },
  production: { ...base, pool: { min: 2, max: 20 } },
}
