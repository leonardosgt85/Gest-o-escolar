// Testes de integração: Express + Knex + PostgreSQL reais (banco <DB_NAME>_test).
// Rode com:  NODE_ENV=test DB_PASSWORD=... npm test
process.env.NODE_ENV = 'test'
process.env.SEED_DEMO = '1'
process.env.FRONTEND_URL = 'http://localhost:5173'
process.env.SERVE_FRONTEND = '0'

const request = require('supertest')
const db = require('../src/config/db')
const app = require('../src/app')
const { demoIds } = require('../src/db/demoData')

const ORIGIN = 'http://localhost:5173'

async function login(email = 'admin@school.local', password = 'AdminDev!123') {
  const agent = request.agent(app)
  const res = await agent.post('/api/auth/login').set('Origin', ORIGIN).send({ email, password })
  return { agent, res }
}
const write = (actor, method, url, body) => actor.agent[method](url).set('Origin', ORIGIN).send(body)

let admin, teacher, finance, secretary

beforeAll(async () => {
  await db.migrate.rollback(undefined, true)
  await db.migrate.latest()
  await db.seed.run()
  admin = await login()
  teacher = await login('professor@school.local', 'ProfessorDev!123')
  finance = await login('financeiro@school.local', 'FinanceiroDev!123')
  secretary = await login('secretaria@school.local', 'SecretariaDev!123')
})
afterAll(async () => { await db.destroy() })

describe('autenticação', () => {
  test('login correto devolve usuário sem hash e cookie httpOnly', async () => {
    expect(admin.res.status).toBe(200)
    expect(admin.res.body.user).toEqual(expect.objectContaining({ email: 'admin@school.local', role: 'admin' }))
    expect(JSON.stringify(admin.res.body)).not.toMatch(/hash|password/i)
    expect(admin.res.headers['set-cookie'][0]).toMatch(/csm_session=.*HttpOnly/i)
    const me = await admin.agent.get('/api/auth/me')
    expect(me.body.user.role).toBe('admin')
  })
  test('senha errada, e-mail inexistente e corpo malformado são negados', async () => {
    const bad = await request(app).post('/api/auth/login').set('Origin', ORIGIN).send({ email: 'admin@school.local', password: 'errada' })
    expect(bad.status).toBe(401)
    const none = await request(app).post('/api/auth/login').set('Origin', ORIGIN).send({ email: 'nao@existe.com', password: 'qualquer' })
    expect(none.status).toBe(401)
    expect(none.body.error).toBe(bad.body.error)
    const malformed = await request(app).post('/api/auth/login').set('Origin', ORIGIN).send({ email: 'x' })
    expect(malformed.status).toBe(422)
  })
  test('sem cookie ou com cookie forjado, a API nega', async () => {
    expect((await request(app).get('/api/resources/students')).status).toBe(401)
    expect((await request(app).get('/api/auth/me').set('Cookie', 'csm_session=forjado')).status).toBe(401)
  })
  test('logout revoga a sessão no banco', async () => {
    const tmp = await login()
    expect((await tmp.agent.get('/api/auth/me')).status).toBe(200)
    expect((await write(tmp, 'post', '/api/auth/logout')).status).toBe(204)
    expect((await tmp.agent.get('/api/auth/me')).status).toBe(401)
  })
  test('escrita de origem estrangeira ou sem Origin é negada sem gravar', async () => {
    const before = Number((await db('courses').count({ n: '*' }).first()).n)
    const body = { code: 'ORIG-1', name: 'Curso origem', level: 'Fundamental' }
    expect((await admin.agent.post('/api/resources/courses').send(body)).status).toBe(403)
    expect((await admin.agent.post('/api/resources/courses').set('Origin', 'http://evil.example').send(body)).status).toBe(403)
    expect(Number((await db('courses').count({ n: '*' }).first()).n)).toBe(before)
  })
})

describe('catálogo e perfis', () => {
  test('catálogo expõe 176 rotas e 23 cadastros', async () => {
    const r = await admin.agent.get('/api/catalog')
    expect(r.status).toBe(200)
    expect(r.body.data.routes).toHaveLength(176)
    expect(Object.keys(r.body.data.resources)).toHaveLength(23)
  })
  test('perfis acessam apenas seus domínios', async () => {
    expect((await secretary.agent.get('/api/resources/invoices')).status).toBe(403)
    expect((await finance.agent.get('/api/resources/students')).status).toBe(403)
    expect((await finance.agent.get('/api/resources/invoices')).status).toBe(200)
    expect((await teacher.agent.get('/api/resources/students')).status).toBe(200)
    expect((await write(teacher, 'post', '/api/resources/courses', { code: 'X', name: 'X', level: 'Fundamental' })).status).toBe(403)
    expect((await teacher.agent.get('/api/reports/receivables')).status).toBe(403)
  })
  test('financeiro lê alunos só como opções de seleção', async () => {
    const r = await finance.agent.get('/api/options/students')
    expect(r.status).toBe(200)
    expect(r.body.data.length).toBeGreaterThan(0)
  })
})

describe('cadastros', () => {
  test('CRUD de aluno com releitura, filtros e exclusão', async () => {
    const created = await write(admin, 'post', '/api/resources/students', { code: 'QA-AL-01', name: 'Aluno Integração', birth_date: '2015-03-14' })
    expect(created.status).toBe(201)
    const id = created.body.data.id
    expect((await admin.agent.get(`/api/resources/students/${id}`)).body.data.name).toBe('Aluno Integração')
    expect((await write(admin, 'put', `/api/resources/students/${id}`, { name: 'Aluno Editado' })).body.data.name).toBe('Aluno Editado')
    const found = await admin.agent.get('/api/resources/students').query({ name: 'Editado' })
    expect(found.body.pagination.total).toBe(1)
    expect((await write(admin, 'delete', `/api/resources/students/${id}`)).status).toBe(200)
    expect((await admin.agent.get(`/api/resources/students/${id}`)).status).toBe(404)
  })
  test('campos desconhecidos, data inválida e duplicidade são negados', async () => {
    const unknown = await write(admin, 'post', '/api/resources/students', { code: 'QA-2', name: 'X', birth_date: '2026-02-30', role: 'admin' })
    expect(unknown.status).toBe(422)
    expect(Array.isArray(unknown.body.fields)).toBe(true)
    const dup = await write(admin, 'post', '/api/resources/students', { code: 'DEMO-AL-001', name: 'Duplicado', birth_date: '2015-01-01' })
    expect(dup.status).toBe(409)
  })
  test('filtros de alunos por curso, ano, situação e responsável', async () => {
    const r = await admin.agent.get('/api/resources/students').query({ guardian_id: demoIds.guardian, course_id: demoIds.course, year: 2026, status: 'Cursando' })
    expect(r.status).toBe(200)
    expect(r.body.pagination.total).toBe(2)
  })
  test('referência inexistente falha sem deixar auditoria parcial', async () => {
    const audits = Number((await db('audit_log').count({ n: '*' }).first()).n)
    const r = await write(admin, 'post', '/api/resources/enrollments', { student_id: demoIds.student1, class_id: '00000000-0000-4000-8000-0000000000ff', status: 'Cursando', enrolled_on: '2026-02-02' })
    expect(r.status).toBeGreaterThanOrEqual(409)
    expect(Number((await db('audit_log').count({ n: '*' }).first()).n)).toBe(audits)
  })
  test('nota de aluno ausente não pode ter valor', async () => {
    const r = await write(admin, 'post', '/api/resources/grades', { enrollment_id: demoIds.enrollment1, subject_id: demoIds.subject, period: 'QA', value: 9, absent: true })
    expect(r.status).toBe(422)
  })
  test('último administrador ativo é protegido', async () => {
    const r = await write(admin, 'put', `/api/resources/users/${demoIds.admin}`, { active: false })
    expect(r.status).toBe(409)
    expect(r.body.code).toBe('LAST_ADMIN')
  })
  test('trocar a senha de um usuário revoga as sessões dele', async () => {
    const created = await write(admin, 'post', '/api/resources/users', { name: 'Prof Temporário', email: 'temp@school.local', role: 'professor', active: true, password: 'SenhaTemporaria!1' })
    expect(created.status).toBe(201)
    const temp = await login('temp@school.local', 'SenhaTemporaria!1')
    expect((await temp.agent.get('/api/auth/me')).status).toBe(200)
    await write(admin, 'put', `/api/resources/users/${created.body.data.id}`, { password: 'OutraSenhaForte!2' })
    expect((await temp.agent.get('/api/auth/me')).status).toBe(401)
    expect(JSON.stringify(created.body)).not.toMatch(/password_hash/)
  })
})

describe('financeiro', () => {
  test('recebimento parcial/total, idempotência e saldo por filho', async () => {
    const key = 'qa-pay-' + Date.now()
    const first = await write(finance, 'post', '/api/finance/payments', { invoice_id: demoIds.invoiceOpen, amount_cents: 25000, method: 'Pix', idempotency_key: key })
    expect(first.status).toBe(201)
    const repeat = await write(finance, 'post', '/api/finance/payments', { invoice_id: demoIds.invoiceOpen, amount_cents: 25000, method: 'Pix', idempotency_key: key })
    expect(repeat.status).toBe(200)
    expect(repeat.body.repeated).toBe(true)
    const conflict = await write(finance, 'post', '/api/finance/payments', { invoice_id: demoIds.invoiceOpen, amount_cents: 1, method: 'Pix', idempotency_key: key })
    expect(conflict.status).toBe(409)
    const over = await write(finance, 'post', '/api/finance/payments', { invoice_id: demoIds.invoiceOpen, amount_cents: 999999, method: 'Pix', idempotency_key: key + '-over' })
    expect(over.status).toBe(409)
    const a = (await finance.agent.get(`/api/resources/invoices/${demoIds.invoiceOpen}`)).body.data
    const b = (await finance.agent.get(`/api/resources/invoices/${demoIds.invoicePartial}`)).body.data
    expect(a.paid_cents).toBe(25000)
    expect(a.balance_cents).toBe(100000)
    expect(b.paid_cents).toBe(40000) // irmão não foi afetado
  })
  test('pagamentos concorrentes com a mesma chave gravam uma vez', async () => {
    const key = 'qa-race-' + Date.now()
    const send = () => write(finance, 'post', '/api/finance/payments', { invoice_id: demoIds.invoiceOpen, amount_cents: 1000, method: 'Pix', idempotency_key: key })
    const results = await Promise.all([send(), send(), send()])
    expect(results.filter((r) => r.status === 201)).toHaveLength(1)
    expect((await db('payments').where({ idempotency_key: key })).length).toBe(1)
  })
  test('cobrança com pagamento não pode ser excluída', async () => {
    expect((await write(finance, 'delete', `/api/resources/invoices/${demoIds.invoicePartial}`)).status).toBe(409)
  })
})

describe('relatórios, resumo e integrações', () => {
  test('relatórios locais retornam colunas e linhas', async () => {
    for (const rep of ['student-roster', 'enrollments', 'grades', 'attendance', 'receivables', 'payables', 'assets', 'cash']) {
      const r = await admin.agent.get(`/api/reports/${rep}`)
      expect(r.status).toBe(200)
      expect(r.body.data.columns.length).toBeGreaterThan(0)
      expect(Array.isArray(r.body.data.rows)).toBe(true)
    }
    expect((await admin.agent.get('/api/reports/inexistente')).status).toBe(404)
  })
  test('resumo do aluno traz só dados do aluno pedido', async () => {
    const a = (await admin.agent.get(`/api/documents/${demoIds.student1}/summary`)).body.data
    expect(a.student.id).toBe(demoIds.student1)
    expect(a.enrollments.every((e) => e.student_id === demoIds.student1)).toBe(true)
    expect((await teacher.agent.get(`/api/documents/${demoIds.student1}/summary`)).status).toBe(403)
  })
  test('integração só enfileira localmente como pendente', async () => {
    const route = (await admin.agent.get('/api/catalog')).body.data.routes.find((r) => r.mode === 'integration' && r.module === 'academico')
    const r = await write(secretary, 'post', '/api/integrations/jobs', { route_id: route.id, payload: { description: 'teste' } })
    expect(r.status).toBe(201)
    expect(r.body.data.status).toBe('pendente')
    const finRoute = (await admin.agent.get('/api/catalog')).body.data.routes.find((x) => x.mode === 'integration' && x.module === 'financeiro')
    expect((await write(secretary, 'post', '/api/integrations/jobs', { route_id: finRoute.id, payload: { description: 'x' } })).status).toBe(403)
  })
  test('dashboard respeita o perfil', async () => {
    const f = (await finance.agent.get('/api/dashboard')).body.data
    expect(f.students).toBeNull()
    expect(typeof f.totalReceivableCents).toBe('number')
  })
  test('seed não roda em produção', async () => {
    const old = process.env.NODE_ENV
    process.env.NODE_ENV = 'production'
    try { await expect(db.seed.run()).rejects.toThrow(/bloqueado/) } finally { process.env.NODE_ENV = old }
  })
})

describe('esquema do banco', () => {
  test('toda coluna de resources.json existe com a obrigatoriedade correta', async () => {
    const { resources } = require('../src/shared/catalog')
    const cols = await db('information_schema.columns').where({ table_schema: 'public' }).select('table_name', 'column_name', 'is_nullable')
    const map = new Map(cols.map((c) => [`${c.table_name}.${c.column_name}`, c.is_nullable]))
    const problems = []
    for (const [table, def] of Object.entries(resources)) {
      for (const f of def.fields) {
        const col = f.type === 'password' ? 'password_hash' : f.key
        const nullable = map.get(`${table}.${col}`)
        if (!nullable) problems.push(`${table}.${col} ausente`)
        else if ((nullable === 'NO') !== Boolean(f.required || f.type === 'boolean' || f.type === 'password')) problems.push(`${table}.${col} obrigatoriedade diferente`)
      }
    }
    expect(problems).toEqual([])
  })
  test('rollback e nova migração funcionam (uma migration por tabela)', async () => {
    const files = require('node:fs').readdirSync(require('node:path').join(__dirname, '../src/db/migrations'))
    expect(files.length).toBe(27)
    await db.migrate.rollback(undefined, true)
    expect((await db('information_schema.tables').where({ table_schema: 'public' }).whereNot('table_name', 'like', 'knex_%').count({ n: '*' }).first()).n).toBe('0')
    await db.migrate.latest()
    await db.seed.run() // seeds são repetíveis
    expect(Number((await db('students').count({ n: '*' }).first()).n)).toBe(2)
  })
})
