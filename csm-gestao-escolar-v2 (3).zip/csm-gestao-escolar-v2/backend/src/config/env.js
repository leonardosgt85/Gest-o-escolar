require('dotenv').config({ quiet: true })

const isProd = process.env.NODE_ENV === 'production'

const sessionHours = Number(process.env.SESSION_HOURS || 8)
if (!Number.isFinite(sessionHours) || sessionHours <= 0 || sessionHours > 24) {
  throw new Error('SESSION_HOURS deve estar entre 0 e 24.')
}

const allowedOrigins = (
  process.env.FRONTEND_URL ||
  (isProd ? '' : 'http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000')
)
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean)

if (isProd && !allowedOrigins.length) throw new Error('Configure FRONTEND_URL em produção.')

module.exports = { isProd, sessionHours, allowedOrigins }
