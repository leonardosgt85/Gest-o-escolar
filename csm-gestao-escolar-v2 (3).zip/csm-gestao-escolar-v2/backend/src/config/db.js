const knex = require('knex')
require('../utils/dates') // parser de DATE do pg (data de calendário, sem fuso)

const environment = process.env.NODE_ENV || 'development'
const config = require('../../knexfile')[environment]

module.exports = knex(config)
