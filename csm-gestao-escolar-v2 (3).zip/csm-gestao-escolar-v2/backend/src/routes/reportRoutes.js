const express = require('express')
const controller = require('../controllers/reportController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)
router.get('/reports/:report', controller.getReport)
router.get('/documents/:studentId/summary', controller.studentSummary)

module.exports = router
