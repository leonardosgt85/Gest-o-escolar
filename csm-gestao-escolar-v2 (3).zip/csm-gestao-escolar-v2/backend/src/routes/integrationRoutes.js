const express = require('express')
const controller = require('../controllers/integrationController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)
router.get('/jobs', controller.list)
router.post('/jobs', controller.create)

module.exports = router
