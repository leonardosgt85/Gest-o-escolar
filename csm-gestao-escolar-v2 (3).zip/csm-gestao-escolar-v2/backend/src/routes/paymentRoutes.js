const express = require('express')
const controller = require('../controllers/paymentController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)
router.post('/payments', controller.create)

module.exports = router
