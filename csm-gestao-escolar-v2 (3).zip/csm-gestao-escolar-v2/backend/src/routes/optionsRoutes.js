const express = require('express')
const controller = require('../controllers/resourceController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)
router.get('/:resource', controller.options)

module.exports = router
