const express = require('express')
const controller = require('../controllers/resourceController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)

// Permissão por cadastro e por perfil é decidida em services/policyService.js
router.get('/:resource', controller.list)
router.get('/:resource/:id', controller.getById)
router.post('/:resource', controller.create)
router.put('/:resource/:id', controller.update)
router.delete('/:resource/:id', controller.remove)

module.exports = router
