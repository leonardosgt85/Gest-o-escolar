const express = require('express')

const authRoutes = require('./authRoutes')
const catalogRoutes = require('./catalogRoutes')
const resourceRoutes = require('./resourceRoutes')
const optionsRoutes = require('./optionsRoutes')
const paymentRoutes = require('./paymentRoutes')
const reportRoutes = require('./reportRoutes')
const integrationRoutes = require('./integrationRoutes')

const router = express.Router()

router.use('/auth', authRoutes)
router.use('/resources', resourceRoutes)
router.use('/options', optionsRoutes)
router.use('/finance', paymentRoutes)
router.use('/integrations', integrationRoutes)
router.use('/', catalogRoutes) // /catalog, /dashboard
router.use('/', reportRoutes) // /reports/:report, /documents/:studentId/summary

module.exports = router
