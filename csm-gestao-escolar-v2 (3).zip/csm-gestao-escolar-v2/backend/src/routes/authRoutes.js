const express = require('express')
const rateLimit = require('express-rate-limit')
const authController = require('../controllers/authController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()

// Trava força bruta de senha
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: process.env.NODE_ENV === 'test' ? 1000 : 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Muitas tentativas de login. Tente novamente em alguns minutos.', code: 'LOGIN_RATE_LIMIT' },
})

router.post('/login', loginLimiter, authController.login)
router.post('/logout', authenticate, authController.logout)
router.get('/me', authenticate, authController.me)

module.exports = router
