const express = require('express')
const controller = require('../controllers/catalogController')
const { authenticate } = require('../middleware/auth')

const router = express.Router()
router.use(authenticate)

router.get('/catalog', controller.getCatalog)
router.get('/dashboard', controller.getDashboard)

module.exports = router
