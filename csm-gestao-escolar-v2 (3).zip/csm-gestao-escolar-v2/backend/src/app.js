require('dotenv').config({ quiet: true })
const path = require('node:path')
const { existsSync } = require('node:fs')
const express = require('express')
const cookieParser = require('cookie-parser')
const helmet = require('helmet')

const routes = require('./routes')
const errorHandler = require('./middleware/errorHandler')
const requireOrigin = require('./middleware/requireOrigin')
const db = require('./config/db')
const { isProd } = require('./config/env')

const app = express()

// Atrás de proxy reverso (comum em hospedagem) o Express precisa enxergar o IP
// real e o HTTPS para o cookie "secure" funcionar.
app.set('trust proxy', 1)
app.disable('x-powered-by')

app.use(helmet({
  hsts: isProd,
  contentSecurityPolicy: isProd ? undefined : false,
}))
app.use(cookieParser())
app.use(express.json({ limit: '256kb' }))

app.use('/api', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store')
  next()
})

app.get('/api/health', async (req, res, next) => {
  try {
    await db.raw('SELECT 1')
    res.json({ status: 'ok', database: 'connected' })
  } catch (err) {
    next(err)
  }
})

app.use('/api', requireOrigin)
app.use('/api', routes)
app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint não encontrado.', code: 'NOT_FOUND' }))

// Opcional: serve o frontend compilado (project/dist) no mesmo processo.
const staticDir = process.env.STATIC_DIR || path.resolve(__dirname, '../../project/dist')
if (process.env.SERVE_FRONTEND !== '0' && existsSync(path.join(staticDir, 'index.html'))) {
  app.use(express.static(staticDir, { index: false }))
  app.get('/{*path}', (req, res, next) => {
    if (!req.accepts('html') || path.extname(req.path)) return next()
    res.sendFile(path.join(staticDir, 'index.html'))
  })
}

app.use((req, res) => res.status(404).json({ error: 'Recurso não encontrado.', code: 'NOT_FOUND' }))
app.use(errorHandler)

module.exports = app
