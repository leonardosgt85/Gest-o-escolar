// Dados fictícios de demonstração: IDs estáveis (sufixo agrupa por tabela) e helpers
// compartilhados pelos arquivos de src/db/seeds. Fica FORA de seeds/ porque o
// `knex seed:run` executa todo arquivo daquela pasta.
const bcrypt = require('bcryptjs')

const demoIds = Object.freeze({
  admin: '7c500000-0000-4000-8000-000000000001',
  professor: '7c500000-0000-4000-8000-000000000002',
  secretaria: '7c500000-0000-4000-8000-000000000003',
  financeiro: '7c500000-0000-4000-8000-000000000004',
  student1: '7c500000-0000-4000-8000-000000000101',
  student2: '7c500000-0000-4000-8000-000000000102',
  guardian: '7c500000-0000-4000-8000-000000000201',
  guardianLink1: '7c500000-0000-4000-8000-000000000301',
  guardianLink2: '7c500000-0000-4000-8000-000000000302',
  course: '7c500000-0000-4000-8000-000000000401',
  academicYear: '7c500000-0000-4000-8000-000000000501',
  class: '7c500000-0000-4000-8000-000000000601',
  subject: '7c500000-0000-4000-8000-000000000701',
  enrollment1: '7c500000-0000-4000-8000-000000000801',
  enrollment2: '7c500000-0000-4000-8000-000000000802',
  lesson: '7c500000-0000-4000-8000-000000000901',
  attendance1: '7c500000-0000-4000-8000-000000001001',
  attendance2: '7c500000-0000-4000-8000-000000001002',
  grade1: '7c500000-0000-4000-8000-000000001101',
  grade2: '7c500000-0000-4000-8000-000000001102',
  occurrence: '7c500000-0000-4000-8000-000000001201',
  invoiceOpen: '7c500000-0000-4000-8000-000000001301',
  invoicePartial: '7c500000-0000-4000-8000-000000001302',
  account: '7c500000-0000-4000-8000-000000001401',
  vendor: '7c500000-0000-4000-8000-000000001501',
  payable: '7c500000-0000-4000-8000-000000001601',
  asset: '7c500000-0000-4000-8000-000000001701',
  event: '7c500000-0000-4000-8000-000000001801',
  contract: '7c500000-0000-4000-8000-000000001901',
  document: '7c500000-0000-4000-8000-000000002001',
  message: '7c500000-0000-4000-8000-000000002101',
  lookup: '7c500000-0000-4000-8000-000000002301',
  payment: '7c500000-0000-4000-8000-000000002401',
})

const demoNotice = 'DADO FICTÍCIO — demonstração local; sem validade oficial.'

// Seeds só rodam em desenvolvimento/teste (as senhas de demonstração são públicas).
function assertSeedAllowed() {
  const env = process.env.NODE_ENV || 'development'
  if (!['development', 'test'].includes(env)) throw new Error('Seed bloqueado: permitido somente em development ou test.')
}

// Administrador de desenvolvimento sempre existe; o restante exige SEED_DEMO=1.
const demoEnabled = () => process.env.SEED_DEMO === '1'

// Cria o usuário se o e-mail ainda não existir; nunca redefine senha de conta existente.
async function ensureUser(knex, { id, name, email, role, password }) {
  const existing = await knex('users').whereRaw('lower(email) = ?', [email]).first()
  if (existing) return existing.id
  await knex('users').insert({ id, name, email, role, active: true, password_hash: await bcrypt.hash(password, 12) }).onConflict().ignore()
  return (await knex('users').whereRaw('lower(email) = ?', [email]).first()).id
}

// Id real do usuário pelo e-mail (a conta pode já existir com outro id).
async function userIdByEmail(knex, email) {
  const row = await knex('users').whereRaw('lower(email) = ?', [email]).first()
  if (!row) throw new Error(`Usuário ${email} não encontrado: rode a seed 01_users antes.`)
  return row.id
}

// Insere registros fictícios e ignora os que já existem (seed repetível, não apaga nada).
const insertDemo = (knex, table, records) => knex(table).insert(records).onConflict().ignore()

module.exports = { demoIds, demoNotice, assertSeedAllowed, demoEnabled, ensureUser, userIdByEmail, insertDemo }
