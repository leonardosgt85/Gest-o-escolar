// Acadêmico: alunos, responsáveis, curso/ano/turma/disciplina, matrículas, aula, frequência, notas, ocorrência.
const { demoIds: i, demoNotice, assertSeedAllowed, demoEnabled, insertDemo, userIdByEmail } = require('../demoData')

exports.seed = async function seed(knex) {
  assertSeedAllowed()
  if (!demoEnabled()) return
  await knex.transaction(async (trx) => {
    const professorId = await userIdByEmail(trx, 'professor@school.local')
    await insertDemo(trx, 'students', [
      { id: i.student1, code: 'DEMO-AL-001', enrollment_number: 'DEMO-2026-001', name: 'Ana Exemplo Fictício', birth_date: '2016-04-12', email: 'ana@students.example', notes: demoNotice },
      { id: i.student2, code: 'DEMO-AL-002', enrollment_number: 'DEMO-2026-002', name: 'Bruno Exemplo Fictício', birth_date: '2016-09-03', email: 'bruno@students.example', notes: demoNotice },
    ])
    await insertDemo(trx, 'guardians', [
      { id: i.guardian, name: 'Maria Responsável Fictícia', email: 'maria@guardians.example', phone: '(00) 00000-0000', address: 'Endereço fictício para demonstração' },
    ])
    await insertDemo(trx, 'guardian_links', [
      { id: i.guardianLink1, student_id: i.student1, guardian_id: i.guardian, relationship: 'Mãe (fictício)', financial_responsible: true },
      { id: i.guardianLink2, student_id: i.student2, guardian_id: i.guardian, relationship: 'Mãe (fictício)', financial_responsible: true },
    ])
    await insertDemo(trx, 'courses', [{ id: i.course, code: 'DEMO-FUND', name: 'Ensino Fundamental — demonstração', level: 'Fundamental' }])
    await insertDemo(trx, 'academic_years', [{ id: i.academicYear, year: 2026, name: 'Ano letivo fictício 2026', starts_on: '2026-02-02', ends_on: '2026-12-18' }])
    await insertDemo(trx, 'subjects', [{ id: i.subject, code: 'DEMO-MAT', name: 'Matemática — demonstração' }])
    await insertDemo(trx, 'classes', [
      { id: i.class, name: '5º ano A — fictício', course_id: i.course, academic_year_id: i.academicYear, shift: 'Matutino', capacity: 25, teacher_id: professorId },
    ])
    await insertDemo(trx, 'enrollments', [
      { id: i.enrollment1, student_id: i.student1, class_id: i.class, status: 'Cursando', enrolled_on: '2026-02-02' },
      { id: i.enrollment2, student_id: i.student2, class_id: i.class, status: 'Cursando', enrolled_on: '2026-02-02' },
    ])
    await insertDemo(trx, 'lessons', [
      { id: i.lesson, class_id: i.class, subject_id: i.subject, teacher_id: professorId, date: '2026-10-05', content: 'Frações equivalentes. Conteúdo fictício para validar a operação local.' },
    ])
    await insertDemo(trx, 'attendance', [
      { id: i.attendance1, lesson_id: i.lesson, student_id: i.student1, present: true, remarks: demoNotice },
      { id: i.attendance2, lesson_id: i.lesson, student_id: i.student2, present: false, remarks: 'Ausência fictícia para demonstração.' },
    ])
    await insertDemo(trx, 'grades', [
      { id: i.grade1, enrollment_id: i.enrollment1, subject_id: i.subject, period: '3º bimestre', value: '8.50', absent: false, remarks: demoNotice },
      { id: i.grade2, enrollment_id: i.enrollment2, subject_id: i.subject, period: '3º bimestre', value: null, absent: true, remarks: 'Avaliação fictícia não realizada; sem média automática.' },
    ])
    await insertDemo(trx, 'occurrences', [
      { id: i.occurrence, student_id: i.student2, date: '2026-10-05', category: 'Registro de demonstração', description: demoNotice },
    ])
  })
}
