// Financeiro: cobranças (uma com recebimento parcial), caixa, fornecedor e conta a pagar.
const { demoIds: i, assertSeedAllowed, demoEnabled, insertDemo, userIdByEmail } = require('../demoData')

exports.seed = async function seed(knex) {
  assertSeedAllowed()
  if (!demoEnabled()) return
  await knex.transaction(async (trx) => {
    const adminId = await userIdByEmail(trx, 'admin@school.local')
    await insertDemo(trx, 'invoices', [
      { id: i.invoiceOpen, student_id: i.student1, guardian_id: i.guardian, description: 'Mensalidade fictícia — novembro/2026', due_on: '2026-11-10', amount_cents: 125000, paid_cents: 0 },
      { id: i.invoicePartial, student_id: i.student2, guardian_id: i.guardian, description: 'Mensalidade fictícia — outubro/2026', due_on: '2026-10-10', amount_cents: 125000, paid_cents: 0 },
    ])
    // O saldo só é atualizado se o recebimento foi realmente inserido (seed repetível).
    const inserted = await trx('payments')
      .insert({ id: i.payment, invoice_id: i.invoicePartial, amount_cents: 40000, method: 'Pix', idempotency_key: 'demo-school-payment-2026-001', created_by: adminId })
      .onConflict().ignore().returning('id')
    if (inserted.length) await trx('invoices').where({ id: i.invoicePartial }).increment('paid_cents', 40000)

    await insertDemo(trx, 'accounts', [{ id: i.account, name: 'Caixa fictício de demonstração', kind: 'Caixa', opening_balance_cents: 100000 }])
    await insertDemo(trx, 'vendors', [{ id: i.vendor, name: 'Papelaria Fictícia Exemplo', document: 'DEMO-FORNECEDOR', email: 'papelaria@vendors.example', phone: '(00) 00000-0000' }])
    await insertDemo(trx, 'payables', [{ id: i.payable, vendor_id: i.vendor, description: 'Material escolar fictício', due_on: '2026-11-15', amount_cents: 38000 }])
  })
}
