// Institucional: patrimônio, evento, contrato, documento, mensagem e cadastro auxiliar.
const { demoIds: i, demoNotice, assertSeedAllowed, demoEnabled, insertDemo } = require('../demoData')

exports.seed = async function seed(knex) {
  assertSeedAllowed()
  if (!demoEnabled()) return
  await knex.transaction(async (trx) => {
    await insertDemo(trx, 'assets', [
      { id: i.asset, code: 'DEMO-PAT-001', name: 'Projetor fictício de demonstração', group_name: 'Equipamentos', sector: 'Sala fictícia 5A', acquired_on: '2026-02-01', value_cents: 250000, status: 'Ativo' },
    ])
    await insertDemo(trx, 'events', [
      { id: i.event, title: 'Reunião fictícia de responsáveis', starts_at: '2026-11-05T18:00:00-04:00', ends_at: '2026-11-05T19:30:00-04:00', description: demoNotice },
    ])
    await insertDemo(trx, 'contracts', [
      { id: i.contract, student_id: i.student1, description: 'Modelo fictício de prestação educacional', terms: `${demoNotice} Sem assinatura digital; não reproduz contrato do fornecedor.` },
    ])
    await insertDemo(trx, 'documents', [{ id: i.document, student_id: i.student1, kind: 'Comprovante fictício', description: demoNotice, received: true }])
    await insertDemo(trx, 'messages', [
      { id: i.message, recipient: 'Secretaria de demonstração', subject: 'Mensagem fictícia local', body: `${demoNotice} Nenhum e-mail, SMS ou WhatsApp foi enviado.` },
    ])
    await insertDemo(trx, 'lookup_entries', [{ id: i.lookup, category: 'Demonstração', code: 'DEMO-AUX-001', name: 'Categoria auxiliar fictícia', notes: demoNotice }])
  })
}
