// Usuários: administrador de desenvolvimento (sempre) + um usuário por perfil (SEED_DEMO=1).
const { demoIds: i, assertSeedAllowed, demoEnabled, ensureUser } = require('../demoData')

exports.seed = async function seed(knex) {
  assertSeedAllowed()
  await ensureUser(knex, { id: i.admin, name: 'Admin de demonstração', email: 'admin@school.local', role: 'admin', password: 'AdminDev!123' })
  if (!demoEnabled()) return
  await ensureUser(knex, { id: i.professor, name: 'Professor fictício João', email: 'professor@school.local', role: 'professor', password: 'ProfessorDev!123' })
  await ensureUser(knex, { id: i.secretaria, name: 'Secretaria de demonstração', email: 'secretaria@school.local', role: 'secretaria', password: 'SecretariaDev!123' })
  await ensureUser(knex, { id: i.financeiro, name: 'Financeiro de demonstração', email: 'financeiro@school.local', role: 'financeiro', password: 'FinanceiroDev!123' })
}
