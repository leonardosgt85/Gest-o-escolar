// Tabela payables — Contas a pagar
exports.up = async function up(knex) {
  await knex.schema.createTable('payables', (t) => {
    t.uuid('id').primary()
    t.uuid('vendor_id').references('id').inTable('vendors').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Fornecedor
    t.text('description').notNullable() // Descrição
    t.date('due_on').notNullable() // Vencimento
    t.integer('amount_cents').notNullable() // Valor (R$)
    t.check('amount_cents >= 0', [], 'payables_amount_cents_check')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX payables_due_on_idx ON payables (due_on)')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('payables')
}
