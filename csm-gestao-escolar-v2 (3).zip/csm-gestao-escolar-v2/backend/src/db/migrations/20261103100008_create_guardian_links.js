// Tabela guardian_links — Vínculos de responsáveis
exports.up = async function up(knex) {
  await knex.schema.createTable('guardian_links', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.uuid('guardian_id').references('id').inTable('guardians').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Responsável
    t.text('relationship').notNullable() // Parentesco
    t.boolean('financial_responsible').defaultTo(false).notNullable() // Responsável financeiro
    t.unique(['student_id', 'guardian_id'], 'guardian_links_student_id_guardian_id_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('guardian_links')
}
