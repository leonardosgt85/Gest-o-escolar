// Tabela attendance — Frequência
exports.up = async function up(knex) {
  await knex.schema.createTable('attendance', (t) => {
    t.uuid('id').primary()
    t.uuid('lesson_id').references('id').inTable('lessons').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aula
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.boolean('present').defaultTo(false).notNullable() // Presente
    t.text('remarks') // Observações
    t.unique(['lesson_id', 'student_id'], 'attendance_lesson_id_student_id_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('attendance')
}
