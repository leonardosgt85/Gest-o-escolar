// Tabela integration_jobs — fila LOCAL de solicitações de integração (nada é enviado)
exports.up = async function up(knex) {
  await knex.schema.createTable('integration_jobs', (t) => {
    t.uuid('id').primary()
    t.text('route_id').notNullable().index()
    t.jsonb('payload').notNullable()
    t.text('status').notNullable().defaultTo('pendente')
    t.check("status IN ('pendente')", [], 'integration_jobs_status_check')
    t.uuid('created_by').notNullable().references('id').inTable('users').onDelete('RESTRICT').index()
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('integration_jobs')
}
