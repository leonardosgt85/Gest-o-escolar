// Tabela classes — Turmas
exports.up = async function up(knex) {
  await knex.schema.createTable('classes', (t) => {
    t.uuid('id').primary()
    t.text('name').notNullable() // Turma
    t.uuid('course_id').references('id').inTable('courses').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Curso
    t.uuid('academic_year_id').references('id').inTable('academic_years').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Ano letivo
    t.text('shift').notNullable() // Período
    t.check("shift IN ('Matutino','Vespertino','Integral','Noturno')", [], 'classes_shift_check')
    t.integer('capacity') // Vagas
    t.uuid('teacher_id').references('id').inTable('users').onDelete('RESTRICT').onUpdate('RESTRICT').index() // Professor responsável
    t.check('capacity IS NULL OR capacity > 0', [], 'classes_capacity_check')
    t.unique(['name', 'academic_year_id'], 'classes_name_academic_year_id_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX classes_name_lower_idx ON classes (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('classes')
}
