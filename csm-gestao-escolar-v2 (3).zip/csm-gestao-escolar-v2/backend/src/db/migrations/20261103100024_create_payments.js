// Tabela payments — recebimentos manuais de cobranças (valores em centavos)
exports.up = async function up(knex) {
  await knex.schema.createTable('payments', (t) => {
    t.uuid('id').primary()
    t.uuid('invoice_id').notNullable().references('id').inTable('invoices').onDelete('RESTRICT').index()
    t.integer('amount_cents').notNullable()
    t.check('amount_cents > 0', [], 'payments_amount_cents_check')
    t.text('method').notNullable() // Dinheiro, Pix, Cartão…
    t.text('idempotency_key').notNullable().unique() // repetir o envio nunca grava duas vezes
    t.uuid('created_by').notNullable().references('id').inTable('users').onDelete('RESTRICT')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('payments')
}
