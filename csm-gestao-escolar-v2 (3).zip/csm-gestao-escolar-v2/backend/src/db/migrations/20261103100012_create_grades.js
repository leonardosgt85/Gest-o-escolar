// Tabela grades — Notas periódicas
exports.up = async function up(knex) {
  await knex.schema.createTable('grades', (t) => {
    t.uuid('id').primary()
    t.uuid('enrollment_id').references('id').inTable('enrollments').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Matrícula
    t.uuid('subject_id').references('id').inTable('subjects').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Disciplina
    t.text('period').notNullable() // Período de avaliação
    t.decimal('value', 8, 2) // Nota
    t.boolean('absent').defaultTo(false).notNullable() // Ausente
    t.text('remarks') // Observações
    t.check('value IS NULL OR value >= 0', [], 'grades_value_check')
    t.check('NOT absent OR value IS NULL', [], 'grades_absent_without_value_check')
    t.unique(['enrollment_id', 'subject_id', 'period'], 'grades_enrollment_id_subject_id_period_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('grades')
}
