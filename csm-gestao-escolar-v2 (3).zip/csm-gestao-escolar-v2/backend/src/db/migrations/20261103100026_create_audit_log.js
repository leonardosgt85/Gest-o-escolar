// Tabela audit_log — trilha de auditoria de criação/edição/exclusão/recebimento
exports.up = async function up(knex) {
  await knex.schema.createTable('audit_log', (t) => {
    t.uuid('id').primary()
    t.uuid('actor_id').references('id').inTable('users').onDelete('SET NULL').index()
    t.text('action').notNullable()
    t.text('resource').notNullable()
    t.uuid('record_id')
    t.jsonb('details').notNullable().defaultTo('{}')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('audit_log')
}
