// Tabela assets — Bens patrimoniais
exports.up = async function up(knex) {
  await knex.schema.createTable('assets', (t) => {
    t.uuid('id').primary()
    t.text('code').notNullable() // Código
    t.text('name').notNullable() // Descrição do bem
    t.text('group_name') // Grupo
    t.text('sector') // Setor
    t.date('acquired_on') // Aquisição
    t.integer('value_cents') // Valor (R$)
    t.check('value_cents >= 0', [], 'assets_value_cents_check')
    t.text('status').notNullable() // Situação
    t.check("status IN ('Ativo','Manutenção','Baixado')", [], 'assets_status_check')
    t.unique(['code'], 'assets_code_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX assets_name_lower_idx ON assets (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('assets')
}
