// Tabela subjects — Disciplinas
exports.up = async function up(knex) {
  await knex.schema.createTable('subjects', (t) => {
    t.uuid('id').primary()
    t.text('code').notNullable() // Código
    t.text('name').notNullable() // Disciplina
    t.unique(['code'], 'subjects_code_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX subjects_name_lower_idx ON subjects (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('subjects')
}
