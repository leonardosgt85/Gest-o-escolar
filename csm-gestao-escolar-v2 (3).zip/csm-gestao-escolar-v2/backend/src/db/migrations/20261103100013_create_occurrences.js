// Tabela occurrences — Ocorrências disciplinares
exports.up = async function up(knex) {
  await knex.schema.createTable('occurrences', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.date('date').notNullable() // Data
    t.text('category').notNullable() // Tipo
    t.text('description').notNullable() // Descrição
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('occurrences')
}
