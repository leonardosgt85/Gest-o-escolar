// Tabela courses — Cursos
exports.up = async function up(knex) {
  await knex.schema.createTable('courses', (t) => {
    t.uuid('id').primary()
    t.text('code').notNullable() // Código
    t.text('name').notNullable() // Curso
    t.text('level') // Nível de ensino
    t.unique(['code'], 'courses_code_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX courses_name_lower_idx ON courses (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('courses')
}
