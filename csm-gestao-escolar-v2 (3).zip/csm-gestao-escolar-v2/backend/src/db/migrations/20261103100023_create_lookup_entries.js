// Tabela lookup_entries — Cadastros auxiliares
exports.up = async function up(knex) {
  await knex.schema.createTable('lookup_entries', (t) => {
    t.uuid('id').primary()
    t.text('category').notNullable() // Categoria
    t.text('code') // Código
    t.text('name').notNullable() // Descrição
    t.text('notes') // Observações
    t.unique(['category', 'code'], 'lookup_entries_category_code_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('lookup_entries')
}
