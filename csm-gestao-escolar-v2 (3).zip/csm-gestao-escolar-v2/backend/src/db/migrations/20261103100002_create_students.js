// Tabela students — Alunos
exports.up = async function up(knex) {
  await knex.schema.createTable('students', (t) => {
    t.uuid('id').primary()
    t.text('code').notNullable() // Código
    t.text('enrollment_number') // Matrícula
    t.text('name').notNullable() // Nome do aluno
    t.text('cpf') // CPF
    t.date('birth_date').notNullable() // Nascimento
    t.text('phone') // Telefone
    t.text('email') // E-mail
    t.text('address') // Endereço
    t.text('notes') // Observações
    t.unique(['code'], 'students_code_unique')
    t.unique(['enrollment_number'], 'students_enrollment_number_unique')
    t.unique(['cpf'], 'students_cpf_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX students_name_lower_idx ON students (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('students')
}
