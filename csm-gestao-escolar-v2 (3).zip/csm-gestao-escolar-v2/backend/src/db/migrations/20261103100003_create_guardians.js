// Tabela guardians — Responsáveis
exports.up = async function up(knex) {
  await knex.schema.createTable('guardians', (t) => {
    t.uuid('id').primary()
    t.text('name').notNullable() // Nome do responsável
    t.text('cpf') // CPF
    t.text('email') // E-mail
    t.text('phone') // Telefone
    t.text('address') // Endereço
    t.unique(['cpf'], 'guardians_cpf_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX guardians_name_lower_idx ON guardians (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('guardians')
}
