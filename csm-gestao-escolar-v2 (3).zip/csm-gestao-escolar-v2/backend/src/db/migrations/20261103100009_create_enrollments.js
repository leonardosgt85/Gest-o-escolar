// Tabela enrollments — Ensalamento de alunos
exports.up = async function up(knex) {
  await knex.schema.createTable('enrollments', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.uuid('class_id').references('id').inTable('classes').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Turma
    t.text('status').notNullable() // Situação
    t.check("status IN ('Aguardando deferimento','Cursando','Indeferida')", [], 'enrollments_status_check')
    t.date('enrolled_on').notNullable() // Data da matrícula
    t.unique(['student_id', 'class_id'], 'enrollments_student_id_class_id_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('enrollments')
}
