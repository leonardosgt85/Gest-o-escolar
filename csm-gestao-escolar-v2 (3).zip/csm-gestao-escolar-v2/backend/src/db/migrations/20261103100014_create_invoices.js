// Tabela invoices — Cobranças por aluno
exports.up = async function up(knex) {
  await knex.schema.createTable('invoices', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.uuid('guardian_id').references('id').inTable('guardians').onDelete('RESTRICT').onUpdate('RESTRICT').index() // Responsável financeiro
    t.text('description').notNullable() // Descrição
    t.date('due_on').notNullable() // Vencimento
    t.integer('amount_cents').notNullable() // Valor (R$)
    t.check('amount_cents >= 0', [], 'invoices_amount_cents_check')
    t.integer('paid_cents').notNullable().defaultTo(0) // total já recebido (atualizado só pelo recebimento)
    t.check('paid_cents >= 0 AND paid_cents <= amount_cents', [], 'invoices_paid_range_check')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX invoices_due_on_idx ON invoices (due_on)')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('invoices')
}
