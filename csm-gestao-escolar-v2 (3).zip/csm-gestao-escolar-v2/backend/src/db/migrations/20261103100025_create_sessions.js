// Tabela sessions — sessões opacas (só o hash do token fica no banco)
exports.up = async function up(knex) {
  await knex.schema.createTable('sessions', (t) => {
    t.uuid('id').primary()
    t.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE').index()
    t.text('token_hash').notNullable().unique()
    t.text('user_agent')
    t.text('ip_address')
    t.timestamp('expires_at', { useTz: true }).notNullable().index()
    t.timestamp('revoked_at', { useTz: true })
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('sessions')
}
