// Tabela academic_years — Anos letivos
exports.up = async function up(knex) {
  await knex.schema.createTable('academic_years', (t) => {
    t.uuid('id').primary()
    t.integer('year').notNullable() // Ano
    t.text('name').notNullable() // Descrição
    t.date('starts_on') // Início
    t.date('ends_on') // Término
    t.check('year BETWEEN 1900 AND 2200', [], 'academic_years_year_check')
    t.check('ends_on IS NULL OR starts_on IS NULL OR ends_on >= starts_on', [], 'academic_years_period_check')
    t.unique(['year'], 'academic_years_year_unique')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('academic_years')
}
