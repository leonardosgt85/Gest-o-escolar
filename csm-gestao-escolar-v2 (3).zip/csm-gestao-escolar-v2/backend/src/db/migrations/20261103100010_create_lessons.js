// Tabela lessons — Conteúdos lecionados
exports.up = async function up(knex) {
  await knex.schema.createTable('lessons', (t) => {
    t.uuid('id').primary()
    t.uuid('class_id').references('id').inTable('classes').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Turma
    t.uuid('subject_id').references('id').inTable('subjects').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Disciplina
    t.date('date').notNullable() // Data da aula
    t.text('content').notNullable() // Conteúdo lecionado
    t.uuid('teacher_id').references('id').inTable('users').onDelete('RESTRICT').onUpdate('RESTRICT').index() // Professor responsável
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX lessons_date_idx ON lessons (date)')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('lessons')
}
