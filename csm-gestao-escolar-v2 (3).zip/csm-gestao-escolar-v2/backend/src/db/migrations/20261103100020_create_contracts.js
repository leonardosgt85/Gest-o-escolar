// Tabela contracts — Contratos
exports.up = async function up(knex) {
  await knex.schema.createTable('contracts', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.text('description').notNullable() // Descrição
    t.text('terms').notNullable() // Condições
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('contracts')
}
