// Tabela messages — Mensagens de entrada
exports.up = async function up(knex) {
  await knex.schema.createTable('messages', (t) => {
    t.uuid('id').primary()
    t.text('recipient').notNullable() // Destinatário
    t.text('subject').notNullable() // Assunto
    t.text('body').notNullable() // Mensagem
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('messages')
}
