// Tabela vendors — Fornecedores e prestadores
exports.up = async function up(knex) {
  await knex.schema.createTable('vendors', (t) => {
    t.uuid('id').primary()
    t.text('name').notNullable() // Razão social / Nome
    t.text('document') // CPF / CNPJ
    t.text('email') // E-mail
    t.text('phone') // Telefone
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX vendors_name_lower_idx ON vendors (lower(name))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('vendors')
}
