// Tabela events — Calendário de eventos
exports.up = async function up(knex) {
  await knex.schema.createTable('events', (t) => {
    t.uuid('id').primary()
    t.text('title').notNullable() // Evento
    t.timestamp('starts_at', { useTz: true }).notNullable() // Início
    t.timestamp('ends_at', { useTz: true }).notNullable() // Término
    t.text('description') // Descrição
    t.check('ends_at >= starts_at', [], 'events_period_check')
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('events')
}
