// Tabela users — Usuários
exports.up = async function up(knex) {
  await knex.schema.createTable('users', (t) => {
    t.uuid('id').primary()
    t.text('name').notNullable() // Nome
    t.text('email').notNullable() // E-mail
    t.text('role').notNullable() // Perfil
    t.check("role IN ('admin','secretaria','professor','financeiro')", [], 'users_role_check')
    t.boolean('active').defaultTo(true).notNullable() // Ativo
    t.text('password_hash').notNullable() // senha (bcrypt); nunca sai pela API
    t.unique(['email'], 'users_email_unique')
    t.timestamps(true, true)
  })
  await knex.schema.raw('CREATE INDEX users_name_lower_idx ON users (lower(name))')
  await knex.schema.raw('CREATE UNIQUE INDEX users_email_lower_unique ON users (lower(email))')
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('users')
}
