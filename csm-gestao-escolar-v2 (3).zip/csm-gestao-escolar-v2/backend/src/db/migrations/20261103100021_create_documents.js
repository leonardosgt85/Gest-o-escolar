// Tabela documents — Documentos dos alunos
exports.up = async function up(knex) {
  await knex.schema.createTable('documents', (t) => {
    t.uuid('id').primary()
    t.uuid('student_id').references('id').inTable('students').onDelete('RESTRICT').onUpdate('RESTRICT').notNullable().index() // Aluno
    t.text('kind').notNullable() // Tipo de documento
    t.text('description') // Descrição
    t.boolean('received').defaultTo(false).notNullable() // Recebido
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('documents')
}
