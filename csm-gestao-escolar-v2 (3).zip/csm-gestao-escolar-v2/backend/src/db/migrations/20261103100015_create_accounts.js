// Tabela accounts — Caixas e bancos
exports.up = async function up(knex) {
  await knex.schema.createTable('accounts', (t) => {
    t.uuid('id').primary()
    t.text('name').notNullable() // Descrição
    t.text('kind').notNullable() // Tipo
    t.check("kind IN ('Caixa','Banco')", [], 'accounts_kind_check')
    t.integer('opening_balance_cents').notNullable() // Saldo inicial (R$)
    t.timestamps(true, true)
  })
}

exports.down = async function down(knex) {
  await knex.schema.dropTableIfExists('accounts')
}
