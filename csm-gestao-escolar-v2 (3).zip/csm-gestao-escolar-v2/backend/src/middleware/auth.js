const ApiError = require('../utils/ApiError')
const sessionService = require('../services/sessionService')

const COOKIE_NAME = 'csm_session'

async function authenticate(req, res, next) {
  const rawToken = req.cookies?.[COOKIE_NAME]
  if (!rawToken) return next(new ApiError(401, 'Entre para continuar.', 'UNAUTHENTICATED'))
  try {
    const session = await sessionService.validate(rawToken)
    if (!session) return next(new ApiError(401, 'Sessão inválida ou expirada. Entre novamente.', 'INVALID_SESSION'))
    req.user = session // { id, name, email, role, sessionId }
    req.sessionToken = rawToken
    next()
  } catch (err) {
    next(err)
  }
}

// Uso: requireRole('admin', 'secretaria')
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return next(new ApiError(401, 'Não autenticado.', 'UNAUTHENTICATED'))
    if (!roles.includes(req.user.role)) return next(new ApiError(403, 'Seu perfil não pode executar esta operação.', 'FORBIDDEN'))
    next()
  }
}

module.exports = { authenticate, requireRole, COOKIE_NAME }
