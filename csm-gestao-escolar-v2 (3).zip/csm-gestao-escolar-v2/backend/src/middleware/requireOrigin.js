const ApiError = require('../utils/ApiError')
const { allowedOrigins } = require('../config/env')

// Defesa contra CSRF para o cookie de sessão: toda escrita precisa vir de uma
// origem explicitamente autorizada (FRONTEND_URL).
function requireOrigin(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next()
  const origin = req.get('Origin')
  if (!origin || !allowedOrigins.includes(origin)) {
    return next(new ApiError(403, 'Origem da solicitação não autorizada.', 'INVALID_ORIGIN'))
  }
  next()
}

module.exports = requireOrigin
