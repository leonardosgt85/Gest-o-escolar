const ApiError = require('../utils/ApiError')

const UNAVAILABLE = ['ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EHOSTUNREACH', 'ENOTFOUND', '57P01', '57P02', '57P03', '08000', '08001', '08003', '08004', '08006']
const CONFLICTS = ['23503', '23505', '23514', '23P01', '40001', '40P01']
const INVALID_VALUE = ['22P02', '22003', '22007', '22008', '23502']

function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err)

  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({ error: err.message, code: err.code || undefined, fields: err.fields || undefined })
  }
  if (err?.name === 'ZodError') {
    const fields = err.issues.map((i) => ({ field: i.path.join('.'), message: i.message }))
    return res.status(422).json({ error: 'Revise os campos informados.', code: 'VALIDATION_ERROR', fields })
  }
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.', code: 'INVALID_JSON' })
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Corpo da requisição excede o limite.', code: 'PAYLOAD_TOO_LARGE' })

  if (UNAVAILABLE.includes(err.code) || UNAVAILABLE.includes(err.cause?.code) || err.name === 'KnexTimeoutError') {
    return res.status(503).json({ error: 'Banco de dados indisponível. Tente novamente após restabelecer a conexão.', code: 'DATABASE_UNAVAILABLE' })
  }
  if (CONFLICTS.includes(err.code)) {
    return res.status(409).json({ error: 'Operação conflita com registros vinculados, duplicados ou regras de integridade.', code: 'CONFLICT' })
  }
  if (INVALID_VALUE.includes(err.code)) {
    return res.status(422).json({ error: 'Valor inválido para este cadastro.', code: 'INVALID_VALUE' })
  }

  // Nunca devolve SQL/credenciais ao cliente; o log guarda só o essencial.
  console.error(JSON.stringify({ event: 'request_error', method: req.method, path: req.path, code: err.code || 'INTERNAL_ERROR' }))
  return res.status(500).json({ error: 'Não foi possível concluir a solicitação.', code: 'INTERNAL_ERROR' })
}

module.exports = errorHandler
