// Erro de negócio com status HTTP. `code` é um identificador estável para o
// frontend/testes; `fields` carrega erros por campo (validação).
class ApiError extends Error {
  constructor(statusCode, message, code = null, fields = null) {
    super(message)
    this.statusCode = statusCode
    this.code = code
    this.fields = fields
  }
}

module.exports = ApiError
