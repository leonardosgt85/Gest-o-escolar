const { z } = require('zod')
const { resources } = require('../shared/catalog')

const idSchema = z.string().uuid();
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use AAAA-MM-DD').refine(s => !Number.isNaN(Date.parse(`${s}T00:00:00Z`)) && new Date(`${s}T00:00:00Z`).toISOString().slice(0,10) === s, 'Data inválida');
const datetime = z.iso.datetime({offset:true}).refine(s => !Number.isNaN(Date.parse(s)), 'Data e hora inválidas');
const integer = z.number().int().safe().min(-2147483648).max(2147483647);
const password = minimum => z.string().min(minimum).max(128).refine(value => Buffer.byteLength(value,'utf8') <= 72,'Senha deve ter no máximo 72 bytes em UTF-8');
function fieldSchema(f) {
  if (f.type === 'reference') return idSchema;
  if (f.type === 'boolean') return z.boolean();
  if (f.type === 'integer') return integer;
  if (f.type === 'money') return f.key === 'opening_balance_cents' ? integer : integer.min(0);
  if (f.type === 'number') return z.number().finite().min(0).max(999999.99).refine(n => Math.abs(n * 100 - Math.round(n * 100)) < 1e-7, 'Use até duas casas decimais');
  if (f.type === 'date') return date;
  if (f.type === 'datetime-local') return datetime;
  if (f.type === 'select') return z.enum(f.options);
  if (f.type === 'email') return z.string().trim().toLowerCase().email().max(254);
  if (f.type === 'password') return password(12);
  return z.string().trim().min(1).max(f.type === 'textarea' ? 10000 : 500);
}
function resourceSchema(resource, partial = false) {
  const shape = {};
  for (const f of resources[resource].fields) shape[f.key] = f.required || (resource === 'users' && f.key === 'password' && !partial) ? fieldSchema(f) : fieldSchema(f).nullable().optional();
  if (['classes','lessons'].includes(resource) && !shape.teacher_id) shape.teacher_id = idSchema.nullable().optional();
  const schema = z.object(shape).strict();
  return partial ? schema.partial().refine(v => Object.keys(v).length > 0, 'Informe pelo menos um campo') : schema;
}
const loginSchema = z.object({ email: z.string().trim().toLowerCase().email().max(254), password: password(1) }).strict();
const paymentSchema = z.object({ invoice_id: idSchema, amount_cents: integer.positive(), method: z.string().trim().min(1).max(50), idempotency_key: z.string().trim().min(8).max(128) }).strict();
const jobSchema = z.object({ route_id: z.string().min(1).max(100), payload: z.record(z.string(), z.unknown()) }).strict();
function parseListQuery(query, resource) {
  const shape = { page: z.coerce.number().int().min(1).max(100000).default(1), pageSize: z.coerce.number().int().min(1).max(100).default(25), search: z.string().trim().max(200).optional() };
  for (const f of resources[resource].fields.filter(f => f.type === 'reference')) shape[f.key] = idSchema.optional();
  if (['classes','lessons'].includes(resource)) shape.teacher_id = idSchema.optional();
  if (resource === 'students') Object.assign(shape, { course_id: idSchema.optional(), class_id: idSchema.optional(), guardian_id: idSchema.optional(), code: z.string().max(100).optional(), cpf: z.string().max(30).optional(), name: z.string().max(200).optional(), enrollment_number: z.string().max(100).optional(), year: z.coerce.number().int().min(1900).max(2200).optional(), status: z.enum(resources.enrollments.fields.find(f => f.key === 'status').options).optional() });
  return z.object(shape).strict().parse(query);
}
const reportQuerySchema = z.object({ year: z.coerce.number().int().min(1900).max(2200).optional(), class_id: idSchema.optional(), student_id: idSchema.optional() }).strict();

module.exports = { idSchema, resourceSchema, loginSchema, paymentSchema, jobSchema, parseListQuery, reportQuerySchema }
