const pg = require('pg')

// PostgreSQL DATE is a calendar date, never a timezone-bearing JavaScript Date.
pg.types.setTypeParser(1082, value => value);
function calendarDate(value) {
  if (value instanceof Date) return [value.getFullYear(),String(value.getMonth()+1).padStart(2,'0'),String(value.getDate()).padStart(2,'0')].join('-');
  return typeof value === 'string' ? value.slice(0,10) : value;
}

module.exports = { calendarDate }
