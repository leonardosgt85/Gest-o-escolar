// Metadados dos cadastros (resources.json) e catálogo de rotas/menus
// (catalog.json). O frontend recebe os dois via GET /api/catalog — não há
// cópia desses arquivos no projeto React.
const resources = require('./resources.json')
const catalog = require('./catalog.json')

const hasResource = (resource) => Object.hasOwn(resources, resource)

module.exports = { resources, catalog, hasResource }
