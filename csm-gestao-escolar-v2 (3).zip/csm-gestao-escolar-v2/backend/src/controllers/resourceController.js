const asyncHandler = require('../utils/asyncHandler')
const db = require('../config/db')
const { idSchema, resourceSchema, parseListQuery } = require('../utils/validation')
const { assertAccess } = require('../services/policyService')
const resourceService = require('../services/resourceService')

const options = asyncHandler(async (req, res) => {
  res.json({ data: await resourceService.listOptions(db, req.params.resource, req.user) })
})

const list = asyncHandler(async (req, res) => {
  const { resource } = req.params
  assertAccess(req.user, resource)
  res.json(await resourceService.listRecords(db, resource, req.user, parseListQuery(req.query, resource)))
})

const getById = asyncHandler(async (req, res) => {
  const { resource } = req.params
  res.json({ data: await resourceService.getRecord(db, resource, idSchema.parse(req.params.id), req.user) })
})

const create = asyncHandler(async (req, res) => {
  const { resource } = req.params
  assertAccess(req.user, resource, true)
  const data = await resourceService.saveRecord(db, resource, null, resourceSchema(resource).parse(req.body), req.user)
  res.status(201).json({ data })
})

const update = asyncHandler(async (req, res) => {
  const { resource } = req.params
  assertAccess(req.user, resource, true)
  const id = idSchema.parse(req.params.id)
  res.json({ data: await resourceService.saveRecord(db, resource, id, resourceSchema(resource, true).parse(req.body), req.user) })
})

const remove = asyncHandler(async (req, res) => {
  const { resource } = req.params
  assertAccess(req.user, resource, true)
  res.json({ data: await resourceService.deleteRecord(db, resource, idSchema.parse(req.params.id), req.user) })
})

module.exports = { options, list, getById, create, update, remove }
