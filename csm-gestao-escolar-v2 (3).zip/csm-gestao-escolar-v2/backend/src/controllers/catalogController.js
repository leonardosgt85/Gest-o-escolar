const asyncHandler = require('../utils/asyncHandler')
const db = require('../config/db')
const { resources, catalog } = require('../shared/catalog')
const reportService = require('../services/reportService')

const getCatalog = (req, res) => res.json({ data: { routes: catalog.routes, resources, modules: catalog.modules } })

const getDashboard = asyncHandler(async (req, res) => {
  res.json({ data: await reportService.dashboard(db, req.user) })
})

module.exports = { getCatalog, getDashboard }
