const asyncHandler = require('../utils/asyncHandler')
const db = require('../config/db')
const { idSchema, reportQuerySchema } = require('../utils/validation')
const reportService = require('../services/reportService')

const getReport = asyncHandler(async (req, res) => {
  res.json({ data: await reportService.buildReport(db, req.params.report, reportQuerySchema.parse(req.query), req.user) })
})

const studentSummary = asyncHandler(async (req, res) => {
  res.json({ data: await reportService.studentSummary(db, idSchema.parse(req.params.studentId), req.user) })
})

module.exports = { getReport, studentSummary }
