const asyncHandler = require('../utils/asyncHandler')
const db = require('../config/db')
const { jobSchema } = require('../utils/validation')
const integrationService = require('../services/integrationService')

const NOTICE_LIST = 'Fila exclusivamente local. Nenhum serviço externo foi acionado.'
const NOTICE_SAVE = 'Solicitação salva apenas na fila local. Nenhum envio, pagamento ou assinatura foi executado.'

const list = asyncHandler(async (req, res) => {
  res.json({ data: await integrationService.list(db, req.user), notice: NOTICE_LIST })
})

const create = asyncHandler(async (req, res) => {
  const job = await integrationService.enqueue(db, jobSchema.parse(req.body), req.user)
  res.status(201).json({ data: job, notice: NOTICE_SAVE })
})

module.exports = { list, create }
