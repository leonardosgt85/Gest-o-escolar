const asyncHandler = require('../utils/asyncHandler')
const db = require('../config/db')
const { paymentSchema } = require('../utils/validation')
const paymentService = require('../services/paymentService')

const create = asyncHandler(async (req, res) => {
  const result = await paymentService.payInvoice(db, paymentSchema.parse(req.body), req.user)
  res.status(result.repeated ? 200 : 201).json({ data: result.payment, repeated: result.repeated })
})

module.exports = { create }
