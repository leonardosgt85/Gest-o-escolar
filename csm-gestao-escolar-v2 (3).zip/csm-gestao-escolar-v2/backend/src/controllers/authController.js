const asyncHandler = require('../utils/asyncHandler')
const authService = require('../services/authService')
const { loginSchema } = require('../utils/validation')
const { COOKIE_NAME } = require('../middleware/auth')
const { isProd } = require('../config/env')

const cookieOptions = (expiresAt) => ({
  httpOnly: true, // JS do navegador não lê o cookie (mitiga roubo de sessão por XSS)
  secure: isProd,
  sameSite: 'lax',
  expires: expiresAt,
  path: '/',
})

const login = asyncHandler(async (req, res) => {
  const { email, password } = loginSchema.parse(req.body)
  const { rawToken, expiresAt, user } = await authService.login(email, password, {
    userAgent: req.headers['user-agent'],
    ipAddress: req.ip,
  })
  res.cookie(COOKIE_NAME, rawToken, cookieOptions(expiresAt))
  res.json({ user })
})

const logout = asyncHandler(async (req, res) => {
  await authService.logout(req.sessionToken)
  res.clearCookie(COOKIE_NAME, { path: '/' })
  res.status(204).send()
})

const me = (req, res) => res.json({ user: authService.publicUser(req.user) })

module.exports = { login, logout, me }
