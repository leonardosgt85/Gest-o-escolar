const bcrypt = require('bcryptjs')
const db = require('../config/db')
const ApiError = require('../utils/ApiError')
const sessionService = require('./sessionService')

// Hash fixo usado quando o e-mail não existe, para que o tempo de resposta não
// revele se a conta existe.
const DUMMY_HASH = '$2b$12$fo6F3N1N4EQNZvqQgbziHeZk2Kkvz3Syym2F89zYPVjntY8kY3sli'

async function login(email, password, meta = {}) {
  const user = await db('users').whereRaw('lower(email) = ?', [email]).first()
  const valid = await bcrypt.compare(password, user?.password_hash || DUMMY_HASH)
  if (!user || !user.active || !valid) throw new ApiError(401, 'E-mail ou senha inválidos.', 'INVALID_CREDENTIALS')

  sessionService.cleanupExpired().catch(() => {})
  const { rawToken, expiresAt } = await sessionService.create(user.id, meta)
  return { rawToken, expiresAt, user: publicUser(user) }
}

async function logout(rawToken) {
  await sessionService.revoke(rawToken)
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role }
}

module.exports = { login, logout, publicUser }
