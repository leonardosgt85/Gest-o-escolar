const { randomUUID } = require('node:crypto')
const bcrypt = require('bcryptjs')
const { resources } = require('../shared/catalog')
const ApiError = require('../utils/ApiError')
const { calendarDate } = require('../utils/dates')
const { assertAccess, classScope, scopedQuery } = require('./policyService')
const { audit } = require('./auditService')

function columns(resource) {
  const fields = resources[resource].fields.map(f => f.key).filter(key => key !== 'password');
  if (['classes','lessons'].includes(resource) && !fields.includes('teacher_id')) fields.push('teacher_id');
  return ['id',...fields,...(resource === 'invoices' ? ['paid_cents'] : []),'created_at','updated_at'];
}
function publicRow(resource,row) {
  if (!row) return row;
  return {...Object.fromEntries(columns(resource).map(key => [key, row[key]])),...(resource === 'invoices' ? {balance_cents:row.amount_cents-row.paid_cents} : {})};
}
async function enrichInvoices(db,rows) {
  if (!rows.length) return rows;
  const sums = await db('payments').whereIn('invoice_id',rows.map(r => r.id)).groupBy('invoice_id').select('invoice_id').sum({paid:'amount_cents'});
  const map = new Map(sums.map(s => [s.invoice_id,Number(s.paid)]));
  return rows.map(row => ({...row,paid_cents:map.get(row.id) || 0,balance_cents:row.amount_cents-(map.get(row.id) || 0)}));
}
function filteredQuery(db,resource,user,filters) {
  const query = scopedQuery(db,resource,user);
  if (filters.search) {
    const searchable = resources[resource].fields.filter(f => ['text','textarea','email'].includes(f.type)).map(f => f.key);
    if (searchable.length) query.where(function () { searchable.forEach((field,index) => this[index ? 'orWhereILike' : 'whereILike'](`${resource}.${field}`,`%${filters.search.replaceAll('\\','\\\\').replaceAll('%','\\%').replaceAll('_','\\_')}%`)); });
  }
  for (const f of resources[resource].fields.filter(f => f.type === 'reference')) if (filters[f.key]) query.where(`${resource}.${f.key}`,filters[f.key]);
  if (resource === 'students') {
    for (const key of ['code','cpf','name','enrollment_number']) if (filters[key]) query.whereILike(`students.${key}`,`%${filters[key].replaceAll('\\','\\\\').replaceAll('%','\\%').replaceAll('_','\\_')}%`);
    if (filters.guardian_id) query.whereExists(function () { this.select('guardian_links.id').from('guardian_links').whereColumn('guardian_links.student_id','students.id').where('guardian_links.guardian_id',filters.guardian_id); });
    if (filters.course_id || filters.class_id || filters.year || filters.status) query.whereExists(function () {
      this.select('filter_enrollment.id').from('enrollments as filter_enrollment').join('classes as filter_class','filter_class.id','filter_enrollment.class_id').join('academic_years as filter_year','filter_year.id','filter_class.academic_year_id').whereColumn('filter_enrollment.student_id','students.id');
      if (filters.course_id) this.where('filter_class.course_id',filters.course_id);
      if (filters.class_id) this.where('filter_class.id',filters.class_id);
      if (filters.year) this.where('filter_year.year',filters.year);
      if (filters.status) this.where('filter_enrollment.status',filters.status);
    });
  }
  return query;
}
async function listRecords(db,resource,user,filters) {
  const query = filteredQuery(db,resource,user,filters);
  const [{total},rows] = await Promise.all([query.clone().count({total:'*'}).first(),query.clone().select(columns(resource).map(c => `${resource}.${c}`)).orderBy(`${resource}.created_at`,'desc').orderBy(`${resource}.id`,'asc').limit(filters.pageSize).offset((filters.page-1)*filters.pageSize)]);
  return {data:resource === 'invoices' ? await enrichInvoices(db,rows) : rows,pagination:{page:filters.page,pageSize:filters.pageSize,total:Number(total)}};
}



async function ensureRow(trx,table,id) { const row = await trx(table).where({id}).forShare().first(); if (!row) throw new ApiError(409, 'O registro vinculado não existe.', 'INVALID_REFERENCE'); return row; }
async function context(trx,resource,row,user,previous) {
  for (const field of resources[resource].fields.filter(f => f.type === 'reference')) if (row[field.key] && !(resource === 'enrollments' && field.key === 'class_id')) await ensureRow(trx,field.reference,row[field.key]);
  if (resource === 'users' && row.active === null) throw new ApiError(422, 'Informe se o usuário está ativo.', 'INVALID_ACTIVE');
  if (['classes','lessons'].includes(resource) && row.teacher_id) {
    const teacher = await ensureRow(trx,'users',row.teacher_id);
    if (!teacher.active || teacher.role !== 'professor') throw new ApiError(409, 'Atribua um professor ativo.', 'INVALID_TEACHER');
  }
  if (resource === 'academic_years') {
    if (row.starts_on && row.ends_on && calendarDate(row.ends_on) < calendarDate(row.starts_on)) throw new ApiError(422, 'O término deve ocorrer depois do início.', 'INVALID_DATES');
    if (previous) {
      const outside = trx('lessons').join('classes','classes.id','lessons.class_id').where('classes.academic_year_id',row.id).where(function () {
        if (row.starts_on) this.orWhere('lessons.date','<',calendarDate(row.starts_on));
        if (row.ends_on) this.orWhere('lessons.date','>',calendarDate(row.ends_on));
      });
      if ((row.starts_on || row.ends_on) && await outside.first()) throw new ApiError(409, 'O intervalo excluiria aulas já registradas neste ano letivo.', 'LINKED_LESSON_DATES');
    }
  }
  if (resource === 'events' && new Date(row.ends_at) < new Date(row.starts_at)) throw new ApiError(422, 'O término deve ocorrer depois do início.', 'INVALID_DATES');
  if (resource === 'classes' && row.capacity != null) {
    const {total} = await trx('enrollments').where({class_id:row.id,status:'Cursando'}).count({total:'*'}).first();
    if (Number(total) > row.capacity) throw new ApiError(409, 'A capacidade não pode ficar abaixo do total de alunos cursando.', 'CLASS_CAPACITY');
  }
  if (resource === 'classes' && previous && row.academic_year_id !== previous.academic_year_id) {
    if (await trx('enrollments').where({class_id:row.id}).first() || await trx('lessons').where({class_id:row.id}).first()) throw new ApiError(409, 'A turma possui matrículas ou aulas; preserve o ano letivo.', 'LINKED_ACADEMIC_RECORDS');
  }
  if (resource === 'enrollments') {
    const klass = await trx('classes').where({id:row.class_id}).forUpdate().first();
    if (!klass) throw new ApiError(409, 'A turma vinculada não existe.', 'INVALID_REFERENCE');
    const year = await ensureRow(trx,'academic_years',klass.academic_year_id);
    if (year.ends_on && calendarDate(row.enrolled_on) > calendarDate(year.ends_on)) throw new ApiError(409, 'A matrícula não pode ocorrer depois do ano letivo.', 'ENROLLMENT_DATE');
    if (row.status === 'Cursando' && klass.capacity != null) {
      const query = trx('enrollments').where({class_id:row.class_id,status:'Cursando'}); if (previous) query.whereNot('id',row.id);
      const {total} = await query.count({total:'*'}).first(); if (Number(total) >= klass.capacity) throw new ApiError(409, 'A turma atingiu sua capacidade.', 'CLASS_CAPACITY');
    }
    if (previous && (previous.class_id !== row.class_id || previous.student_id !== row.student_id || (previous.status === 'Cursando' && row.status !== 'Cursando'))) {
      const grades = await trx('grades').where({enrollment_id:row.id}).first();
      const attendance = await trx('attendance').join('lessons','lessons.id','attendance.lesson_id').where({'attendance.student_id':previous.student_id,'lessons.class_id':previous.class_id}).first();
      if (grades || attendance) throw new ApiError(409, 'A matrícula possui notas ou frequência; preserve o vínculo e crie outra matrícula.', 'LINKED_ACADEMIC_RECORDS');
    }
  }
  if (resource === 'lessons') {
    const klass = await ensureRow(trx,'classes',row.class_id), year = await ensureRow(trx,'academic_years',klass.academic_year_id);
    const dateValue = calendarDate(row.date);
    if ((year.starts_on && dateValue < calendarDate(year.starts_on)) || (year.ends_on && dateValue > calendarDate(year.ends_on))) throw new ApiError(409, 'A aula precisa ocorrer dentro do ano letivo.', 'LESSON_DATE');
    if (previous && row.class_id !== previous.class_id && await trx('attendance').where({lesson_id:row.id}).first()) throw new ApiError(409, 'A aula possui frequência; não altere sua turma.', 'LINKED_ATTENDANCE');
    if (previous && (row.class_id !== previous.class_id || row.subject_id !== previous.subject_id)) {
      const otherLesson = await trx('lessons').where({class_id:previous.class_id,subject_id:previous.subject_id}).whereNot('id',row.id).first();
      if (!otherLesson && await trx('grades').join('enrollments','enrollments.id','grades.enrollment_id').where({'enrollments.class_id':previous.class_id,'grades.subject_id':previous.subject_id}).first()) throw new ApiError(409, 'A aula sustenta notas desta disciplina; preserve o vínculo.', 'LINKED_GRADES');
    }
    if (user.role === 'professor') {
      if (!await classScope(trx('classes'),user).where('classes.id',row.class_id).first()) throw new ApiError(403, 'Turma não atribuída a este professor.', 'FORBIDDEN');
      if (row.teacher_id && row.teacher_id !== user.id) throw new ApiError(403, 'Você só pode registrar aulas atribuídas a você.', 'FORBIDDEN');
      row.teacher_id = user.id;
    }
  }
  if (resource === 'attendance') {
    const lesson = await ensureRow(trx,'lessons',row.lesson_id);
    if (!await trx('enrollments').where({student_id:row.student_id,class_id:lesson.class_id,status:'Cursando'}).forShare().first()) throw new ApiError(409, 'O aluno precisa estar cursando a turma da aula.', 'INVALID_ATTENDANCE');
    if (user.role === 'professor' && !await scopedQuery(trx,'lessons',user).where('lessons.id',row.lesson_id).first()) throw new ApiError(403, 'Aula não atribuída a este professor.', 'FORBIDDEN');
  }
  if (resource === 'grades') {
    const enrollment = await ensureRow(trx,'enrollments',row.enrollment_id);
    if (enrollment.status !== 'Cursando') throw new ApiError(409, 'Só é possível lançar nota em matrícula cursando.', 'INVALID_ENROLLMENT');
    if (row.absent && row.value != null) throw new ApiError(422, 'Aluno ausente deve ficar sem nota.', 'ABSENT_GRADE');
    if (!await trx('lessons').where({class_id:enrollment.class_id,subject_id:row.subject_id}).forShare().first()) throw new ApiError(409, 'A disciplina precisa possuir aula vinculada à turma.', 'INVALID_SUBJECT');
    if (user.role === 'professor') {
      const klass = await ensureRow(trx,'classes',enrollment.class_id);
      const assignment = await trx('lessons').where({class_id:enrollment.class_id,subject_id:row.subject_id,teacher_id:user.id}).first();
      if (klass.teacher_id !== user.id && !assignment) throw new ApiError(403, 'Disciplina e turma não atribuídas a este professor.', 'FORBIDDEN');
    }
  }
  if (resource === 'occurrences' && user.role === 'professor' && !await scopedQuery(trx,'students',user).where('students.id',row.student_id).first()) throw new ApiError(403, 'Aluno não vinculado às suas turmas.', 'FORBIDDEN');
  if (resource === 'invoices') {
    if (row.amount_cents < (previous?.paid_cents || 0)) throw new ApiError(409, 'O valor não pode ficar abaixo do total já quitado.', 'BELOW_PAID_AMOUNT');
    if (previous?.paid_cents && (row.student_id !== previous.student_id || row.guardian_id !== previous.guardian_id)) throw new ApiError(409, 'A cobrança possui pagamentos; preserve aluno e responsável.', 'LINKED_PAYMENTS');
    if (row.guardian_id && !await trx('guardian_links').where({student_id:row.student_id,guardian_id:row.guardian_id,financial_responsible:true}).first()) throw new ApiError(409, 'O responsável financeiro precisa estar vinculado ao aluno.', 'INVALID_GUARDIAN');
  }
}
async function guardLastAdmin(trx,previous,next,isDelete) {
  const admins = await trx('users').where({role:'admin',active:true}).orderBy('id').forUpdate().select('id');
  if (previous?.role === 'admin' && previous.active && (isDelete || next.role !== 'admin' || next.active === false) && admins.length <= 1) throw new ApiError(409, 'Preserve pelo menos um administrador ativo.', 'LAST_ADMIN');
}
async function saveRecord(db,resource,id,input,user) {
  assertAccess(user,resource,true);
  return db.transaction(async trx => {
    if (resource === 'users') await trx.raw("SELECT pg_advisory_xact_lock(hashtext('school_admin_guard'))");
    const previous = id ? await scopedQuery(trx,resource,user).where(`${resource}.id`,id).forUpdate().first() : null;
    if (id && !previous) throw new ApiError(404, 'Registro não encontrado.', 'NOT_FOUND');
    const row = {...previous,...input,id:id || randomUUID()};
    if (resource === 'users') {
      if (!id && !input.password) throw new ApiError(422, 'Informe uma senha de pelo menos 12 caracteres.', 'PASSWORD_REQUIRED');
      row.active ??= true;
      await guardLastAdmin(trx,previous,row,false);
      if (input.password) row.password_hash = await bcrypt.hash(input.password,12);
      delete row.password;
    }
    await context(trx,resource,row,user,previous);
    const insertable = {};
    for (const key of columns(resource).filter(key => !['created_at','updated_at','paid_cents'].includes(key))) if (row[key] !== undefined) insertable[key] = row[key];
    if (resource === 'users') insertable.password_hash = row.password_hash;
    insertable.updated_at = new Date();
    const [saved] = id ? await trx(resource).where({id}).update(insertable).returning('*') : await trx(resource).insert(insertable).returning('*');
    if (resource === 'users' && previous && (input.password || row.active === false || row.role !== previous.role)) await trx('sessions').where({user_id:id}).whereNull('revoked_at').update({revoked_at:new Date(),updated_at:new Date()});
    await audit(trx,user,id ? 'update' : 'create',resource,saved.id,{fields:Object.keys(input).filter(k => k !== 'password')});
    return publicRow(resource,saved);
  });
}
async function deleteRecord(db,resource,id,user) {
  assertAccess(user,resource,true);
  return db.transaction(async trx => {
    if (resource === 'users') await trx.raw("SELECT pg_advisory_xact_lock(hashtext('school_admin_guard'))");
    const row = await scopedQuery(trx,resource,user).where(`${resource}.id`,id).forUpdate().first();
    if (!row) throw new ApiError(404, 'Registro não encontrado.', 'NOT_FOUND');
    if (resource === 'users') await guardLastAdmin(trx,row,{},true);
    if (resource === 'invoices' && (row.paid_cents > 0 || await trx('payments').where({invoice_id:id}).first())) throw new ApiError(409, 'Não é possível excluir obrigação que possui pagamento.', 'LINKED_PAYMENTS');
    if (resource === 'enrollments' && await trx('attendance').join('lessons','lessons.id','attendance.lesson_id').where({'attendance.student_id':row.student_id,'lessons.class_id':row.class_id}).first()) throw new ApiError(409, 'A matrícula possui frequência registrada.', 'LINKED_ATTENDANCE');
    if (resource === 'lessons') {
      const otherLesson = await trx('lessons').where({class_id:row.class_id,subject_id:row.subject_id}).whereNot('id',row.id).first();
      if (!otherLesson && await trx('grades').join('enrollments','enrollments.id','grades.enrollment_id').where({'enrollments.class_id':row.class_id,'grades.subject_id':row.subject_id}).first()) throw new ApiError(409, 'A aula sustenta notas desta disciplina; preserve o vínculo.', 'LINKED_GRADES');
    }
    await audit(trx,user,'delete',resource,id);
    await trx(resource).where({id}).del();
    return {id,deleted:true};
  });
}


// ---------------------------------------------------------------------------
// Leitura de um registro e opções para selects (usadas pelos controllers)
// ---------------------------------------------------------------------------
async function getRecord(db, resource, id, user) {
  assertAccess(user, resource)
  let row = await scopedQuery(db, resource, user)
    .where(`${resource}.id`, id)
    .select(columns(resource).map((c) => `${resource}.${c}`))
    .first()
  if (!row) throw new ApiError(404, 'Registro não encontrado.', 'NOT_FOUND')
  if (resource === 'invoices') [row] = await enrichInvoices(db, [row])
  return row
}

// Lista enxuta (id + rótulo) para preencher <select> de referências. Financeiro
// pode ler alunos/responsáveis, e perfis acadêmicos podem ler professores,
// mesmo sem acesso completo ao cadastro.
async function listOptions(db, resource, user) {
  if (!Object.hasOwn(resources, resource)) throw new ApiError(404, 'Cadastro não encontrado.', 'NOT_FOUND')
  const financeLookup = user.role === 'financeiro' && ['students', 'guardians'].includes(resource)
  const teacherLookup = ['admin', 'secretaria', 'professor'].includes(user.role) && resource === 'users'
  if (!financeLookup && !teacherLookup) assertAccess(user, resource)
  const query = scopedQuery(db, resource, user)
  let label =
    resources[resource].fields.find((f) => f.key === 'name')?.key ||
    resources[resource].fields.find((f) => f.type === 'text')?.key ||
    resources[resource].fields[0].key
  if (resource === 'users') {
    query.where({ active: true, role: 'professor' })
    if (user.role === 'professor') query.where({ id: user.id })
    label = 'name'
  }
  if (resource === 'enrollments') {
    query
      .join('students', 'students.id', 'enrollments.student_id')
      .join('classes', 'classes.id', 'enrollments.class_id')
      .select('enrollments.id', db.raw("students.name || ' — ' || classes.name AS label"))
  } else if (resource === 'lessons') {
    query
      .join('classes', 'classes.id', 'lessons.class_id')
      .join('subjects', 'subjects.id', 'lessons.subject_id')
      .select('lessons.id', db.raw("classes.name || ' — ' || subjects.name || ' — ' || lessons.date::text AS label"))
  } else {
    query.select(`${resource}.id`, `${resource}.${label} as label`)
  }
  return query.orderBy('label').limit(1000)
}

module.exports = { columns, publicRow, enrichInvoices, filteredQuery, listRecords, getRecord, listOptions, saveRecord, deleteRecord }
