const crypto = require('crypto')
const db = require('../config/db')
const { sessionHours } = require('../config/env')

const SESSION_DURATION_MS = sessionHours * 60 * 60 * 1000

function hashToken(rawToken) {
  return crypto.createHash('sha256').update(rawToken).digest('hex')
}

// Token opaco (não é JWT): só o hash fica no banco, o valor bruto só existe no
// cookie httpOnly do navegador.
async function create(userId, { userAgent, ipAddress } = {}) {
  const rawToken = crypto.randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS)
  await db('sessions').insert({
    id: crypto.randomUUID(),
    user_id: userId,
    token_hash: hashToken(rawToken),
    user_agent: userAgent ? String(userAgent).slice(0, 300) : null,
    ip_address: ipAddress || null,
    expires_at: expiresAt,
  })
  return { rawToken, expiresAt }
}

// Devolve o usuário dono da sessão se ela existir, não tiver expirado/sido
// revogada e o usuário continuar ativo; senão null (força novo login). O perfil
// é sempre relido do banco.
async function validate(rawToken) {
  if (!rawToken) return null
  const row = await db('sessions as s')
    .join('users as u', 'u.id', 's.user_id')
    .select('s.id as session_id', 's.expires_at', 's.revoked_at', 'u.id', 'u.name', 'u.email', 'u.role', 'u.active')
    .where('s.token_hash', hashToken(rawToken))
    .first()
  if (!row || row.revoked_at || new Date(row.expires_at) < new Date() || !row.active) return null
  return { id: row.id, name: row.name, email: row.email, role: row.role, sessionId: row.session_id }
}

async function revoke(rawToken) {
  if (!rawToken) return
  await db('sessions').where({ token_hash: hashToken(rawToken) }).update({ revoked_at: new Date(), updated_at: new Date() })
}

async function revokeAllForUser(userId) {
  await db('sessions').where({ user_id: userId }).whereNull('revoked_at').update({ revoked_at: new Date(), updated_at: new Date() })
}

// Remove sessões expiradas há mais de 30 dias (best-effort a cada login).
async function cleanupExpired() {
  await db('sessions').where('expires_at', '<', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)).del()
}

module.exports = { create, validate, revoke, revokeAllForUser, cleanupExpired, SESSION_DURATION_MS }
