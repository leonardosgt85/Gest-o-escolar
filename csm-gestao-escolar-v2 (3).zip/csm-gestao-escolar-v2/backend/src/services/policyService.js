const ApiError = require('../utils/ApiError')
const { hasResource } = require('../shared/catalog')

const finance = new Set(['invoices','accounts','vendors','payables']);
const secretary = new Set(['students','guardians','guardian_links','courses','academic_years','classes','subjects','enrollments','lessons','attendance','grades','occurrences','events','contracts','documents','messages','lookup_entries']);
const teacherRead = new Set(['students','courses','academic_years','classes','subjects','enrollments','lessons','attendance','grades','occurrences']);
const teacherWrite = new Set(['lessons','attendance','grades','occurrences']);
function canAccess(user, resource, write = false) {
  if (!hasResource(resource)) return false;
  if (user.role === 'admin') return true;
  if (user.role === 'secretaria') return secretary.has(resource);
  if (user.role === 'financeiro') return finance.has(resource);
  if (user.role === 'professor') return (write ? teacherWrite : teacherRead).has(resource);
  return false;
}
function assertAccess(user, resource, write = false) {
  if (!hasResource(resource)) throw new ApiError(404, 'Cadastro não encontrado.', 'NOT_FOUND');
  if (!canAccess(user,resource,write)) throw new ApiError(403, 'Seu perfil não pode acessar este cadastro.', 'FORBIDDEN');
}
function classScope(query, user, classAlias = 'classes') {
  return query.where(function () {
    this.where(`${classAlias}.teacher_id`, user.id).orWhereExists(function () {
      this.select('assigned_lesson.id').from('lessons as assigned_lesson').whereColumn('assigned_lesson.class_id',`${classAlias}.id`).where('assigned_lesson.teacher_id',user.id);
    });
  });
}
function lessonScope(query, user, lessonAlias = 'lessons') {
  return query.where(function () {
    this.where(`${lessonAlias}.teacher_id`,user.id).orWhereExists(function () {
      this.select('own_class.id').from('classes as own_class').whereColumn('own_class.id',`${lessonAlias}.class_id`).where('own_class.teacher_id',user.id);
    });
  });
}
function scopedQuery(db, resource, user) {
  const query = db(resource);
  if (user.role !== 'professor') return query;
  if (resource === 'classes') return classScope(query,user);
  if (resource === 'lessons') return lessonScope(query,user);
  if (resource === 'enrollments') return query.whereExists(function () { this.select('teacher_class.id').from('classes as teacher_class').whereColumn('teacher_class.id','enrollments.class_id'); classScope(this,user,'teacher_class'); });
  if (resource === 'students' || resource === 'occurrences') return query.whereExists(function () {
    this.select('teacher_enrollment.id').from('enrollments as teacher_enrollment').join('classes as teacher_class','teacher_class.id','teacher_enrollment.class_id').whereColumn('teacher_enrollment.student_id',`${resource === 'students' ? 'students.id' : 'occurrences.student_id'}`); classScope(this,user,'teacher_class');
  });
  if (resource === 'attendance') return query.whereExists(function () {
    this.select('teacher_lesson.id').from('lessons as teacher_lesson').whereColumn('teacher_lesson.id','attendance.lesson_id'); lessonScope(this,user,'teacher_lesson');
  });
  if (resource === 'grades') return query.whereExists(function () {
    this.select('teacher_enrollment.id').from('enrollments as teacher_enrollment').join('classes as teacher_class','teacher_class.id','teacher_enrollment.class_id').whereColumn('teacher_enrollment.id','grades.enrollment_id').where(function () {
      this.where('teacher_class.teacher_id',user.id).orWhereExists(function () { this.select('teacher_lesson.id').from('lessons as teacher_lesson').whereColumn('teacher_lesson.class_id','teacher_class.id').whereColumn('teacher_lesson.subject_id','grades.subject_id').where('teacher_lesson.teacher_id',user.id); });
    });
  });
  return query;
}
function assertRole(user, roles) { if (!roles.includes(user.role)) throw new ApiError(403, 'Seu perfil não pode executar esta operação.', 'FORBIDDEN'); }

module.exports = { canAccess, assertAccess, classScope, lessonScope, scopedQuery, assertRole }
