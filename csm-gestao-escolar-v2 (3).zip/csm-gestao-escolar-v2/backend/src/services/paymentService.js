const { randomUUID } = require('node:crypto')
const ApiError = require('../utils/ApiError')
const { assertAccess } = require('./policyService')
const { audit } = require('./auditService')

async function payInvoice(db,input,user) {
  assertAccess(user,'invoices',true);
  return db.transaction(async trx => {
    await trx.raw('SELECT pg_advisory_xact_lock(hashtext(?))',[`school_payment:${input.idempotency_key}`]);
    const existing = await trx('payments').where({idempotency_key:input.idempotency_key}).first();
    if (existing) {
      if (existing.invoice_id !== input.invoice_id || existing.amount_cents !== input.amount_cents || existing.method !== input.method) throw new ApiError(409, 'A chave já foi usada para outro pagamento.', 'IDEMPOTENCY_CONFLICT');
      const invoice = await trx('invoices').where({id:existing.invoice_id}).first();
      return {payment:{...existing,remaining_cents:invoice.amount_cents-invoice.paid_cents},repeated:true};
    }
    const invoice = await trx('invoices').where({id:input.invoice_id}).forUpdate().first();
    if (!invoice) throw new ApiError(404, 'Cobrança não encontrada.', 'NOT_FOUND');
    if (input.amount_cents > invoice.amount_cents - invoice.paid_cents) throw new ApiError(409, 'O pagamento excede o saldo disponível.', 'EXCEEDS_BALANCE');
    const [payment] = await trx('payments').insert({id:randomUUID(),...input,created_by:user.id}).returning('*');
    await trx('invoices').where({id:invoice.id}).increment('paid_cents',input.amount_cents).update({updated_at:new Date()});
    await audit(trx,user,'payment','invoices',invoice.id,{payment_id:payment.id,amount_cents:payment.amount_cents});
    return {payment:{...payment,remaining_cents:invoice.amount_cents-invoice.paid_cents-input.amount_cents},repeated:false};
  });
}

module.exports = { payInvoice }
