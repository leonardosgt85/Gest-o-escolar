const ApiError = require('../utils/ApiError')
const { assertRole, scopedQuery } = require('./policyService')
const { columns, enrichInvoices } = require('./resourceService')

const notice = 'Dados locais de demonstração. Notas e frequência são registros individuais; não calculamos média, aprovação ou validade oficial.';
const titles = {'student-roster':'Relação de alunos',grades:'Notas registradas',attendance:'Frequência registrada',receivables:'Contas a receber',payables:'Contas a pagar',assets:'Bens patrimoniais',cash:'Caixas e recebimentos locais',enrollments:'Matrículas'};
const fields = {
  'student-roster': [['student_name','Aluno'],['code','Código'],['enrollment_number','Matrícula'],['class_name','Turma'],['year','Ano'],['status','Situação']],
  enrollments: [['student_name','Aluno'],['class_name','Turma'],['year','Ano'],['status','Situação'],['enrolled_on','Data da matrícula']],
  grades: [['student_name','Aluno'],['class_name','Turma'],['subject_name','Disciplina'],['period','Período'],['value','Nota'],['absent','Ausente'],['remarks','Observações']],
  attendance: [['student_name','Aluno'],['class_name','Turma'],['subject_name','Disciplina'],['date','Data'],['present','Presente'],['remarks','Observações']],
  receivables: [['student_name','Aluno'],['description','Descrição'],['due_on','Vencimento'],['amount_cents','Valor em centavos'],['paid_cents','Quitado em centavos'],['balance_cents','Saldo em centavos']],
  payables: [['vendor_name','Fornecedor'],['description','Descrição'],['due_on','Vencimento'],['amount_cents','Valor em centavos']],
  assets: [['code','Código'],['name','Bem'],['group_name','Grupo'],['sector','Setor'],['value_cents','Valor em centavos'],['status','Situação']],
  cash: [['date','Data'],['type','Tipo de registro'],['description','Descrição'],['amount_cents','Valor em centavos'],['method','Forma']],
};
function academicFilters(query,filter,{classAlias='classes',studentColumn='enrollments.student_id',yearAlias='academic_years'} = {}) {
  if (filter.class_id) query.where(`${classAlias}.id`,filter.class_id);
  if (filter.student_id) query.where(studentColumn,filter.student_id);
  if (filter.year) query.where(`${yearAlias}.year`,filter.year);
  return query;
}
function calendarYear(query,column,year) { if (year) query.whereRaw('EXTRACT(YEAR FROM ??) = ?',[column,year]); return query; }
async function buildReport(db,report,filter,user) {
  if (!Object.hasOwn(titles,report)) throw new ApiError(404, 'Relatório não encontrado.', 'NOT_FOUND');
  const finance = ['receivables','payables','cash'].includes(report);
  if (finance) assertRole(user,['admin','financeiro']);
  else if (report === 'assets') assertRole(user,['admin']);
  else assertRole(user,['admin','secretaria','professor']);
  let rows;
  if (['student-roster','enrollments'].includes(report)) {
    const query = scopedQuery(db,'enrollments',user).join('students','students.id','enrollments.student_id').join('classes','classes.id','enrollments.class_id').join('academic_years','academic_years.id','classes.academic_year_id');
    rows = await academicFilters(query,filter).select('enrollments.id','students.name as student_name','students.code','students.enrollment_number','classes.name as class_name','academic_years.year','enrollments.status','enrollments.enrolled_on').orderBy('students.name');
  }
  if (report === 'grades') {
    const query = scopedQuery(db,'grades',user).join('enrollments','enrollments.id','grades.enrollment_id').join('students','students.id','enrollments.student_id').join('classes','classes.id','enrollments.class_id').join('academic_years','academic_years.id','classes.academic_year_id').join('subjects','subjects.id','grades.subject_id');
    rows = await academicFilters(query,filter).select('grades.id','students.name as student_name','classes.name as class_name','subjects.name as subject_name','grades.period','grades.value','grades.absent','grades.remarks').orderBy('students.name').orderBy('grades.period');
  }
  if (report === 'attendance') {
    const query = scopedQuery(db,'attendance',user).join('lessons','lessons.id','attendance.lesson_id').join('classes','classes.id','lessons.class_id').join('academic_years','academic_years.id','classes.academic_year_id').join('students','students.id','attendance.student_id').join('subjects','subjects.id','lessons.subject_id');
    rows = await academicFilters(query,filter,{studentColumn:'attendance.student_id'}).select('attendance.id','students.name as student_name','classes.name as class_name','subjects.name as subject_name','lessons.date','attendance.present','attendance.remarks').orderBy('lessons.date').orderBy('students.name');
  }
  if (report === 'receivables') {
    const query = db('invoices').join('students','students.id','invoices.student_id');
    if (filter.student_id) query.where('invoices.student_id',filter.student_id);
    if (filter.class_id) query.whereExists(function () { this.select('id').from('enrollments').whereColumn('enrollments.student_id','invoices.student_id').where('enrollments.class_id',filter.class_id); });
    rows = await enrichInvoices(db,await calendarYear(query,'invoices.due_on',filter.year).select(columns('invoices').map(c => `invoices.${c}`)).select('students.name as student_name').orderBy('invoices.due_on'));
  }
  if (report === 'payables') rows = await calendarYear(db('payables').join('vendors','vendors.id','payables.vendor_id'),'payables.due_on',filter.year).select('payables.id','vendors.name as vendor_name','payables.description','payables.due_on','payables.amount_cents').orderBy('payables.due_on');
  if (report === 'assets') rows = await calendarYear(db('assets'),'assets.acquired_on',filter.year).select(columns('assets')).orderBy('name');
  if (report === 'cash') {
    const query = db('payments').join('invoices','invoices.id','payments.invoice_id');
    if (filter.student_id) query.where('invoices.student_id',filter.student_id);
    if (filter.class_id) query.whereExists(function () { this.select('id').from('enrollments').whereColumn('enrollments.student_id','invoices.student_id').where('enrollments.class_id',filter.class_id); });
    const receipts = await calendarYear(query,'payments.created_at',filter.year).select('payments.id','payments.created_at as date','invoices.description','payments.amount_cents','payments.method').orderBy('payments.created_at');
    const accounts = await db('accounts').select('id','name as description','opening_balance_cents as amount_cents');
    rows = [...accounts.map(r => ({...r,date:null,type:'Saldo inicial cadastrado',method:null})),...receipts.map(r => ({...r,type:'Recebimento local'}))];
  }
  return {title:titles[report],columns:fields[report].map(([key,label]) => ({key,label})),rows,notice: report === 'cash' ? 'Saldos iniciais são valores cadastrados, sem data de competência. Recebimentos locais não estão atribuídos a contas bancárias. Nenhum extrato, transferência ou conciliação bancária foi executado.' : report === 'payables' ? 'Obrigações cadastradas localmente; não há integração bancária nem baixa de contas a pagar nesta versão.' : notice};
}
async function dashboard(db,user) {
  const numericCount = async query => Number((await query.count({total:'*'}).first()).total);
  const financial = ['admin','financeiro'].includes(user.role);
  const academic = ['admin','secretaria','professor'].includes(user.role);
  const [students,guardians,enrollments,assets] = await Promise.all([
    academic ? numericCount(scopedQuery(db,'students',user)) : null,
    ['admin','secretaria'].includes(user.role) ? numericCount(db('guardians')) : null,
    academic ? numericCount(scopedQuery(db,'enrollments',user).where('enrollments.status','Cursando')) : null,
    user.role === 'admin' ? numericCount(db('assets')) : null,
  ]);
  let pendingInvoices=null,totalReceivableCents=null,receivedCents=null;
  if (financial) {
    const invoices = await enrichInvoices(db,await db('invoices').select('id','amount_cents','paid_cents'));
    pendingInvoices = invoices.filter(i => i.balance_cents > 0).length;
    totalReceivableCents = invoices.reduce((sum,i) => sum+i.balance_cents,0);
    receivedCents = Number((await db('payments').sum({total:'amount_cents'}).first()).total || 0);
  }
  return {students,guardians,enrollments,pendingInvoices,totalReceivableCents,receivedCents,assets};
}
async function studentSummary(db,studentId,user) {
  assertRole(user,['admin','secretaria']);
  const student = await db('students').select(columns('students')).where({id:studentId}).first();
  if (!student) throw new ApiError(404, 'Aluno não encontrado.', 'NOT_FOUND');
  const [enrollments,grades,attendance,documents] = await Promise.all([
    db('enrollments').join('classes','classes.id','enrollments.class_id').join('academic_years','academic_years.id','classes.academic_year_id').where('enrollments.student_id',studentId).select('enrollments.*','classes.name as class_name','academic_years.year'),
    db('grades').join('enrollments','enrollments.id','grades.enrollment_id').join('subjects','subjects.id','grades.subject_id').where('enrollments.student_id',studentId).select('grades.*','subjects.name as subject_name'),
    db('attendance').join('lessons','lessons.id','attendance.lesson_id').join('subjects','subjects.id','lessons.subject_id').where('attendance.student_id',studentId).select('attendance.*','lessons.date','subjects.name as subject_name'),
    db('documents').where({student_id:studentId}).select(columns('documents')),
  ]);
  return {student,enrollments,grades,attendance,documents,notice:'Documento de demonstração com dados locais. Sem validade de histórico oficial, assinatura digital ou contrato do fornecedor.'};
}

module.exports = { buildReport, dashboard, studentSummary }
