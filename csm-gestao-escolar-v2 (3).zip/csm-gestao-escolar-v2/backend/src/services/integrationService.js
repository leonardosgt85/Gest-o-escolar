const { randomUUID } = require('node:crypto')
const { catalog } = require('../shared/catalog')
const ApiError = require('../utils/ApiError')
const { assertRole } = require('./policyService')
const { audit } = require('./auditService')

const ROLES = ['admin', 'secretaria', 'financeiro']

async function list(db, user) {
  assertRole(user, ROLES)
  const query = db('integration_jobs')
  if (user.role !== 'admin') query.where({ created_by: user.id })
  return query.orderBy('created_at', 'desc').limit(100)
}

// Só enfileira a solicitação no banco local; nenhum serviço externo é acionado.
async function enqueue(db, input, user) {
  assertRole(user, ROLES)
  const route = catalog.routes.find((r) => r.id === input.route_id)
  if (!route) throw new ApiError(422, 'A rota de origem não existe no catálogo local.', 'INVALID_ROUTE')
  if ((user.role === 'financeiro' && route.module !== 'financeiro') || (user.role === 'secretaria' && route.module === 'financeiro')) {
    throw new ApiError(403, 'Seu perfil não pode solicitar esta integração.', 'FORBIDDEN')
  }
  return db.transaction(async (trx) => {
    const [saved] = await trx('integration_jobs')
      .insert({ id: randomUUID(), ...input, status: 'pendente', created_by: user.id })
      .returning('*')
    await audit(trx, user, 'enqueue', 'integration_jobs', saved.id, { route_id: saved.route_id })
    return saved
  })
}

module.exports = { list, enqueue }
