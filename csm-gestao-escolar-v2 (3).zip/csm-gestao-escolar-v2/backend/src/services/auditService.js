const { randomUUID } = require('node:crypto')

async function audit(db, user, action, resource, recordId, details = {}) {
  await db('audit_log').insert({ id:randomUUID(),actor_id:user.id,action,resource,record_id:recordId,details });
}

module.exports = { audit }
