const app = require('./src/app')
const db = require('./src/config/db')

const PORT = process.env.PORT || 3000
const HOST = process.env.HOST || '127.0.0.1'
const DEMO_EMAILS = ['admin@school.local', 'professor@school.local', 'secretaria@school.local', 'financeiro@school.local']

async function start() {
  await db.raw('SELECT 1') // falha cedo se o banco estiver inacessível
  // Em produção, recusa subir enquanto as contas de demonstração (senhas públicas) existirem.
  if (process.env.NODE_ENV === 'production') {
    const demo = await db('users').whereIn(db.raw('lower(email)'), DEMO_EMAILS).where({ active: true }).first()
    if (demo) throw new Error('Contas de demonstração (@school.local) ativas encontradas. Crie seu administrador com scripts/create-admin.js e desative essas contas (Cadastros › Usuários) antes de subir em produção.')
  }
  app.listen(PORT, HOST, () => console.log(`CSM API em http://${HOST}:${PORT}`))
}

start().catch((err) => { console.error(err.message); process.exit(1) })
