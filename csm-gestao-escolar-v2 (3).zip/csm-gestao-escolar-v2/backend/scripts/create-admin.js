// Cria (ou redefine a senha de) um administrador — uso em produção, onde o seed é bloqueado.
//   ADMIN_PASSWORD='senha-com-12+-caracteres' node scripts/create-admin.js "Nome Completo" email@escola.com.br
require('dotenv').config({ quiet: true })
const bcrypt = require('bcryptjs')
const { randomUUID } = require('node:crypto')
const db = require('../src/config/db')

async function main() {
  const [name, rawEmail] = process.argv.slice(2)
  const password = process.env.ADMIN_PASSWORD
  const email = (rawEmail || '').trim().toLowerCase()
  if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Uso: ADMIN_PASSWORD=... node scripts/create-admin.js "Nome" email')
  if (!password || password.length < 12 || Buffer.byteLength(password) > 72) throw new Error('ADMIN_PASSWORD deve ter 12+ caracteres (máx. 72 bytes).')
  const password_hash = await bcrypt.hash(password, 12)
  const existing = await db('users').whereRaw('lower(email) = ?', [email]).first()
  if (existing) {
    await db('users').where({ id: existing.id }).update({ name, role: 'admin', active: true, password_hash, updated_at: new Date() })
    await db('sessions').where({ user_id: existing.id }).whereNull('revoked_at').update({ revoked_at: new Date() })
    console.log(`Administrador atualizado: ${email} (sessões anteriores revogadas)`)
  } else {
    await db('users').insert({ id: randomUUID(), name, email, role: 'admin', active: true, password_hash })
    console.log(`Administrador criado: ${email}`)
  }
}
main().catch((e) => { console.error(e.message); process.exitCode = 1 }).finally(() => db.destroy())
