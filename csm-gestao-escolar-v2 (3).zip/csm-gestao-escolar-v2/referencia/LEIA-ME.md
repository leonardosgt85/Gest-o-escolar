# Referência visual do sistema original

Coloque aqui os screenshots do sistema que está sendo copiado. Sem eles o layout só pode ser
aproximado — o pacote do Codex não trouxe nenhuma imagem do original.

## O que capturar (1280 px de largura, navegador em 100% de zoom; PNG, sem recorte)
| Arquivo sugerido | Tela |
|---|---|
| `01-login.png` | Login |
| `02-home.png` | Início (página inteira, com cabeçalho, faixa de sessão, menu, faixa vermelha, banner e rodapé) |
| `03-menu-academico.png` … `08-menu-patrimonio.png` | Cada módulo com o submenu aberto (inclusive submenus aninhados) |
| `10-alunos-consulta.png` | Alunos: consulta com filtros abertos |
| `11-alunos-form.png` | Alunos: formulário de inclusão aberto |
| `12-alunos-form-abas.png` | Cada aba/seção do formulário, se houver |
| `20-relatorio-filtro.png` / `21-relatorio-resultado.png` | Um relatório (filtro e resultado) |
| `30-financeiro-baixa.png` | Cobranças/baixa |
| `40-modal-confirmacao.png` | Um diálogo de confirmação e um de erro |
| `50-mobile-home.png` | Início em 390 px (se o original for responsivo) |

## Medidas reais (muito mais valioso que screenshot)
No DevTools (F12) → Elements → Computed, anote para: cabeçalho, faixa de sessão, navbar, item ativo,
faixa vermelha, rodapé, botões, inputs e tabela:
`background-color`, `color`, `font-family`, `font-size`, `height`, `padding`, `border`.
Cole em `referencia/medidas.md`. O arquivo `project/src/index.css` tem as variáveis `--csm-*` prontas para receber os valores.

## Não coloque aqui
Dados reais de alunos/responsáveis, senhas, cookies ou tokens. Use registros fictícios ou desfoque antes de salvar.
