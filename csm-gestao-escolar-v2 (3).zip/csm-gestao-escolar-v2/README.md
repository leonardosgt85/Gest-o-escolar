# CSM — Gestão Escolar (v2, estrutura SGEC + Bootstrap 3)

Mesmo sistema do pacote gerado pelo Codex (cadastros acadêmicos e financeiros, relatórios,
recebimento manual, perfis), **reorganizado na estrutura do SGEC** e com o visual montado em
**Bootstrap 3.4.1** (no lugar de CSS próprio/Tailwind).

```
backend/                      Node + Express 5 + Knex + PostgreSQL (CommonJS, como o SGEC)
  server.js, knexfile.js
  src/app.js                  helmet, cookies, Origin check, rotas, serve project/dist se existir
  src/config/                 db.js (Knex), env.js (FRONTEND_URL, SESSION_HOURS)
  src/middleware/             auth.js (sessão), requireOrigin.js, errorHandler.js
  src/routes/ → controllers/ → services/   (mesmo fluxo do SGEC)
  src/services/               policyService (perfis/escopo), resourceService (CRUD + regras),
                              paymentService, reportService, sessionService, authService …
  src/shared/                 resources.json (23 cadastros) e catalog.json (176 destinos de menu)
  src/db/migrations/          27 arquivos, um por tabela (…_create_students.js etc.), em ordem de dependência
  src/db/seeds/               01_users, 02_academico, 03_financeiro, 04_institucional (só development/test)
  src/db/demoData.js          ids e helpers dos seeds (fora de seeds/: o knex roda todo arquivo de lá)
  tests/api.test.js           Jest + Supertest contra PostgreSQL real
project/                      React 19 + Vite + TypeScript + react-router + Bootstrap 3
  src/context/AppContext.tsx  sessão e catálogo
  src/lib/                    api.ts, format.ts, types.ts
  src/components/             Layout (cabeçalho, navbar, faixa, rodapé), ui.tsx, formulários
  src/pages/                  Login, Home, Dashboard, Resource, Report, Integration, Pending
  src/index.css               tema (cores/medidas) por cima do Bootstrap 3
docs/codex/                   análise e matriz de paridade (176 destinos) feitas pelo Codex
referencia/                   COLOQUE AQUI os screenshots do sistema original (ver LEIA-ME)
tools/capture.mjs             captura as telas deste projeto para comparar com a referência
CLAUDE.md                     briefing para o Claude Code reavaliar e ajustar o layout
```

## Requisitos
Node 20+ e PostgreSQL 14+.

## Instalação
```sh
# 1) banco (uma vez)
createdb school            # ou: psql -c "CREATE DATABASE school;"

# 2) backend
cd backend
npm install
cp .env.example .env       # preencha DB_PASSWORD (ou DATABASE_URL)
npm run migrate
npm run seed               # 4 arquivos; admin de dev + dados fictícios (SEED_DEMO=1). Repetível, não apaga nada
npm run dev                # http://127.0.0.1:3000

# 3) frontend (outro terminal)
cd project
npm install
npm run dev                # http://localhost:5173 (proxy /api → 3000)
```
Produção em um processo só: `cd project && npm run build`, depois `cd backend && npm start` — o
Express serve `project/dist` (desligue com `SERVE_FRONTEND=0`). Adicione a URL pública em `FRONTEND_URL`.

## Subir em produção (manual, como o SGEC)
1. `createdb school` no servidor e copie `backend/.env.example` → `backend/.env`:
   `NODE_ENV=production`, `DB_*` (ou `DATABASE_URL`), `HOST`/`PORT`, `FRONTEND_URL=https://seu-dominio` (origem exata, usada na checagem de gravação), `SESSION_HOURS`. Não defina `SEED_DEMO`.
2. `cd backend && npm ci --omit=dev && npm run migrate` (**não rode `npm run seed`**: ele é bloqueado em produção).
3. Crie o primeiro administrador: `ADMIN_PASSWORD='12+ caracteres' node scripts/create-admin.js "Seu Nome" voce@escola.com.br`.
4. `cd project && npm ci && npm run build` (ou gere o `dist` na sua máquina e envie).
5. `cd backend && npm start` atrás de HTTPS (Nginx/Apache como proxy). O cookie de sessão é `Secure` em produção; `trust proxy` já está ativo. Use PM2/systemd para manter o processo.
6. O servidor recusa iniciar em produção se existir conta `@school.local` ativa (contas de demonstração).

## Acesso de demonstração (somente development/test)
| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | admin@school.local | AdminDev!123 |
| Secretaria | secretaria@school.local | SecretariaDev!123 |
| Professor | professor@school.local | ProfessorDev!123 |
| Financeiro | financeiro@school.local | FinanceiroDev!123 |

**Remova essas contas antes de qualquer uso real** — o seed é bloqueado fora de development/test.

## Testes
```sh
cd backend
NODE_ENV=test DB_PASSWORD=... npm test   # usa o banco <DB_NAME>_test (crie: createdb school_test)
cd ../project && npm run typecheck && npm run build
```
Os testes derrubam e recriam o esquema do banco de teste — nunca aponte para o banco real.

## O que mudou em relação ao pacote do Codex
- **Estrutura**: `server/*.js` monolítico → `routes/controllers/services/middleware` como no SGEC; frontend `client/` JSX → `project/src` TSX.
- **Sessão**: JWT + token CSRF → sessão opaca em cookie httpOnly (hash na tabela `sessions`, como no SGEC) + verificação de `Origin` em toda escrita. Troca de senha/perfil/desativação revoga as sessões do usuário.
- **Erros da API**: `{ error: "mensagem", code, fields }` (formato do SGEC).
- **Visual**: Bootstrap 3.4.1 só com **CSS** (sem jQuery); dropdowns, modais e colapso são componentes React usando as classes do BS3. Ícones: Glyphicons.
- Lógica de negócio (validações acadêmicas, escopo do professor, recebimento idempotente, relatórios) foi **portada sem alteração de regra**; 23 testes de API cobrem os pontos críticos.

## Limites conhecidos (herdados da extração)
- Dos 176 destinos de menu, 91 usam CRUD/relatório **genérico** e 85 são páginas "pendente". Só a tela de Alunos foi observada de verdade no original; campos dos demais formulários são inferidos. Ver `docs/codex/PARIDADE.csv`.
- Cores, fonte e medidas do layout são **estimadas** a partir de uma imagem. Para fidelidade real falta material de referência (ver `referencia/LEIA-ME.md`).
- Logo, banner e identidade visual do fornecedor **não** são reproduzidos (placeholders). Para colocar a marca da escola: troque `.logo-placeholder` em `Layout.tsx`/`Login.tsx` por `<img>` e guarde o arquivo em `project/public/`.
- Integrações (boleto, banco, fiscal, WhatsApp…) só enfileiram solicitações locais; nada é enviado.

## Como adicionar um cadastro
1. Declare-o em `backend/src/shared/resources.json` (campos, tipos, referências).
2. Crie **uma migration por tabela** (`npx knex migrate:make create_<tabela>`) com as colunas escritas em Knex; nunca edite migrations já aplicadas — alterações entram em arquivos novos (`alter_<tabela>_...`).
3. Libere o perfil em `policyService.js` (e em `WRITE` de `project/src/pages/Resource.tsx`, só para exibir os botões).
4. Aponte uma rota do `catalog.json` (`mode: "resource"`, `target: "<chave>"`).
