# Briefing — reavaliação e fidelidade de layout (CSM Gestão Escolar)

Você vai **reavaliar** este projeto e levar o **layout o mais perto possível do sistema original**,
sem copiar a identidade do fornecedor.

## Contexto
- Estrutura igual à do SGEC: `backend/` (routes → controllers → services) e `project/` (React + TS).
- Visual em **Bootstrap 3.4.1 (só CSS)**. Não adicione jQuery nem o JS do Bootstrap; dropdown, modal e
  colapso são componentes React com as classes do BS3 (`components/ui.tsx`, `components/Layout.tsx`).
- Tema em `project/src/index.css` (variáveis `--csm-*`). **As cores/medidas atuais são estimativas.**
- Lógica de negócio e permissões estão em `backend/src/services/` — **não altere regras** ao mexer em layout.
- Matriz de paridade e análise do Codex: `docs/codex/` (91 destinos com CRUD/relatório genérico, 85 pendentes).

## Regras
1. Compare **tela por tela** com os arquivos de `referencia/` (screenshots + `medidas.md`). Sem referência
   para uma tela, **não invente** — registre como "sem referência" em `docs/PARIDADE_VISUAL.md`.
2. Reproduza **composição, proporções, cores, tipografia, espaçamentos e comportamento de menus/tabelas/formulários**.
   **Não** copie logotipo, banner, textos comerciais ou marcas do fornecedor: mantenha placeholders.
3. Prefira ajustar variáveis e classes em `index.css`; só mude JSX quando a estrutura diferir.
   Use classes nativas do Bootstrap 3 antes de CSS novo.
4. Mantenha acessibilidade (foco visível, Esc nos diálogos, rótulos) e a ausência de rolagem horizontal da página
   em 390/768/1280 px (a tabela rola dentro do próprio contêiner).
5. Formulários dos cadastros ainda são **inferidos** (campos mínimos). Só altere campos/validações com base em
   screenshot do formulário real; mudanças de esquema entram em **nova migration** (uma por alteração), nunca editando as já criadas.

## Roteiro sugerido
1. `cd backend && npm i && cp .env.example .env && npm run migrate && npm run seed && npm run dev`
2. `cd project && npm i && npm run dev`
3. `npm i -D playwright && npx playwright install chromium` (na raiz) e `node tools/capture.mjs`
4. Para cada tela de `referencia/`: abrir lado a lado com `referencia/capturas/`, listar diferenças
   (cabeçalho, faixa de sessão, navbar, submenus aninhados, faixa vermelha, rodapé, tabela, filtros, modais),
   corrigir, recapturar. Repita até a diferença visível ser mínima.
6. Antes de terminar: `cd project && npm run typecheck && npm run build` e `cd backend && NODE_ENV=test npm test`.
7. Atualize `docs/PARIDADE_VISUAL.md` (tela, referência usada, diferenças restantes) e responda com o que ficou pendente.

## Pontos já conhecidos que dependem da referência
- Submenus: hoje são grupos achatados com busca; o original tem hierarquia (Arquivos › Lançamentos › Relatórios…).
- Tipografia: BS3 padrão (Helvetica Neue/Arial 14 px); o original pode usar fonte condensada.
- Proporção cabeçalho/faixa de sessão (56/44), alturas da navbar (50 px) e da faixa vermelha (20 px): estimadas.
- Início: banner central é placeholder; a grade de atalhos por cadastro foi inventada pelo Codex.
